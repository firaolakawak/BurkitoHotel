import React from 'react';
import { useHotel } from '../../context/HotelContext.tsx';
import {
  Bed,
  Users,
  Sparkles,
  Wrench,
  Clock,
  CalendarDays
} from 'lucide-react';

export const MetricsBar: React.FC = () => {
  const { rooms, bookings } = useHotel();

  const totalRooms = rooms.length;
  const occupiedRooms = rooms.filter(r => r.status === 'OCCUPIED').length;
  const availableRooms = rooms.filter(r => r.status === 'AVAILABLE').length;
  const dirtyRooms = rooms.filter(r => r.status === 'DIRTY').length;
  const maintenanceRooms = rooms.filter(r => r.status === 'MAINTENANCE').length;

  const occupancyPct = totalRooms > 0 ? Math.round((occupiedRooms / totalRooms) * 100) : 0;
  const availablePct = totalRooms > 0 ? Math.round((availableRooms / totalRooms) * 100) : 0;
  const dirtyPct = totalRooms > 0 ? Math.round((dirtyRooms / totalRooms) * 100) : 0;
  const maintenancePct = totalRooms > 0 ? Math.round((maintenanceRooms / totalRooms) * 100) : 0;

  // Real or derived arrival/departure counts
  const arrivalsToday = bookings.filter(b => b.status === 'CONFIRMED' || b.status === 'CHECKED_IN').length;
  const departuresToday = bookings.filter(b => b.status === 'CHECKED_IN').length;

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
      {/* 1. Total Rooms */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-3.5 flex items-center gap-3.5 shadow-xs">
        <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600 shrink-0">
          <Bed className="w-5 h-5" />
        </div>
        <div>
          <div className="text-[11px] font-medium text-slate-500">Total Rooms</div>
          <div className="text-xl font-bold text-slate-900 tracking-tight">{totalRooms}</div>
        </div>
      </div>

      {/* 2. Occupied */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-3.5 flex items-center gap-3.5 shadow-xs">
        <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600 shrink-0">
          <Users className="w-5 h-5" />
        </div>
        <div>
          <div className="text-[11px] font-medium text-slate-500">Occupied</div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-slate-900 tracking-tight">{occupiedRooms}</span>
            <span className="text-[11px] font-medium text-slate-400">{occupancyPct}%</span>
          </div>
        </div>
      </div>

      {/* 3. Available */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-3.5 flex items-center gap-3.5 shadow-xs">
        <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600 shrink-0">
          <Bed className="w-5 h-5" />
        </div>
        <div>
          <div className="text-[11px] font-medium text-slate-500">Available</div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-emerald-600 tracking-tight">{availableRooms}</span>
            <span className="text-[11px] font-medium text-slate-400">{availablePct}%</span>
          </div>
        </div>
      </div>

      {/* 4. Dirty */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-3.5 flex items-center gap-3.5 shadow-xs">
        <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center text-amber-600 shrink-0">
          <Sparkles className="w-5 h-5" />
        </div>
        <div>
          <div className="text-[11px] font-medium text-slate-500">Dirty</div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-amber-600 tracking-tight">{dirtyRooms}</span>
            <span className="text-[11px] font-medium text-slate-400">{dirtyPct}%</span>
          </div>
        </div>
      </div>

      {/* 5. Maintenance */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-3.5 flex items-center gap-3.5 shadow-xs">
        <div className="w-10 h-10 rounded-xl bg-rose-50 flex items-center justify-center text-rose-600 shrink-0">
          <Wrench className="w-5 h-5" />
        </div>
        <div>
          <div className="text-[11px] font-medium text-slate-500">Maintenance</div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-rose-600 tracking-tight">{maintenanceRooms}</span>
            <span className="text-[11px] font-medium text-slate-400">{maintenancePct}%</span>
          </div>
        </div>
      </div>

      {/* 6. Arrivals Today */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-3.5 flex items-center gap-3.5 shadow-xs">
        <div className="w-10 h-10 rounded-xl bg-purple-50 flex items-center justify-center text-purple-600 shrink-0">
          <Clock className="w-5 h-5" />
        </div>
        <div>
          <div className="text-[11px] font-medium text-slate-500">Arrivals Today</div>
          <div className="text-xl font-bold text-slate-900 tracking-tight">{arrivalsToday}</div>
        </div>
      </div>

      {/* 7. Departures Today */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-3.5 flex items-center gap-3.5 shadow-xs">
        <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600 shrink-0">
          <CalendarDays className="w-5 h-5" />
        </div>
        <div>
          <div className="text-[11px] font-medium text-slate-500">Departures Today</div>
          <div className="text-xl font-bold text-slate-900 tracking-tight">{departuresToday}</div>
        </div>
      </div>
    </div>
  );
};
