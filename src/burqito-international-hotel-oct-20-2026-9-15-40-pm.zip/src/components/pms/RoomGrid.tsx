import React, { useState, useMemo } from 'react';
import { useHotel } from '../../context/HotelContext.tsx';
import { Room, RoomCategory, RoomStatus } from '../../types/index.ts';
import {
  KeyRound,
  User,
  Sparkles,
  Wrench,
  CheckCircle2,
  SlidersHorizontal,
  ChevronDown,
  LayoutGrid,
  List,
  Bed,
  MapPin,
  Calendar,
  Clock,
  ArrowRight,
  ShieldCheck,
  Check,
  RotateCcw,
  DoorClosed,
  Plus
} from 'lucide-react';

export const RoomGrid: React.FC = () => {
  const {
    rooms,
    floors,
    bookings,
    selectedRoom,
    setSelectedRoom,
    openBookingWizardForRoom,
    openCheckOutModal,
    formatMoney,
    currency,
    exchangeRate,
    clearAllOccupiedAndResetFrontDesk
  } = useHotel();

  // Floor selection
  const [selectedFloor, setSelectedFloor] = useState<number | 'ALL'>('ALL');
  const [viewMode, setViewMode] = useState<'GRID' | 'LIST'>('GRID');
  const [subTab, setSubTab] = useState<'ROOM_GRID' | 'FLOOR_PLAN' | 'AVAILABILITY' | 'ARRIVALS' | 'DEPARTURES' | 'IN_HOUSE'>('ROOM_GRID');
  const [roomTypeFilter, setRoomTypeFilter] = useState<'ALL' | 'STANDARD' | 'DELUXE' | 'SUITE'>('ALL');

  // Dynamically generated floor list from custom floors and actual room counts
  const floorList = useMemo(() => {
    const list: Array<{ id: number | 'ALL'; name: string; desc: string; count: number }> = [
      { id: 'ALL', name: 'All Floors', desc: `${rooms.length} rooms total`, count: rooms.length }
    ];
    const sortedFloors = [...floors].sort((a, b) => b.floorNumber - a.floorNumber);
    sortedFloors.forEach(fl => {
      const count = rooms.filter(r => r.floor === fl.floorNumber).length;
      list.push({
        id: fl.floorNumber,
        name: fl.name || `Floor ${fl.floorNumber}`,
        desc: fl.description || fl.wing || `${count} rooms`,
        count
      });
    });
    return list;
  }, [floors, rooms]);

  // Filtered rooms for the grid
  const displayedRooms = useMemo(() => {
    return rooms.filter(r => {
      if (selectedFloor !== 'ALL' && r.floor !== selectedFloor) return false;
      if (roomTypeFilter !== 'ALL' && r.category !== roomTypeFilter) return false;
      return true;
    }).sort((a, b) => Number(a.roomNumber) - Number(b.roomNumber));
  }, [rooms, selectedFloor, roomTypeFilter]);

  // Status styling per card matching the screenshot:
  const getCardStyle = (room: Room) => {
    switch (room.status) {
      case 'AVAILABLE':
        return {
          container: 'bg-[#F0FDF4] border-[#BBF7D0] hover:border-emerald-400',
          badgeBg: 'bg-[#DCFCE7] text-[#15803D]',
          badgeText: 'Available',
          badgeIcon: KeyRound,
          topIcon: KeyRound,
          topIconColor: 'text-[#16A34A]'
        };
      case 'OCCUPIED':
        return {
          container: 'bg-[#EFF6FF] border-[#BFDBFE] hover:border-blue-400',
          badgeBg: 'bg-blue-100 text-blue-800',
          badgeText: 'Occupied',
          badgeIcon: Bed,
          topIcon: Bed,
          topIconColor: 'text-[#2563EB]'
        };
      case 'DIRTY':
        return {
          container: 'bg-[#FFFBEB] border-[#FDE68A] hover:border-amber-400',
          badgeBg: 'bg-[#FEF3C7] text-[#B45309]',
          badgeText: 'Dirty',
          badgeIcon: Sparkles,
          topIcon: Sparkles,
          topIconColor: 'text-[#D97706]'
        };
      case 'MAINTENANCE':
        return {
          container: 'bg-[#FEF2F2] border-[#FECDD3] hover:border-rose-400',
          badgeBg: 'bg-[#FEE2E2] text-[#B91C1C]',
          badgeText: 'Maintenance',
          badgeIcon: Wrench,
          topIcon: Wrench,
          topIconColor: 'text-[#DC2626]'
        };
      case 'CHECKED_OUT':
      default:
        return {
          container: 'bg-white border-slate-200 hover:border-slate-300',
          badgeBg: 'bg-slate-100 text-slate-700',
          badgeText: 'Checked-Out',
          badgeIcon: CheckCircle2,
          topIcon: CheckCircle2,
          topIconColor: 'text-slate-400'
        };
    }
  };

  return (
    <div className="space-y-4">
      {/* Sub Tabs and Controls Strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200">
        {/* Navigation Tabs */}
        <div className="flex space-x-6 text-xs font-semibold overflow-x-auto scrollbar-none">
          {[
            { id: 'ROOM_GRID', label: 'Room Grid' },
            { id: 'FLOOR_PLAN', label: 'Floor Plan' },
            { id: 'AVAILABILITY', label: 'Availability' },
            { id: 'ARRIVALS', label: 'Arrivals' },
            { id: 'DEPARTURES', label: 'Departures' },
            { id: 'IN_HOUSE', label: 'In-House' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setSubTab(tab.id as any)}
              className={`py-3 transition-colors relative whitespace-nowrap ${
                subTab === tab.id
                  ? 'text-blue-600 font-bold'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {tab.label}
              {subTab === tab.id && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600 rounded-full" />
              )}
            </button>
          ))}
        </div>

        {/* View mode toggle + All room types filter */}
        <div className="flex items-center gap-2.5 pb-2 sm:pb-0">
          {/* Grid / List segmented toggle */}
          <div className="flex items-center rounded-lg border border-slate-200 bg-white p-0.5 text-xs">
            <button
              onClick={() => setViewMode('GRID')}
              className={`px-3 py-1 rounded-md font-semibold flex items-center gap-1 transition-colors ${
                viewMode === 'GRID'
                  ? 'bg-blue-50 text-blue-700 border border-blue-200'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Grid</span>
            </button>
            <button
              onClick={() => setViewMode('LIST')}
              className={`px-3 py-1 rounded-md font-semibold flex items-center gap-1 transition-colors ${
                viewMode === 'LIST'
                  ? 'bg-blue-50 text-blue-700 border border-blue-200'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>List</span>
            </button>
          </div>

          {/* Room type filter */}
          <div className="relative">
            <select
              value={roomTypeFilter}
              onChange={e => setRoomTypeFilter(e.target.value as any)}
              className="appearance-none bg-white border border-slate-200 rounded-lg pl-3 pr-8 py-1.5 text-xs font-medium text-slate-700 focus:outline-none focus:border-blue-500 cursor-pointer"
            >
              <option value="ALL">All Room Types</option>
              <option value="STANDARD">Standard</option>
              <option value="DELUXE">Deluxe</option>
              <option value="SUITE">Suite</option>
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>

          {/* Clear Mockup & Make All Rooms Available Button */}
          <button
            onClick={() => clearAllOccupiedAndResetFrontDesk()}
            title="Clear any mock occupied rooms and set all rooms to available"
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-lg text-xs font-semibold transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Make All Available</span>
          </button>
        </div>
      </div>

      {/* SUBTAB 1: ROOM GRID (Grid & List View) */}
      {subTab === 'ROOM_GRID' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-start">
          {/* Left Floor Selector */}
          <div className="md:col-span-2 space-y-1.5">
            {floorList.map(fl => {
              const isSelected = selectedFloor === fl.id;
              return (
                <button
                  key={fl.id}
                  onClick={() => setSelectedFloor(fl.id as any)}
                  className={`w-full text-left p-3 rounded-xl border transition-all ${
                    isSelected
                      ? 'bg-blue-50/70 border-blue-500/80 shadow-xs ring-1 ring-blue-500/30'
                      : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/50'
                  }`}
                >
                  <div className={`text-xs font-bold ${isSelected ? 'text-blue-900' : 'text-slate-800'}`}>
                    {fl.name}
                  </div>
                  {fl.id !== 'ALL' && (
                    <div className={`text-[11px] mt-0.5 ${isSelected ? 'text-blue-700' : 'text-slate-400'}`}>
                      {fl.desc}
                    </div>
                  )}
                  {fl.id !== 'ALL' && (
                    <div className={`text-[10px] mt-0.5 ${isSelected ? 'text-blue-600 font-medium' : 'text-slate-400'}`}>
                      {fl.count} rooms
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          {/* Center Room Grid or List Matrix */}
          <div className="md:col-span-10 space-y-3">
            {/* Floor Header & Occupancy Bar */}
            <div className="flex items-center justify-between pb-1">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-slate-900">
                  {selectedFloor === 'ALL'
                    ? 'All Hotel Floors'
                    : floors.find(f => f.floorNumber === selectedFloor)?.name || `Floor ${selectedFloor}`}
                </h3>
                <span className="text-xs text-slate-500">
                  {selectedFloor === 'ALL'
                    ? 'Overall Property Inventory'
                    : floors.find(f => f.floorNumber === selectedFloor)?.description || floors.find(f => f.floorNumber === selectedFloor)?.wing || 'Custom Wing'}
                </span>
              </div>

              <div className="flex items-center gap-3">
                {(() => {
                  const targetRooms = selectedFloor === 'ALL' ? rooms : rooms.filter(r => r.floor === selectedFloor);
                  const occCount = targetRooms.filter(r => r.status === 'OCCUPIED').length;
                  const occPct = targetRooms.length > 0 ? Math.round((occCount / targetRooms.length) * 100) : 0;
                  return (
                    <>
                      <span className="text-xs text-slate-500">
                        {targetRooms.length} rooms · Occupancy <strong className="text-slate-800">{occPct}%</strong>
                      </span>
                      <div className="w-24 h-2 rounded-full bg-blue-100 overflow-hidden flex">
                        <div className="h-full bg-blue-600 rounded-full transition-all" style={{ width: `${occPct}%` }} />
                      </div>
                    </>
                  );
                })()}
              </div>
            </div>

            {viewMode === 'GRID' ? (
              /* 6-Column Room Card Grid matching Screenshot */
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                {displayedRooms.map(room => {
                  const card = getCardStyle(room);
                  const activeBooking = room.currentBookingId
                    ? bookings.find(b => b.id === room.currentBookingId)
                    : null;
                  const guest = activeBooking?.guest;
                  const isSelected = selectedRoom?.id === room.id;
                  const TopIcon = card.topIcon;

                  return (
                    <div
                      key={room.id}
                      onClick={() => setSelectedRoom(room)}
                      className={`relative p-3 rounded-xl border text-left cursor-pointer transition-all duration-150 flex flex-col justify-between min-h-[118px] ${card.container} ${
                        isSelected ? 'ring-2 ring-blue-600 shadow-md scale-[1.02]' : 'shadow-2xs'
                      }`}
                    >
                      <div>
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="text-sm font-bold text-slate-900 leading-none">
                              {room.roomNumber}
                            </div>
                            <div className="text-[10px] text-slate-500 mt-0.5 capitalize">
                              {room.category.toLowerCase()}
                            </div>
                          </div>
                          <TopIcon className={`w-3.5 h-3.5 ${card.topIconColor} shrink-0`} />
                        </div>

                        <div className="mt-2.5">
                          {room.status === 'OCCUPIED' && guest ? (
                            <div className="flex items-center gap-1.5 text-xs text-slate-900 font-semibold truncate">
                              <User className="w-3 h-3 text-slate-500 shrink-0" />
                              <span className="truncate">{guest.firstName} {guest.lastName}</span>
                            </div>
                          ) : (
                            <div className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-semibold ${card.badgeBg}`}>
                              <span>{card.badgeText}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="mt-2.5 pt-1.5 border-t border-black/5 flex items-center justify-between text-[11px] font-semibold text-slate-700">
                        <span>{formatMoney(room.pricePerNight)}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              /* Tabular List View */
              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase text-[10px] font-semibold">
                      <th className="py-2.5 px-3">Room</th>
                      <th className="py-2.5 px-3">Floor</th>
                      <th className="py-2.5 px-3">Category</th>
                      <th className="py-2.5 px-3">Status</th>
                      <th className="py-2.5 px-3">Occupant</th>
                      <th className="py-2.5 px-3">Nightly Rate</th>
                      <th className="py-2.5 px-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {displayedRooms.map(room => {
                      const activeBooking = room.currentBookingId ? bookings.find(b => b.id === room.currentBookingId) : null;
                      const card = getCardStyle(room);
                      const isSelected = selectedRoom?.id === room.id;

                      return (
                        <tr
                          key={room.id}
                          onClick={() => setSelectedRoom(room)}
                          className={`cursor-pointer transition-colors ${isSelected ? 'bg-blue-50/70' : 'hover:bg-slate-50'}`}
                        >
                          <td className="py-2.5 px-3 font-bold text-slate-900">Room {room.roomNumber}</td>
                          <td className="py-2.5 px-3 text-slate-600">Floor {room.floor}</td>
                          <td className="py-2.5 px-3 font-medium text-slate-700 capitalize">{room.category.toLowerCase()}</td>
                          <td className="py-2.5 px-3">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${card.badgeBg}`}>
                              {card.badgeText}
                            </span>
                          </td>
                          <td className="py-2.5 px-3">
                            {activeBooking?.guest ? `${activeBooking.guest.firstName} ${activeBooking.guest.lastName}` : '—'}
                          </td>
                          <td className="py-2.5 px-3 font-mono font-bold text-slate-900">{formatMoney(room.pricePerNight)}</td>
                          <td className="py-2.5 px-3 text-right text-blue-600 font-semibold hover:underline">
                            Inspect
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 2: DYNAMIC ARCHITECTURAL FLOOR PLAN */}
      {subTab === 'FLOOR_PLAN' && (() => {
        const activeFloorNum = selectedFloor === 'ALL' ? (floors[0]?.floorNumber || 1) : selectedFloor;
        const targetFloorConfig = floors.find(f => f.floorNumber === activeFloorNum) || {
          floorNumber: activeFloorNum,
          name: `Floor ${activeFloorNum}`,
          wing: 'Lake Wing',
          description: 'Custom Layout'
        };
        const floorRooms = rooms.filter(r => r.floor === activeFloorNum).sort((a, b) => Number(a.roomNumber) - Number(b.roomNumber));
        const half = Math.ceil(floorRooms.length / 2);
        const topRooms = floorRooms.slice(0, half);
        const bottomRooms = floorRooms.slice(half);

        return (
          <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-4 shadow-2xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Architectural Schematic: {targetFloorConfig.name} ({targetFloorConfig.wing || 'Main Wing'})
                </h3>
                <p className="text-xs text-slate-500">
                  {floorRooms.length} rooms inventory · 100% synchronized with Room Management
                </p>
              </div>
              <div className="flex items-center gap-3 text-xs flex-wrap">
                <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-emerald-100 border border-emerald-300" /> Available</span>
                <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-blue-100 border border-blue-300" /> Occupied</span>
                <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-amber-100 border border-amber-300" /> Dirty</span>
                <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-rose-100 border border-rose-300" /> Maintenance</span>
              </div>
            </div>

            {floorRooms.length === 0 ? (
              <div className="py-12 text-center space-y-2 border border-dashed border-slate-200 rounded-xl">
                <DoorClosed className="w-8 h-8 text-slate-300 mx-auto" />
                <h4 className="text-xs font-bold text-slate-700">No rooms configured on {targetFloorConfig.name}</h4>
                <p className="text-[11px] text-slate-400">Set room count for this floor in Room Management</p>
              </div>
            ) : (
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/80 space-y-3 overflow-x-auto min-w-[580px]">
                {/* Top Wing */}
                <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center justify-between">
                  <span>North Corridor Rooms</span>
                  <span className="text-[10px] text-slate-400 font-normal">{topRooms.length} units</span>
                </div>
                <div
                  className="grid gap-2"
                  style={{ gridTemplateColumns: `repeat(${Math.max(topRooms.length, 1)}, minmax(0, 1fr))` }}
                >
                  {topRooms.map(r => (
                    <div
                      key={r.id}
                      onClick={() => setSelectedRoom(r)}
                      className={`p-2.5 rounded-lg border text-center cursor-pointer transition-all hover:scale-102 ${
                        r.status === 'OCCUPIED'
                          ? 'bg-blue-50 border-blue-200 text-blue-900'
                          : r.status === 'AVAILABLE'
                          ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                          : r.status === 'DIRTY'
                          ? 'bg-amber-50 border-amber-200 text-amber-900'
                          : 'bg-rose-50 border-rose-200 text-rose-900'
                      }`}
                    >
                      <div className="text-xs font-bold font-mono">{r.roomNumber}</div>
                      <div className="text-[10px] mt-0.5 opacity-75 capitalize">{r.category.toLowerCase()}</div>
                      <div className="text-[9px] font-semibold mt-1 text-emerald-700">Available</div>
                    </div>
                  ))}
                </div>

                {/* Central Corridor & Elevator Bank */}
                <div className="h-10 bg-slate-200/80 rounded-lg flex items-center justify-between px-6 text-xs text-slate-500 font-semibold border border-slate-300/80">
                  <span>◄ Fire Exit & West Balconies</span>
                  <span className="px-3 py-1 bg-white rounded border border-slate-300 shadow-2xs text-slate-700 font-bold">
                    Elevator Lobby · Floor {activeFloorNum}
                  </span>
                  <span>East Promenade Deck ►</span>
                </div>

                {/* South Wing */}
                <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider pt-2 flex items-center justify-between">
                  <span>South Corridor Rooms</span>
                  <span className="text-[10px] text-slate-400 font-normal">{bottomRooms.length} units</span>
                </div>
                <div
                  className="grid gap-2"
                  style={{ gridTemplateColumns: `repeat(${Math.max(bottomRooms.length, 1)}, minmax(0, 1fr))` }}
                >
                  {bottomRooms.map(r => (
                    <div
                      key={r.id}
                      onClick={() => setSelectedRoom(r)}
                      className={`p-2.5 rounded-lg border text-center cursor-pointer transition-all hover:scale-102 ${
                        r.status === 'OCCUPIED'
                          ? 'bg-blue-50 border-blue-200 text-blue-900'
                          : r.status === 'AVAILABLE'
                          ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                          : r.status === 'DIRTY'
                          ? 'bg-amber-50 border-amber-200 text-amber-900'
                          : 'bg-rose-50 border-rose-200 text-rose-900'
                      }`}
                    >
                      <div className="text-xs font-bold font-mono">{r.roomNumber}</div>
                      <div className="text-[10px] mt-0.5 opacity-75 capitalize">{r.category.toLowerCase()}</div>
                      <div className="text-[9px] font-semibold mt-1 text-emerald-700">Available</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        );
      })()}

      {/* SUBTAB 3: DYNAMIC AVAILABILITY MATRIX */}
      {subTab === 'AVAILABILITY' && (() => {
        // Compute real category breakdown dynamically from rooms
        const categories: RoomCategory[] = ['STANDARD', 'DELUXE', 'SUITE', 'PRESIDENTIAL'];
        const breakdown = categories
          .map(cat => {
            const catRooms = rooms.filter(r => r.category === cat);
            if (catRooms.length === 0) return null;
            const avail = catRooms.filter(r => r.status === 'AVAILABLE').length;
            const occ = catRooms.filter(r => r.status === 'OCCUPIED').length;
            const dirty = catRooms.filter(r => r.status === 'DIRTY').length;
            const avgRate = catRooms.reduce((sum, r) => sum + r.pricePerNight, 0) / catRooms.length;
            const label = cat === 'SUITE' ? 'Executive Suites' : cat === 'DELUXE' ? 'Deluxe Rooms' : cat === 'PRESIDENTIAL' ? 'Presidential Suites' : 'Standard Rooms';
            return {
              cat: label,
              total: catRooms.length,
              avail,
              occ,
              dirty,
              rate: avgRate
            };
          })
          .filter(Boolean) as Array<{ cat: string; total: number; avail: number; occ: number; dirty: number; rate: number }>;

        return (
          <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-4 shadow-2xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Room Category Availability Matrix</h3>
                <p className="text-xs text-slate-500">Live room inventory count derived directly from Room Management</p>
              </div>
              <button
                onClick={() => openBookingWizardForRoom()}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg text-xs"
              >
                + Book Room
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 text-[10px] font-bold uppercase text-slate-500 border-b border-slate-200">
                    <th className="py-2.5 px-3">Category</th>
                    <th className="py-2.5 px-3">Total Inventory</th>
                    <th className="py-2.5 px-3">Available Now</th>
                    <th className="py-2.5 px-3">Occupied</th>
                    <th className="py-2.5 px-3">Turnaround / Dirty</th>
                    <th className="py-2.5 px-3">Nightly Rate</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {breakdown.map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="py-3 px-3 font-bold text-slate-900">{row.cat}</td>
                      <td className="py-3 px-3 font-medium text-slate-600">{row.total} Rooms</td>
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[11px]">
                          {row.avail} Available
                        </span>
                      </td>
                      <td className="py-3 px-3 font-medium text-blue-600">{row.occ} Occupied</td>
                      <td className="py-3 px-3 font-medium text-amber-600">{row.dirty} Cleaning</td>
                      <td className="py-3 px-3 font-mono font-bold text-slate-900">{formatMoney(row.rate, { showBoth: true })}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
      })()}

      {/* SUBTAB 4: DYNAMIC ARRIVALS QUEUE */}
      {subTab === 'ARRIVALS' && (() => {
        const expectedArrivals = bookings.filter(b => b.status === 'CONFIRMED');

        return (
          <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-4 shadow-2xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Today's Expected Arrivals ({expectedArrivals.length})
                </h3>
                <p className="text-xs text-slate-500">Active reservation check-ins for today</p>
              </div>
              <button
                onClick={() => openBookingWizardForRoom()}
                className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-semibold"
              >
                + Express Walk-In Check-In
              </button>
            </div>

            {expectedArrivals.length === 0 ? (
              <div className="py-12 text-center space-y-2 border border-dashed border-slate-200 rounded-xl">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
                <h4 className="text-xs font-bold text-slate-800">No arrivals scheduled</h4>
                <p className="text-[11px] text-slate-400">All {rooms.length} hotel rooms are available for walk-in guests</p>
                <button
                  onClick={() => openBookingWizardForRoom()}
                  className="mt-2 px-3.5 py-1.5 bg-blue-600 text-white text-xs font-semibold rounded-lg hover:bg-blue-700 transition-colors inline-flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Register Walk-in Guest</span>
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {expectedArrivals.map(b => (
                  <div key={b.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center">
                        {b.guest?.firstName ? b.guest.firstName[0] : 'G'}
                      </div>
                      <div>
                        <div className="font-bold text-slate-900 flex items-center gap-2">
                          <span>{b.guest ? `${b.guest.firstName} ${b.guest.lastName}` : 'Walk-in'}</span>
                          <span className="px-1.5 py-0.2 bg-blue-100 text-blue-800 rounded text-[9px] font-bold">Confirmed</span>
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {b.bookingReference} · Room {b.room?.roomNumber || '—'} ({b.room?.category || 'Standard'}) · In: {b.checkInDate}
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => openBookingWizardForRoom(b.roomId)}
                      className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-xs"
                    >
                      Check In Guest
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })()}

      {/* SUBTAB 5: DYNAMIC DEPARTURES QUEUE */}
      {subTab === 'DEPARTURES' && (() => {
        const departures = bookings.filter(b => b.status === 'CHECKED_IN');

        return (
          <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-4 shadow-2xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Today's Scheduled Departures ({departures.length})
                </h3>
                <p className="text-xs text-slate-500">Check-out status, folio payment collection, and housekeeping releases</p>
              </div>
            </div>

            {departures.length === 0 ? (
              <div className="py-12 text-center space-y-2 border border-dashed border-slate-200 rounded-xl">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
                <h4 className="text-xs font-bold text-slate-800">No departures due</h4>
                <p className="text-[11px] text-slate-400">All rooms in the hotel are vacant and available</p>
              </div>
            ) : (
              <div className="space-y-2">
                {departures.map(b => (
                  <div key={b.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-bold text-slate-900">
                        {b.guest?.firstName} {b.guest?.lastName} · Room {b.room?.roomNumber || '—'}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {b.bookingReference} · Out: {b.checkOutDate} · Balance: {formatMoney(b.totalNights * b.ratePerNight)}
                      </div>
                    </div>

                    <button
                      onClick={() => openCheckOutModal(b)}
                      className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg text-xs"
                    >
                      Process Check-Out
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })()}

      {/* SUBTAB 6: DYNAMIC IN-HOUSE GUESTS */}
      {subTab === 'IN_HOUSE' && (() => {
        const occupiedList = rooms.filter(r => r.status === 'OCCUPIED');

        return (
          <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-4 shadow-2xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Current In-House Occupants ({occupiedList.length})
                </h3>
                <p className="text-xs text-slate-500">All guests currently checked in and residing in the hotel</p>
              </div>
            </div>

            {occupiedList.length === 0 ? (
              <div className="py-12 text-center space-y-2 border border-dashed border-slate-200 rounded-xl">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
                <h4 className="text-xs font-bold text-slate-800">No in-house guests</h4>
                <p className="text-[11px] text-slate-400">0 rooms occupied · 100% of rooms are available for new arrivals</p>
                <button
                  onClick={() => openBookingWizardForRoom()}
                  className="mt-2 px-3.5 py-1.5 bg-blue-600 text-white text-xs font-semibold rounded-lg hover:bg-blue-700 transition-colors inline-flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Check In Walk-In Guest</span>
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {occupiedList.map(r => {
                  const b = bookings.find(bk => bk.id === r.currentBookingId);
                  const g = b?.guest;

                  return (
                    <div
                      key={r.id}
                      onClick={() => setSelectedRoom(r)}
                      className="p-3 bg-white hover:bg-blue-50/50 rounded-xl border border-slate-200 flex items-center justify-between text-xs cursor-pointer transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center">
                          {g ? g.firstName[0] : 'G'}
                        </div>
                        <div>
                          <div className="font-bold text-slate-900">
                            {g ? `${g.firstName} ${g.lastName}` : r.guestName || 'Occupant'} — Room {r.roomNumber} ({r.category})
                          </div>
                          <div className="text-[11px] text-slate-500">
                            {b ? `${b.bookingReference} · Departs ${b.checkOutDate}` : 'In-House'}
                          </div>
                        </div>
                      </div>

                      <span className="text-blue-600 font-semibold hover:underline">
                        View Dossier →
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      })()}
    </div>
  );
};
