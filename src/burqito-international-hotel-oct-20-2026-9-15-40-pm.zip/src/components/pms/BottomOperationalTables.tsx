import React from 'react';
import { useHotel } from '../../context/HotelContext.tsx';
import { Bed, CalendarDays, CheckCircle2, Clock, Sparkles, UserPlus } from 'lucide-react';

export const BottomOperationalTables: React.FC = () => {
  const {
    setSelectedRoom,
    rooms,
    bookings,
    housekeepingTasks,
    setActiveTab,
    openBookingWizardForRoom
  } = useHotel();

  const handleRoomClick = (roomNumber: string) => {
    const r = rooms.find(rm => rm.roomNumber === roomNumber);
    if (r) {
      setSelectedRoom(r);
    }
  };

  // Expected Arrivals from real bookings
  const expectedArrivals = bookings.filter(b => b.status === 'CONFIRMED');

  // Expected Departures from real checked in bookings
  const expectedDepartures = bookings.filter(b => b.status === 'CHECKED_IN');

  // Active Housekeeping Tasks or Dirty Rooms needing turnaround
  const dirtyRooms = rooms.filter(r => r.status === 'DIRTY' || r.cleaningStatus === 'NEEDS_CLEANING');

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 font-sans">
      {/* 1. Today's Arrivals */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-2xs flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-600" />
              <h4 className="text-sm font-bold text-slate-900">
                Today's Arrivals ({expectedArrivals.length})
              </h4>
            </div>
            <button
              onClick={() => setActiveTab('RESERVATIONS')}
              className="text-xs text-blue-600 hover:text-blue-700 font-semibold"
            >
              View all
            </button>
          </div>

          {expectedArrivals.length === 0 ? (
            <div className="py-8 text-center space-y-2 border border-dashed border-slate-200 rounded-xl my-1">
              <CheckCircle2 className="w-6 h-6 text-emerald-500 mx-auto" />
              <p className="text-xs font-semibold text-slate-700">No arrivals scheduled</p>
              <p className="text-[11px] text-slate-400">All rooms are available for new walk-ins</p>
              <button
                onClick={() => openBookingWizardForRoom()}
                className="mt-1 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded-lg text-xs font-semibold inline-flex items-center gap-1 transition-colors"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>+ Create Reservation</span>
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="text-[11px] text-slate-400 font-medium border-b border-slate-100">
                  <tr>
                    <th className="pb-2 font-medium">Ref</th>
                    <th className="pb-2 font-medium">Guest</th>
                    <th className="pb-2 font-medium">Room</th>
                    <th className="pb-2 font-medium text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {expectedArrivals.slice(0, 5).map(b => {
                    const r = rooms.find(rm => rm.id === b.roomId);
                    return (
                      <tr key={b.id} className="hover:bg-slate-50 transition-colors">
                        <td className="py-2.5 font-mono text-[11px] text-slate-500">
                          {b.bookingReference}
                        </td>
                        <td className="py-2.5 font-semibold text-slate-900">
                          {b.guest ? `${b.guest.firstName} ${b.guest.lastName}` : 'Walk-in Guest'}
                        </td>
                        <td className="py-2.5">
                          {r ? (
                            <button
                              onClick={() => handleRoomClick(r.roomNumber)}
                              className="font-mono text-blue-600 hover:underline font-bold"
                            >
                              {r.roomNumber}
                            </button>
                          ) : (
                            <span className="text-slate-400">-</span>
                          )}
                        </td>
                        <td className="py-2.5 text-right">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-50 text-blue-700 border border-blue-200">
                            {b.status}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* 2. Today's Departures */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-2xs flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <CalendarDays className="w-4 h-4 text-purple-600" />
              <h4 className="text-sm font-bold text-slate-900">
                Today's Departures ({expectedDepartures.length})
              </h4>
            </div>
            <button
              onClick={() => setActiveTab('RESERVATIONS')}
              className="text-xs text-blue-600 hover:text-blue-700 font-semibold"
            >
              View all
            </button>
          </div>

          {expectedDepartures.length === 0 ? (
            <div className="py-8 text-center space-y-1.5 border border-dashed border-slate-200 rounded-xl my-1">
              <CheckCircle2 className="w-6 h-6 text-emerald-500 mx-auto" />
              <p className="text-xs font-semibold text-slate-700">No departures due</p>
              <p className="text-[11px] text-slate-400">All active rooms are clear and available</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="text-[11px] text-slate-400 font-medium border-b border-slate-100">
                  <tr>
                    <th className="pb-2 font-medium">Ref</th>
                    <th className="pb-2 font-medium">Guest</th>
                    <th className="pb-2 font-medium">Room</th>
                    <th className="pb-2 font-medium text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {expectedDepartures.slice(0, 5).map(b => {
                    const r = rooms.find(rm => rm.id === b.roomId);
                    return (
                      <tr key={b.id} className="hover:bg-slate-50 transition-colors">
                        <td className="py-2.5 font-mono text-[11px] text-slate-500">
                          {b.bookingReference}
                        </td>
                        <td className="py-2.5 font-semibold text-slate-900">
                          {b.guest ? `${b.guest.firstName} ${b.guest.lastName}` : 'Guest'}
                        </td>
                        <td className="py-2.5">
                          {r ? (
                            <button
                              onClick={() => handleRoomClick(r.roomNumber)}
                              className="font-mono text-blue-600 hover:underline font-bold"
                            >
                              {r.roomNumber}
                            </button>
                          ) : (
                            <span className="text-slate-400">-</span>
                          )}
                        </td>
                        <td className="py-2.5 text-right">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                            Due Checkout
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* 3. Housekeeping Tasks & Turnaround */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-2xs flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <h4 className="text-sm font-bold text-slate-900">
                Housekeeping Turnaround ({housekeepingTasks.length + dirtyRooms.length})
              </h4>
            </div>
            <button
              onClick={() => setActiveTab('HOUSEKEEPING')}
              className="text-xs text-blue-600 hover:text-blue-700 font-semibold"
            >
              View all
            </button>
          </div>

          {housekeepingTasks.length === 0 && dirtyRooms.length === 0 ? (
            <div className="py-8 text-center space-y-1.5 border border-dashed border-slate-200 rounded-xl my-1">
              <CheckCircle2 className="w-6 h-6 text-emerald-500 mx-auto" />
              <p className="text-xs font-semibold text-slate-700">All rooms 100% clean</p>
              <p className="text-[11px] text-slate-400">No pending turnover or cleaning tasks</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="text-[11px] text-slate-400 font-medium border-b border-slate-100">
                  <tr>
                    <th className="pb-2 font-medium">Room</th>
                    <th className="pb-2 font-medium">Task</th>
                    <th className="pb-2 font-medium">Priority</th>
                    <th className="pb-2 font-medium text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {dirtyRooms.slice(0, 4).map(r => (
                    <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-2.5 font-mono font-semibold text-slate-900">
                        <button onClick={() => handleRoomClick(r.roomNumber)} className="text-blue-600 hover:underline">
                          {r.roomNumber}
                        </button>
                      </td>
                      <td className="py-2.5 text-slate-800">Turnaround Clean</td>
                      <td className="py-2.5">
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-50 text-amber-700">
                          Normal
                        </span>
                      </td>
                      <td className="py-2.5 text-right">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-amber-100 text-amber-800">
                          Needs Clean
                        </span>
                      </td>
                    </tr>
                  ))}
                  {housekeepingTasks.slice(0, 4).map(task => (
                    <tr key={task.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-2.5 font-mono font-semibold text-slate-900">
                        <button onClick={() => handleRoomClick(task.roomNumber)} className="text-blue-600 hover:underline">
                          {task.roomNumber}
                        </button>
                      </td>
                      <td className="py-2.5 text-slate-800">{task.taskType.replace(/_/g, ' ')}</td>
                      <td className="py-2.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          task.priority === 'HIGH' ? 'bg-rose-50 text-rose-700' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {task.priority}
                        </span>
                      </td>
                      <td className="py-2.5 text-right">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 text-slate-600">
                          {task.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
