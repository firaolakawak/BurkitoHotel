import React, { useState, useMemo } from 'react';
import { useHotel } from '../../context/HotelContext.tsx';
import { GUEST_PROFILES_DATA } from '../../data/guestData.ts';
import {
  Users,
  Search,
  Star,
  DollarSign,
  Heart,
  Calendar,
  Bed,
  ChevronRight,
  ShieldCheck,
  Phone,
  Mail,
  MapPin,
  Sparkles,
  Award
} from 'lucide-react';

export const GuestsDirectoryView: React.FC = () => {
  const { bookings, rooms, setSelectedRoom, setActiveTab, addToast, formatMoney, currency, exchangeRate, hotelInfo } = useHotel();
  const [selectedTier, setSelectedTier] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Extract all guests
  const guestList = useMemo(() => {
    return Object.entries(GUEST_PROFILES_DATA).map(([name, data]) => {
      const activeBooking = bookings.find(b => {
        const bName = b.guest ? `${b.guest.firstName} ${b.guest.lastName}` : '';
        return bName === name && b.status === 'CHECKED_IN';
      });

      const currentRoom = activeBooking ? rooms.find(r => r.id === activeBooking.roomId) : null;

      return {
        name,
        vipTier: data.vipTier,
        memberSince: data.memberSince,
        totalStaysCount: data.totalStaysCount,
        totalNightsCount: data.totalNightsCount,
        lifetimeSpend: data.lifetimeSpend,
        roomPreferences: data.roomPreferences,
        pastStays: data.pastStays,
        currentRoom,
        activeBooking
      };
    });
  }, [bookings, rooms]);

  const filteredGuests = useMemo(() => {
    return guestList.filter(g => {
      if (selectedTier !== 'ALL' && g.vipTier !== selectedTier) return false;
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase();
        const matchesName = g.name.toLowerCase().includes(q);
        const matchesPref = g.roomPreferences.preferredRoomCategory?.toLowerCase().includes(q);
        return matchesName || matchesPref;
      }
      return true;
    });
  }, [guestList, selectedTier, searchQuery]);

  const totalLifetimeSpend = useMemo(() => {
    return guestList.reduce((acc, g) => acc + g.lifetimeSpend, 0);
  }, [guestList]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">Guests Directory & CRM</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
              Burqito VIP Club
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">Guest loyalty tiers, personalized room preferences, and lifetime spend history in {currency}</p>
        </div>

        <div className="flex items-center gap-2">
          <div className="px-3.5 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 shadow-2xs flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-500" />
            <span>Total VIP Revenue: <strong>{formatMoney(totalLifetimeSpend, { showBoth: true })}</strong></span>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-3.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-medium text-slate-500">Total Registered Guests</div>
          <div className="text-xl font-bold text-slate-900 font-mono mt-1">{guestList.length} Guests</div>
          <div className="text-[10px] text-slate-400 mt-0.5">Profiles with stay records</div>
        </div>

        <div className="p-3.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-medium text-slate-500">Platinum Elite VIPs</div>
          <div className="text-xl font-bold text-purple-700 font-mono mt-1">
            {guestList.filter(g => g.vipTier === 'PLATINUM').length} Guests
          </div>
          <div className="text-[10px] text-purple-600 mt-0.5">Top tier hospitality status</div>
        </div>

        <div className="p-3.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-medium text-slate-500">Currently In-House</div>
          <div className="text-xl font-bold text-blue-600 font-mono mt-1">
            {guestList.filter(g => g.currentRoom).length} Guests
          </div>
          <div className="text-[10px] text-blue-600 mt-0.5">Floor 5 executive rooms</div>
        </div>

        <div className="p-3.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-medium text-slate-500">Average Lifetime Value</div>
          <div className="text-xl font-bold text-emerald-600 font-mono mt-1">
            AED {Math.round(totalLifetimeSpend / Math.max(1, guestList.length)).toLocaleString()}
          </div>
          <div className="text-[10px] text-emerald-600 mt-0.5">Per guest profile</div>
        </div>
      </div>

      {/* Sub Tabs & Search */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-4 space-y-4 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          {/* VIP Tier Tabs */}
          <div className="flex space-x-2 text-xs overflow-x-auto scrollbar-none">
            {[
              { id: 'ALL', label: 'All Guests' },
              { id: 'PLATINUM', label: 'Platinum VIP' },
              { id: 'GOLD', label: 'Gold VIP' },
              { id: 'SILVER', label: 'Silver VIP' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setSelectedTier(tab.id)}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                  selectedTier === tab.id
                    ? 'bg-blue-50 text-blue-700 border border-blue-200'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Search Bar */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by name or preference..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Guest Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredGuests.map(g => {
            const initials = g.name.split(' ').map(p => p[0]).join('').slice(0, 2);

            return (
              <div
                key={g.name}
                className="p-4 rounded-xl border border-slate-200/90 hover:border-blue-300 transition-all bg-white shadow-2xs flex flex-col justify-between space-y-3"
              >
                {/* Guest Identity & VIP Tier */}
                <div>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-blue-100 to-indigo-100 text-blue-700 font-bold text-sm flex items-center justify-center border border-blue-200 shrink-0">
                        {initials}
                      </div>
                      <div>
                        <div className="text-sm font-bold text-slate-900">{g.name}</div>
                        <div className="text-[11px] text-slate-400">Member since {g.memberSince}</div>
                      </div>
                    </div>

                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                      g.vipTier === 'PLATINUM'
                        ? 'bg-purple-50 text-purple-700 border-purple-200'
                        : g.vipTier === 'GOLD'
                        ? 'bg-amber-50 text-amber-700 border-amber-200'
                        : 'bg-slate-100 text-slate-700 border-slate-200'
                    }`}>
                      {g.vipTier} VIP
                    </span>
                  </div>

                  {/* Lifetime spend & stays */}
                  <div className="grid grid-cols-2 gap-2 mt-3 p-2 bg-slate-50 rounded-lg text-xs">
                    <div>
                      <div className="text-[10px] text-slate-500 uppercase tracking-wider">Lifetime Spend</div>
                      <div className="font-mono font-bold text-slate-900 mt-0.5">{formatMoney(g.lifetimeSpend)}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-500 uppercase tracking-wider">Total Stays</div>
                      <div className="font-mono font-bold text-slate-900 mt-0.5">{g.totalStaysCount} Stays ({g.totalNightsCount} nts)</div>
                    </div>
                  </div>

                  {/* Room Preferences Tag */}
                  <div className="mt-3 space-y-1.5 text-xs">
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                      <Heart className="w-3 h-3 text-rose-500" />
                      <span>Room Preferences</span>
                    </div>
                    <div className="text-[11px] text-slate-700 font-medium">
                      {g.roomPreferences.preferredRoomCategory} · {g.roomPreferences.temperaturePreference}
                    </div>
                    <div className="text-[10px] text-slate-500 line-clamp-1">
                      {g.roomPreferences.bedAndPillow}
                    </div>
                  </div>
                </div>

                {/* Footer Status & View History button */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                  {g.currentRoom ? (
                    <span className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                      In Room {g.currentRoom.roomNumber}
                    </span>
                  ) : (
                    <span className="text-[11px] text-slate-400">Past Guest</span>
                  )}

                  <button
                    onClick={() => {
                      if (g.currentRoom) {
                        setSelectedRoom(g.currentRoom);
                      } else {
                        // Select default room 502 to show this guest in drawer
                        const defaultRoom = rooms.find(r => r.roomNumber === '502') || rooms[0];
                        if (defaultRoom) setSelectedRoom(defaultRoom);
                      }
                      setActiveTab('PMS_GRID');
                      addToast({
                        type: 'info',
                        title: 'Guest Dossier Loaded',
                        message: `Opened ${g.name}'s guest history and preferences in Room Detail Drawer.`
                      });
                    }}
                    className="text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1 text-[11px] hover:underline"
                  >
                    <span>View Guest History</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
