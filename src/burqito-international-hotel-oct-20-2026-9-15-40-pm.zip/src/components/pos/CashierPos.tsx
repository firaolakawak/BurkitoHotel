import React, { useState, useMemo } from 'react';
import { useHotel } from '../../context/HotelContext.tsx';
import { POS_MENU_ITEMS, PosMenuItem, PosOrderItem } from '../../data/posMenuData.ts';
import {
  Utensils,
  Bell,
  ShoppingBag,
  Wine,
  Users,
  Sparkles,
  Search,
  Heart,
  Pencil,
  Trash2,
  Plus,
  Minus,
  CheckCircle2,
  Printer,
  CreditCard,
  Banknote,
  Bed,
  Wallet,
  MoreHorizontal,
  ArrowRight,
  Coffee,
  Soup,
  Salad,
  Pizza,
  Flame,
  Fish,
  Cake,
  GlassWater,
  Star,
  Leaf,
  X,
  Share2,
  Percent,
  Receipt,
  MapPin,
  Building
} from 'lucide-react';

export const CashierPos: React.FC = () => {
  const {
    rooms,
    postPosCharge,
    addToast,
    currency,
    exchangeRate,
    formatMoney,
    hotelInfo,
    menuItems
  } = useHotel();

  // Dining Mode (Top Horizontal Bar)
  const [diningMode, setDiningMode] = useState<
    'DINE_IN' | 'ROOM_SERVICE' | 'LAKE_TERRACE' | 'COFFEE_CEREMONY' | 'TAKE_AWAY' | 'BANQUET'
  >('DINE_IN');

  // Selected Category (Left Vertical Menu)
  const [selectedCategory, setSelectedCategory] = useState<string>('All Menu Items');

  // Quick Tag Filter (Above Menu Grid)
  const [tagFilter, setTagFilter] = useState<'ALL' | "Chef's Special" | 'Vegetarian' | 'Spicy'>('ALL');

  // Search Input
  const [searchQuery, setSearchQuery] = useState('');

  // Table & Guest State
  const [selectedTable, setSelectedTable] = useState<string>('12');
  const [guestCount, setGuestCount] = useState<number>(2);
  const [guestRoomNumber, setGuestRoomNumber] = useState<string>('502');
  const [guestName, setGuestName] = useState<string>('Arthur Pendelton');
  const [isChangeTableOpen, setIsChangeTableOpen] = useState(false);

  // Cart Tab: 'Current Order' vs 'Guest Details'
  const [cartTab, setCartTab] = useState<'ORDER' | 'GUEST'>('ORDER');

  // Selected Payment Method
  const [paymentMethod, setPaymentMethod] = useState<'CASH' | 'CARD' | 'ROOM_CHARGE' | 'OTHER'>('CARD');

  // Modals
  const [isNoteModalOpen, setIsNoteModalOpen] = useState(false);
  const [orderNote, setOrderNote] = useState('');
  const [isPrintReceiptOpen, setIsPrintReceiptOpen] = useState(false);

  // Initial Cart with signature Burqito International Hotel dishes
  const [orderItems, setOrderItems] = useState<PosOrderItem[]>([
    {
      id: 'ord-1',
      menuItem: POS_MENU_ITEMS.find(m => m.name.includes('Doro Wat')) || POS_MENU_ITEMS[0],
      quantity: 1,
      note: 'Mild spice with fresh Ayib cheese'
    },
    {
      id: 'ord-2',
      menuItem: POS_MENU_ITEMS.find(m => m.name.includes('Lake Hawassa')) || POS_MENU_ITEMS[1],
      quantity: 2,
      note: 'Crisp fried with lemon & karia'
    },
    {
      id: 'ord-3',
      menuItem: POS_MENU_ITEMS.find(m => m.name.includes('Coffee Ceremony')) || POS_MENU_ITEMS[4],
      quantity: 2,
      note: 'Organic Sidama beans with rue herb'
    },
    {
      id: 'ord-4',
      menuItem: POS_MENU_ITEMS.find(m => m.name.includes('Spris')) || POS_MENU_ITEMS[5],
      quantity: 2,
      note: 'Layered fresh avocado & mango'
    }
  ]);

  // Categories list matching screenshot & Burqito International Hotel dining
  const categories = [
    { id: 'All Menu Items', label: 'All Menu Items', icon: Utensils, color: 'text-blue-600' },
    { id: 'Ethiopian Specialties', label: 'Ethiopian Specials', icon: Flame, color: 'text-amber-600' },
    { id: 'Lake Hawassa Seafood', label: 'Hawassa Seafood', icon: Fish, color: 'text-blue-500' },
    { id: 'Grill & Barbecue', label: 'Grill & Steaks', icon: Flame, color: 'text-orange-500' },
    { id: 'Pizza & Pasta', label: 'Pizza & Pasta', icon: Pizza, color: 'text-amber-500' },
    { id: 'Breakfast', label: 'Breakfast', icon: Coffee, color: 'text-amber-600' },
    { id: 'Salads', label: 'Salads', icon: Salad, color: 'text-emerald-500' },
    { id: 'Soups', label: 'Soups', icon: Soup, color: 'text-rose-500' },
    { id: 'Vegetarian', label: 'Vegetarian / Fasting', icon: Leaf, color: 'text-emerald-600' },
    { id: 'Desserts', label: 'Desserts', icon: Cake, color: 'text-pink-500' },
    { id: 'Beverages', label: 'Beverages & Coffee', icon: GlassWater, color: 'text-cyan-500' },
  ];

  // Filter menu items
  const filteredMenuItems = useMemo(() => {
    const sourceList = menuItems && menuItems.length > 0 ? menuItems : POS_MENU_ITEMS;
    return sourceList.filter(item => {
      // Category filter
      if (selectedCategory !== 'All Menu Items') {
        if (selectedCategory === 'Vegetarian / Fasting') {
          if (!item.isVegetarian) return false;
        } else if (item.category !== selectedCategory) {
          return false;
        }
      }

      // Quick Tag Filter
      if (tagFilter !== 'ALL') {
        if (tagFilter === 'Vegetarian' && !item.isVegetarian) return false;
        if (tagFilter === 'Spicy' && !item.isSpicy) return false;
        if (tagFilter === "Chef's Special" && item.tag !== "Chef's Special") return false;
      }

      // Search Query
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase();
        return (
          item.name.toLowerCase().includes(q) ||
          item.description.toLowerCase().includes(q) ||
          item.category.toLowerCase().includes(q)
        );
      }

      return true;
    });
  }, [menuItems, selectedCategory, tagFilter, searchQuery]);

  // Cart Management
  const handleAddToCart = (menuItem: PosMenuItem) => {
    if (menuItem.isAvailable === false) {
      addToast({
        type: 'error',
        title: 'Item Sold Out (86\'d)',
        message: `"${menuItem.name}" is currently 86'd in the kitchen. Please check Menu Management to restock.`
      });
      return;
    }

    setOrderItems(prev => {
      const existingIndex = prev.findIndex(item => item.menuItem.id === menuItem.id);
      if (existingIndex >= 0) {
        const copy = [...prev];
        copy[existingIndex] = {
          ...copy[existingIndex],
          quantity: copy[existingIndex].quantity + 1
        };
        return copy;
      }
      return [
        ...prev,
        {
          id: `ord-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
          menuItem,
          quantity: 1,
          note: menuItem.defaultNote || 'Regular'
        }
      ];
    });

    addToast({
      type: 'info',
      title: 'Item Added',
      message: `${menuItem.name} added to Table ${selectedTable} order.`
    });
  };

  const handleUpdateQty = (orderId: string, delta: number) => {
    setOrderItems(prev =>
      prev
        .map(item => {
          if (item.id === orderId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as PosOrderItem[]
    );
  };

  const handleRemoveItem = (orderId: string) => {
    setOrderItems(prev => prev.filter(i => i.id !== orderId));
  };

  // Calculations in ETB with dual USD support
  const subtotal = useMemo(() => {
    return orderItems.reduce((sum, item) => sum + (item.menuItem.price * item.quantity), 0);
  }, [orderItems]);

  const serviceCharge = Number((subtotal * 0.10).toFixed(2)); // 10% Service Charge
  const tourismFee = orderItems.length > 0 ? 50.00 : 0.00; // ETB 50 Lake Hawassa Tourism & Eco Levy
  const vat = Number((subtotal * 0.15).toFixed(2)); // 15% Ethiopian VAT
  const total = Number((subtotal + serviceCharge + tourismFee + vat).toFixed(2));

  // Complete Order
  const handleCompleteOrder = async () => {
    if (orderItems.length === 0) {
      addToast({ type: 'warning', title: 'Empty Order', message: 'Please add items to complete order.' });
      return;
    }

    if (paymentMethod === 'ROOM_CHARGE') {
      await postPosCharge({
        roomNumber: guestRoomNumber,
        category: 'FOOD_BEVERAGE',
        description: `BIH Open Kitchen - Table ${selectedTable} (${orderItems.length} items)`,
        amount: total,
        serverName: 'Selamawit Haile'
      });
      addToast({
        type: 'success',
        title: 'Charged to Room Folio',
        message: `${formatMoney(total, { showBoth: true })} posted to Room ${guestRoomNumber} (${guestName}).`
      });
    } else {
      addToast({
        type: 'success',
        title: 'Order Paid & Dispatched',
        message: `Order for Table ${selectedTable} (${formatMoney(total, { showBoth: true })}) settled via ${paymentMethod}. Kitchen KDS notified.`
      });
    }

    // Reset with confirmation
    setOrderItems([]);
  };

  return (
    <div className="space-y-4">
      
      {/* 1. Dining Mode Tabs (Top Horizontal Bar) */}
      <div className="bg-white border border-slate-200/90 rounded-2xl px-4 py-1.5 shadow-xs flex items-center gap-6 overflow-x-auto scrollbar-none select-none">
        {[
          { id: 'DINE_IN', label: 'Dine In (Open Kitchen)', icon: Utensils },
          { id: 'LAKE_TERRACE', label: 'Lake Terrace Bar & Lounge', icon: Wine },
          { id: 'COFFEE_CEREMONY', label: 'Sidama Coffee Garden', icon: Coffee },
          { id: 'ROOM_SERVICE', label: 'Room Service & In-Room Dining', icon: Bell },
          { id: 'TAKE_AWAY', label: 'Take Away & Express', icon: ShoppingBag },
          { id: 'BANQUET', label: 'Banquet & Events Hall', icon: Users },
        ].map(mode => {
          const Icon = mode.icon;
          const isActive = diningMode === mode.id;

          return (
            <button
              key={mode.id}
              onClick={() => {
                setDiningMode(mode.id as any);
                if (mode.id === 'ROOM_SERVICE') {
                  setPaymentMethod('ROOM_CHARGE');
                }
              }}
              className={`py-2 px-3 text-xs font-semibold flex items-center gap-2 relative whitespace-nowrap transition-colors ${
                isActive
                  ? 'text-blue-600 font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-blue-600' : 'text-slate-400'}`} />
              <span>{mode.label}</span>
              {isActive && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600 rounded-full" />
              )}
            </button>
          );
        })}
      </div>

      {/* 2. Main POS Workspace: Category Sidebar + Menu Grid + Right Cart Folio */}
      <div className="flex flex-col lg:flex-row gap-4 items-start">
        
        {/* A. Category Sidebar (Vertical Left Menu) */}
        <div className="w-full lg:w-48 xl:w-52 bg-white border border-slate-200/90 rounded-2xl p-2.5 shadow-xs shrink-0 select-none space-y-0.5">
          {categories.map(cat => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.id;

            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium transition-all text-left ${
                  isSelected
                    ? 'bg-blue-50 text-blue-700 font-bold border-l-3 border-blue-600 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isSelected ? 'text-blue-600' : cat.color}`} />
                <span className="truncate">{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* B. Center Menu Products Workspace */}
        <div className="flex-1 space-y-3 min-w-0">
          
          {/* Quick Tag Pills Bar + Search Input */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-2.5 rounded-2xl border border-slate-200/90 shadow-2xs">
            {/* Quick Pills matching reference image */}
            <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto scrollbar-none">
              {(['ALL', "Chef's Special", 'Vegetarian', 'Spicy'] as const).map(tag => (
                <button
                  key={tag}
                  onClick={() => setTagFilter(tag)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                    tagFilter === tag
                      ? 'bg-blue-600 text-white shadow-2xs'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  {tag === 'ALL' ? 'All Items' : tag}
                </button>
              ))}
            </div>

            {/* Search within Menu */}
            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search dishes or drinks..."
                className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-500"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Menu Items Grid matching reference screenshot */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3.5">
            {filteredMenuItems.map(item => (
              <div
                key={item.id}
                onClick={() => handleAddToCart(item)}
                className={`group bg-white border rounded-2xl overflow-hidden shadow-2xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between relative ${
                  item.isAvailable === false
                    ? 'border-rose-200 opacity-65 bg-slate-50'
                    : 'border-slate-200/90 hover:border-blue-500/80'
                }`}
              >
                <div>
                  {/* Food Thumbnail Image */}
                  <div className="relative h-32 w-full overflow-hidden bg-slate-100">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

                    {/* 86'd Sold out badge */}
                    {item.isAvailable === false && (
                      <div className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded text-[10px] font-extrabold bg-rose-600 text-white shadow-md z-10 tracking-wider">
                        86'D · SOLD OUT
                      </div>
                    )}

                    {/* Quick Add Overlay on Hover */}
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/25">
                      <span className={`px-3 py-1.5 rounded-lg text-xs font-bold shadow-lg flex items-center gap-1.5 ${
                        item.isAvailable === false ? 'bg-slate-800 text-slate-200' : 'bg-blue-600 text-white'
                      }`}>
                        <Plus className="w-3.5 h-3.5" />
                        <span>{item.isAvailable === false ? 'Sold Out in Kitchen' : 'Add to Order'}</span>
                      </span>
                    </div>

                    {/* Favorite Heart Button */}
                    <button
                      type="button"
                      onClick={e => {
                        e.stopPropagation();
                        addToast({ type: 'info', title: 'Favorites', message: `${item.name} highlighted` });
                      }}
                      className="absolute top-2.5 right-2.5 p-1.5 rounded-full bg-black/40 backdrop-blur-xs text-white/90 hover:text-rose-400 transition-colors"
                    >
                      <Heart className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Card Content */}
                  <div className="p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <h4 className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-1">
                          {item.name}
                        </h4>
                        {item.isVegetarian && <Leaf className="w-3 h-3 text-emerald-600 shrink-0" />}
                        {item.isSpicy && <Flame className="w-3 h-3 text-rose-600 shrink-0" />}
                      </div>
                    </div>

                    {/* Price in ETB and USD */}
                    <div className="flex items-baseline gap-1.5 mt-1">
                      <span className="text-xs font-mono font-bold text-slate-900">
                        {formatMoney(item.price)}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {currency === 'ETB'
                          ? `($${(item.price / exchangeRate).toFixed(2)})`
                          : `(ETB ${item.price.toFixed(0)})`}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>

                {/* Bottom Tag Badge if available */}
                <div className="px-3 pb-3 pt-0">
                  {item.tag === "Chef's Special" && (
                    <span className="inline-block px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-50 text-rose-600 border border-rose-100">
                      Chef's Special
                    </span>
                  )}
                  {item.tag === 'Vegetarian' && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-600 border border-emerald-100">
                      <Leaf className="w-2.5 h-2.5" />
                      <span>Vegetarian</span>
                    </span>
                  )}
                  {item.tag === 'Spicy' && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-50 text-rose-600 border border-rose-100">
                      <Flame className="w-2.5 h-2.5" />
                      <span>Spicy</span>
                    </span>
                  )}
                </div>

              </div>
            ))}
          </div>

        </div>

        {/* C. Right-Hand Cart / Folio Panel matching screenshot */}
        <div className="w-full lg:w-[360px] xl:w-[390px] bg-white border border-slate-200/90 rounded-2xl p-4 shadow-xs flex flex-col justify-between shrink-0 select-none">
          
          <div>
            {/* Header: Table / Outlet info + Change Table Button */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600 shrink-0">
                  <Users className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-bold text-slate-900">Table {selectedTable}</span>
                    <span className="text-slate-400 text-xs">›</span>
                    <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-blue-50 text-blue-600">
                      {diningMode === 'ROOM_SERVICE' ? 'Room Service' : diningMode === 'LAKE_TERRACE' ? 'Lake Terrace' : 'Dine In'}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 font-medium">
                    {diningMode === 'ROOM_SERVICE' ? `Room ${guestRoomNumber} (${guestName})` : `${guestCount} Guests`}
                  </div>
                </div>
              </div>

              <button
                onClick={() => setIsChangeTableOpen(true)}
                className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-blue-600 transition-colors"
              >
                Change Table
              </button>
            </div>

            {/* Sub-tabs: Current Order vs Guest Details */}
            <div className="flex border-b border-slate-200 mt-3 text-xs font-semibold">
              <button
                onClick={() => setCartTab('ORDER')}
                className={`py-2 px-3 transition-colors relative ${
                  cartTab === 'ORDER' ? 'text-blue-600 font-bold' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <span>Current Order ({orderItems.length})</span>
                {cartTab === 'ORDER' && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600 rounded-full" />
                )}
              </button>

              <button
                onClick={() => setCartTab('GUEST')}
                className={`py-2 px-3 transition-colors relative ${
                  cartTab === 'GUEST' ? 'text-blue-600 font-bold' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <span>Guest Details</span>
                {cartTab === 'GUEST' && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600 rounded-full" />
                )}
              </button>
            </div>

            {/* Order Items List */}
            {cartTab === 'ORDER' ? (
              <div className="py-2 space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
                {orderItems.length > 0 ? (
                  orderItems.map(item => (
                    <div
                      key={item.id}
                      className="flex items-center justify-between text-xs py-1.5 border-b border-slate-50 last:border-none"
                    >
                      {/* Left: Qty Badge + Title & Modifiers */}
                      <div className="flex items-start gap-2.5 min-w-0">
                        <div className="w-6 h-6 rounded-md bg-slate-100 flex items-center justify-center font-mono font-bold text-slate-800 text-xs shrink-0 mt-0.5">
                          {item.quantity}
                        </div>
                        <div className="min-w-0">
                          <div className="font-bold text-slate-900 truncate">{item.menuItem.name}</div>
                          {item.note && (
                            <div className="text-[10px] text-slate-400 truncate">{item.note}</div>
                          )}
                        </div>
                      </div>

                      {/* Right: Price + Edit / Trash Icons */}
                      <div className="flex items-center gap-2.5 shrink-0 pl-2">
                        <div className="text-right">
                          <div className="font-mono font-bold text-slate-900 text-xs">
                            {formatMoney(item.menuItem.price * item.quantity)}
                          </div>
                          <div className="text-[9px] text-slate-400 font-mono">
                            {currency === 'ETB'
                              ? `$${((item.menuItem.price * item.quantity) / exchangeRate).toFixed(2)}`
                              : `ETB ${(item.menuItem.price * item.quantity).toFixed(0)}`}
                          </div>
                        </div>
                        
                        <button
                          onClick={() => {
                            const newQty = prompt(`Update quantity for ${item.menuItem.name}:`, String(item.quantity));
                            if (newQty && Number(newQty) > 0) {
                              handleUpdateQty(item.id, Number(newQty) - item.quantity);
                            }
                          }}
                          className="p-1 text-slate-400 hover:text-blue-600 rounded transition-colors"
                          title="Edit Quantity"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => handleRemoveItem(item.id)}
                          className="p-1 text-rose-400 hover:text-rose-600 rounded transition-colors"
                          title="Remove Item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-8 text-center text-xs text-slate-400">
                    No items in current order. Click any dish to add.
                  </div>
                )}

                {/* + Add Note Bar Button */}
                <button
                  onClick={() => setIsNoteModalOpen(true)}
                  className="w-full py-2 bg-blue-50/60 hover:bg-blue-50 border border-blue-200/60 rounded-xl text-blue-600 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors mt-2"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{orderNote ? `Note: ${orderNote}` : 'Add Kitchen Note'}</span>
                </button>
              </div>
            ) : (
              /* Guest Details Tab */
              <div className="p-3 bg-slate-50 rounded-xl mt-3 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Guest Name</span>
                  <span className="font-bold text-slate-900">{guestName}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Hotel Room</span>
                  <span className="font-bold text-blue-700 font-mono">Room {guestRoomNumber}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">VIP Status</span>
                  <span className="font-bold text-amber-600">Platinum VIP</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Active Room Folio</span>
                  <span className="font-mono text-slate-700 font-semibold">{formatMoney(8450, { showBoth: true })}</span>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Billing Summary & Checkout Controls */}
          <div className="pt-3 border-t border-slate-100 space-y-3 mt-2">
            
            {/* Price Breakdown */}
            <div className="space-y-1.5 text-xs">
              <div className="flex items-center justify-between text-slate-500">
                <span>Subtotal</span>
                <span className="font-mono font-semibold text-slate-800">{formatMoney(subtotal)}</span>
              </div>
              <div className="flex items-center justify-between text-slate-500">
                <span>Service Charge (10%)</span>
                <span className="font-mono font-semibold text-slate-800">{formatMoney(serviceCharge)}</span>
              </div>
              <div className="flex items-center justify-between text-slate-500">
                <span>Lake Tourism Levy</span>
                <span className="font-mono font-semibold text-slate-800">{formatMoney(tourismFee)}</span>
              </div>
              <div className="flex items-center justify-between text-slate-500">
                <span>Ethiopian VAT (15%)</span>
                <span className="font-mono font-semibold text-slate-800">{formatMoney(vat)}</span>
              </div>

              {/* Total Display */}
              <div className="flex items-baseline justify-between pt-2 border-t border-slate-200">
                <div>
                  <span className="text-sm font-bold text-slate-900">Total Due</span>
                  <div className="text-[10px] text-slate-400">
                    {currency === 'ETB' ? `≈ $${(total / exchangeRate).toFixed(2)} USD` : `≈ ETB ${total.toLocaleString()} ETB`}
                  </div>
                </div>
                <span className="text-xl font-bold font-mono text-slate-900 tracking-tight">
                  {formatMoney(total)}
                </span>
              </div>
            </div>

            {/* Quick Actions Row 1: % Discount + Split Bill + Print Bill */}
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => addToast({ type: 'info', title: 'Discount', message: 'Applied 10% Hotel Resident Discount.' })}
                className="py-1.5 px-2 bg-blue-50/50 hover:bg-blue-50 border border-slate-200 rounded-xl text-xs font-semibold text-blue-700 flex items-center justify-center gap-1 transition-colors"
              >
                <Percent className="w-3.5 h-3.5" />
                <span>Discount</span>
              </button>

              <button
                onClick={() => addToast({
                  type: 'info',
                  title: 'Split Bill',
                  message: `Split into 2 equal folios (${formatMoney(total / 2)} each).`
                })}
                className="py-1.5 px-2 bg-blue-50/50 hover:bg-blue-50 border border-slate-200 rounded-xl text-xs font-semibold text-blue-700 flex items-center justify-center gap-1 transition-colors"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Split Bill</span>
              </button>

              <button
                onClick={() => setIsPrintReceiptOpen(true)}
                className="py-1.5 px-2 bg-blue-50/50 hover:bg-blue-50 border border-slate-200 rounded-xl text-xs font-semibold text-blue-700 flex items-center justify-center gap-1 transition-colors"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Bill</span>
              </button>
            </div>

            {/* Payment Method Row 2: Cash + Card (selected blue) + Room Charge */}
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setPaymentMethod('CASH')}
                className={`py-2 px-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                  paymentMethod === 'CASH'
                    ? 'bg-[#2563EB] text-white shadow-xs'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Banknote className="w-4 h-4" />
                <span>Cash</span>
              </button>

              <button
                onClick={() => setPaymentMethod('CARD')}
                className={`py-2 px-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                  paymentMethod === 'CARD'
                    ? 'bg-[#2563EB] text-white shadow-xs'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <CreditCard className="w-4 h-4" />
                <span>Card</span>
              </button>

              <button
                onClick={() => setPaymentMethod('ROOM_CHARGE')}
                className={`py-2 px-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                  paymentMethod === 'ROOM_CHARGE'
                    ? 'bg-[#2563EB] text-white shadow-xs'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Bed className="w-4 h-4" />
                <span>Room Charge</span>
              </button>
            </div>

            {/* Secondary Row: Other Payment + More */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPaymentMethod('OTHER')}
                className={`flex-1 py-1.5 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                  paymentMethod === 'OTHER'
                    ? 'bg-blue-50 text-blue-700 border-blue-200'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Wallet className="w-3.5 h-3.5 text-slate-500" />
                <span>Telebirr / CBE Birr</span>
              </button>

              <button
                onClick={() => addToast({
                  type: 'info',
                  title: 'Burqito Payment Methods',
                  message: 'Supports Telebirr, Commercial Bank of Ethiopia (CBE), Visa/Mastercard, and Room Folio.'
                })}
                className="p-2 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl text-slate-400 transition-colors"
              >
                <MoreHorizontal className="w-4 h-4" />
              </button>
            </div>

            {/* Big Complete Order Button matching screenshot green button */}
            <button
              onClick={handleCompleteOrder}
              className="w-full py-3 bg-[#059669] hover:bg-emerald-700 text-white rounded-xl text-sm font-bold flex items-center justify-center gap-3 transition-colors shadow-sm active:scale-99"
            >
              <span>Complete Order</span>
              <span className="font-mono">({formatMoney(total)})</span>
              <ArrowRight className="w-4 h-4" />
            </button>

          </div>

        </div>

      </div>

      {/* Change Table & Room Modal */}
      {isChangeTableOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="font-bold text-slate-900 text-base">Select Table or Room</div>
              <button onClick={() => setIsChangeTableOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">Restaurant Table</label>
              <div className="grid grid-cols-4 gap-2">
                {['01', '04', '08', '12', '15', '18', '20', '24'].map(tbl => (
                  <button
                    key={tbl}
                    onClick={() => setSelectedTable(tbl)}
                    className={`py-2 rounded-xl text-xs font-bold border transition-colors ${
                      selectedTable === tbl
                        ? 'bg-blue-50 border-blue-600 text-blue-700'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    Table {tbl}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100">
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">Or Charge to Guest Room</label>
              <select
                value={guestRoomNumber}
                onChange={e => setGuestRoomNumber(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-800"
              >
                <option value="502">Room 502 (Executive Suite - Arthur Pendelton)</option>
                <option value="501">Room 501 (Deluxe King - Michael Scott)</option>
                <option value="408">Room 408 (Standard Double - Dr. Klaus Schmidt)</option>
                <option value="305">Room 305 (Executive Suite - David Miller)</option>
              </select>
            </div>

            <button
              onClick={() => setIsChangeTableOpen(false)}
              className="w-full py-2 bg-[#2563EB] hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors"
            >
              Confirm Selection
            </button>
          </div>
        </div>
      )}

      {/* Add Note Modal */}
      {isNoteModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-sm p-5 space-y-3 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="font-bold text-slate-900 text-sm">Add Kitchen Instruction</div>
              <button onClick={() => setIsNoteModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <textarea
              rows={3}
              placeholder="e.g. Extra spicy, dressing on the side, allergic to peanuts..."
              value={orderNote}
              onChange={e => setOrderNote(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-800 focus:outline-none focus:border-blue-500"
            />

            <button
              onClick={() => setIsNoteModalOpen(false)}
              className="w-full py-2 bg-[#2563EB] hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors"
            >
              Save Note
            </button>
          </div>
        </div>
      )}

      {/* Professional Printed Bill Modal (Burqito International Hotel Hawassa) */}
      {isPrintReceiptOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <Printer className="w-4 h-4 text-blue-600" />
                <span className="font-bold text-slate-900 text-sm">Official Guest Dining Receipt</span>
              </div>
              <button onClick={() => setIsPrintReceiptOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Receipt Preview */}
            <div className="bg-slate-50 p-4 rounded-xl border border-dashed border-slate-300 font-mono space-y-3 text-[11px]">
              <div className="text-center space-y-0.5 border-b border-slate-200 pb-2">
                <div className="font-bold text-xs text-slate-900">BURQITO INTERNATIONAL HOTEL (BIH)</div>
                <div className="text-slate-500">Hawassa, Sidama Region, Ethiopia</div>
                <div className="text-slate-500">Tel: +251 91 682 3984 / +251 90 966 9900</div>
                <div className="text-slate-400 text-[10px]">TIN: 0048192019 · VAT Reg: #ET-789021</div>
              </div>

              <div className="flex justify-between text-slate-600">
                <span>Date: 14 Oct 2025, 13:24</span>
                <span>Table: {selectedTable}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Server: Selamawit Haile</span>
                <span>Type: {diningMode}</span>
              </div>

              {/* Items */}
              <div className="border-t border-b border-slate-200 py-2 space-y-1">
                {orderItems.map(item => (
                  <div key={item.id} className="flex justify-between">
                    <span>{item.quantity}x {item.menuItem.name}</span>
                    <span className="font-bold">ETB {(item.menuItem.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>

              {/* Totals */}
              <div className="space-y-1">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal:</span>
                  <span>ETB {subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Service Charge (10%):</span>
                  <span>ETB {serviceCharge.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Lake Tourism Levy:</span>
                  <span>ETB {tourismFee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>VAT (15%):</span>
                  <span>ETB {vat.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold text-xs pt-1 border-t border-slate-300 text-slate-900">
                  <span>TOTAL DUE (ETB):</span>
                  <span>ETB {total.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold text-xs text-blue-700">
                  <span>TOTAL EQUIVALENT (USD):</span>
                  <span>${(total / exchangeRate).toFixed(2)} USD</span>
                </div>
              </div>

              <div className="text-center text-[10px] text-slate-400 pt-2 border-t border-slate-200">
                Ameseginalehu! Thank you for dining at Burqito International Hotel, Hawassa.
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => {
                  addToast({ type: 'success', title: 'Receipt Printed', message: 'Thermal receipt sent to kitchen & cashier printer.' });
                  setIsPrintReceiptOpen(false);
                }}
                className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold flex items-center justify-center gap-2"
              >
                <Printer className="w-4 h-4" />
                <span>Send to Thermal Printer</span>
              </button>
              <button
                onClick={() => setIsPrintReceiptOpen(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
