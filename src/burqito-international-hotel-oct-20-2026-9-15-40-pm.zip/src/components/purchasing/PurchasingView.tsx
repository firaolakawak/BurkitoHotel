import React, { useState, useMemo } from 'react';
import { useHotel } from '../../context/HotelContext.tsx';
import { PurchaseOrder, PurchaseOrderStatus } from '../../types/index.ts';
import {
  ShoppingCart,
  Search,
  Plus,
  Truck,
  CheckCircle2,
  Clock,
  AlertCircle,
  Building,
  DollarSign,
  Package,
  ArrowRight,
  Filter
} from 'lucide-react';

export const PurchasingView: React.FC = () => {
  const {
    purchaseOrders,
    setIsPurchaseOrderOpen,
    transitionPOStatus,
    addToast,
    formatMoney,
    currency,
    exchangeRate,
    hotelInfo
  } = useHotel();

  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredPOs = useMemo(() => {
    return purchaseOrders.filter(po => {
      if (statusFilter !== 'ALL' && po.status !== statusFilter) return false;
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase();
        return po.poNumber.toLowerCase().includes(q) || po.vendorName.toLowerCase().includes(q);
      }
      return true;
    });
  }, [purchaseOrders, statusFilter, searchQuery]);

  const totalCommittedSpend = useMemo(() => {
    return purchaseOrders.reduce((acc, po) => acc + po.totalAmount, 0);
  }, [purchaseOrders]);

  const pendingCount = purchaseOrders.filter(po => po.status === 'SENT' || po.status === 'PARTIALLY_RECEIVED').length;

  const handleReceiveStock = async (po: PurchaseOrder) => {
    const success = await transitionPOStatus(po.id, 'FULFILLED');
    if (success) {
      addToast({
        type: 'success',
        title: 'Goods Received & Stock Updated',
        message: `Inventory stock has been replenished across warehouse staging locations for ${po.poNumber}.`
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">Purchasing & Procurement</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
              Burqito Supply Chain
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">Automated vendor reorder cycles, purchase orders in {currency}, and Hawassa warehouse receiving</p>
        </div>

        <button
          onClick={() => setIsPurchaseOrderOpen(true)}
          className="px-4 py-2.5 bg-[#2563EB] hover:bg-blue-700 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-sm transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Create Purchase Order</span>
        </button>
      </div>

      {/* 4 KPI Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-3.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-medium text-slate-500">Active Purchase Orders</div>
          <div className="text-xl font-bold text-slate-900 font-mono mt-1">{purchaseOrders.length} Orders</div>
          <div className="text-[10px] text-slate-400 mt-0.5">Procurement lifecycle</div>
        </div>

        <div className="p-3.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-medium text-slate-500">Committed Procurement</div>
          <div className="text-xl font-bold text-emerald-600 font-mono mt-1">{formatMoney(totalCommittedSpend)}</div>
          <div className="text-[10px] text-emerald-600 mt-0.5">
            {currency === 'ETB' ? `≈ $${(totalCommittedSpend / exchangeRate).toFixed(0)} USD` : `≈ ETB ${totalCommittedSpend.toLocaleString()}`}
          </div>
        </div>

        <div className="p-3.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-medium text-slate-500">Inbound Shipments</div>
          <div className="text-xl font-bold text-blue-600 font-mono mt-1">{pendingCount} Shipments</div>
          <div className="text-[10px] text-blue-600 mt-0.5">Awaiting warehouse dock receiving</div>
        </div>

        <div className="p-3.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-medium text-slate-500">Approved Suppliers</div>
          <div className="text-xl font-bold text-purple-700 font-mono mt-1">5 Suppliers</div>
          <div className="text-[10px] text-purple-600 mt-0.5">Verified contracted vendors</div>
        </div>
      </div>

      {/* Sub Tabs & Search */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-4 space-y-4 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          {/* Status Sub Tabs */}
          <div className="flex space-x-2 text-xs overflow-x-auto scrollbar-none">
            {[
              { id: 'ALL', label: 'All Orders' },
              { id: 'SENT', label: 'In Transit / Sent' },
              { id: 'DRAFT', label: 'Draft' },
              { id: 'FULFILLED', label: 'Received & Stocked' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setStatusFilter(tab.id)}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                  statusFilter === tab.id
                    ? 'bg-blue-50 text-blue-700 border border-blue-200'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Search Bar */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search PO # or vendor..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* PO Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-100 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-2.5 px-3">PO Number</th>
                <th className="py-2.5 px-3">Vendor Name</th>
                <th className="py-2.5 px-3">Destination Hub</th>
                <th className="py-2.5 px-3">Created Date</th>
                <th className="py-2.5 px-3">Est. Delivery</th>
                <th className="py-2.5 px-3">Order Total</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPOs.map(po => {
                const isFulfilled = po.status === 'FULFILLED';
                const isSent = po.status === 'SENT';

                return (
                  <tr key={po.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-3 font-mono font-bold text-blue-600">
                      {po.poNumber}
                    </td>

                    <td className="py-3 px-3">
                      <div className="font-semibold text-slate-900">{po.vendorName}</div>
                      <div className="text-[11px] text-slate-400">{po.items.length} catalog line items</div>
                    </td>

                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700">
                        {po.targetWarehouse === 'MAIN_WAREHOUSE' ? 'Central Logistics Hub' : 'Floor Linen Closet'}
                      </span>
                    </td>

                    <td className="py-3 px-3 text-slate-600">
                      {new Date(po.createdAt).toLocaleDateString()}
                    </td>

                    <td className="py-3 px-3 text-slate-600 font-medium">
                      {po.expectedDeliveryDate}
                    </td>

                    <td className="py-3 px-3 font-mono font-bold text-slate-900">
                      AED {po.totalAmount.toLocaleString()}
                    </td>

                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold inline-flex items-center gap-1 ${
                        isFulfilled
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : isSent
                          ? 'bg-blue-50 text-blue-700 border border-blue-200'
                          : 'bg-amber-50 text-amber-700 border border-amber-200'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${isFulfilled ? 'bg-emerald-600' : isSent ? 'bg-blue-600' : 'bg-amber-600'}`} />
                        <span>{isFulfilled ? 'Stock Received' : isSent ? 'Inbound Transit' : 'Draft'}</span>
                      </span>
                    </td>

                    <td className="py-3 px-3 text-right">
                      {!isFulfilled ? (
                        <button
                          onClick={() => handleReceiveStock(po)}
                          className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-medium inline-flex items-center gap-1 shadow-2xs"
                        >
                          <Truck className="w-3 h-3" />
                          <span>Receive Stock</span>
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-400 font-medium flex items-center justify-end gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Fulfilled</span>
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
