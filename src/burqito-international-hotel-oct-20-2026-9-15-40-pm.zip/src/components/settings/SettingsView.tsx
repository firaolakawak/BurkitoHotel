import React, { useState, useRef } from 'react';
import { useHotel } from '../../context/HotelContext.tsx';
import {
  Settings,
  Building,
  DollarSign,
  Clock,
  Shield,
  Save,
  CheckCircle2,
  FileCode2,
  Globe,
  Phone,
  Mail,
  MapPin,
  Image as ImageIcon,
  Plus,
  Trash2,
  Upload
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const { addToast, setActiveTab, currency, setCurrency, exchangeRate, hotelInfo, updateHotelInfo, resetAllData } = useHotel();
  const [activeSubTab, setActiveSubTab] = useState<'GENERAL' | 'RATES' | 'TAX' | 'BLUEPRINT'>('GENERAL');

  const [hotelName, setHotelName] = useState(hotelInfo.name);
  const [city, setCity] = useState(hotelInfo.city);
  const [address, setAddress] = useState(hotelInfo.address);
  const [phone, setPhone] = useState(hotelInfo.phone);
  const [email, setEmail] = useState(hotelInfo.email);
  const [website, setWebsite] = useState(hotelInfo.website);
  const [logoInput, setLogoInput] = useState(hotelInfo.logo || '');
  const [photosList, setPhotosList] = useState<string[]>(hotelInfo.photos || [
    'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1000&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=1000&auto=format&fit=crop&q=80'
  ]);
  const [newPhotoUrl, setNewPhotoUrl] = useState('');

  const logoFileRef = useRef<HTMLInputElement | null>(null);
  const galleryFileRef = useRef<HTMLInputElement | null>(null);

  const [checkInTime, setCheckInTime] = useState('14:00');
  const [checkOutTime, setCheckOutTime] = useState('11:00');
  const [vatRate, setVatRate] = useState('15');
  const [serviceChargeRate, setServiceChargeRate] = useState('10');
  const [tourismFee, setTourismFee] = useState('50');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateHotelInfo({
      name: hotelName,
      city,
      address,
      phone,
      email,
      website,
      logo: logoInput,
      photos: photosList
    });
    addToast({
      type: 'success',
      title: 'Configuration Saved',
      message: 'Burqito International Hotel profile, logo, photo gallery, and currency parameters updated.'
    });
  };

  const handleLogoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      if (typeof event.target?.result === 'string') {
        setLogoInput(event.target.result);
        addToast({ type: 'success', title: 'Logo Uploaded', message: 'New hotel logo loaded successfully from device.' });
      }
    };
    reader.readAsDataURL(file);
  };

  const handleGalleryFilesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (typeof event.target?.result === 'string') {
          setPhotosList(prev => [...prev, event.target!.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
    addToast({ type: 'success', title: 'Pictures Uploaded', message: `${files.length} hotel picture(s) uploaded successfully from device.` });
  };

  const handleAddPhotoUrl = () => {
    if (!newPhotoUrl.trim()) return;
    setPhotosList(prev => [...prev, newPhotoUrl.trim()]);
    setNewPhotoUrl('');
    addToast({ type: 'success', title: 'Photo Added', message: 'New hotel picture URL added to gallery.' });
  };

  const handleRemovePhoto = (index: number) => {
    setPhotosList(prev => prev.filter((_, i) => i !== index));
    addToast({ type: 'info', title: 'Photo Removed', message: 'Picture removed from gallery.' });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">Hotel & System Settings</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
              Burqito International Hotel (BIH)
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">Global property profile for Hawassa, Ethiopia, file uploads for logo & hotel pictures, check-in policy, ETB/USD dual-currency & tax rules</p>
        </div>

        <button
          onClick={handleSave}
          className="px-4 py-2.5 bg-[#2563EB] hover:bg-blue-700 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-sm transition-colors"
        >
          <Save className="w-4 h-4" />
          <span>Save Changes</span>
        </button>
      </div>

      {/* Main Settings Card */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-5 space-y-5 shadow-2xs">
        {/* Sub Tabs */}
        <div className="flex space-x-2 text-xs border-b border-slate-100 pb-3">
          {[
            { id: 'GENERAL', label: 'Property Profile, Logo & Photos' },
            { id: 'RATES', label: 'Check-In Policy & Hours' },
            { id: 'TAX', label: 'Currencies & Taxes (ETB / USD)' },
            { id: 'BLUEPRINT', label: 'Database Blueprint' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => {
                if (tab.id === 'BLUEPRINT') {
                  setActiveTab('BLUEPRINT');
                } else {
                  setActiveSubTab(tab.id as any);
                }
              }}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                activeSubTab === tab.id
                  ? 'bg-blue-50 text-blue-700 border border-blue-200'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="space-y-5 max-w-3xl text-xs">
          {activeSubTab === 'GENERAL' && (
            <div className="space-y-5">
              {/* Logo & Branding Uploader (Device File Upload) */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <div className="font-bold text-slate-900 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ImageIcon className="w-4 h-4 text-blue-600" />
                    <span>Hotel Logo & Brand Icon (Device Upload)</span>
                  </div>
                  <span className="text-[11px] text-slate-500 font-normal">Supports PNG, JPG, SVG image files</span>
                </div>

                <div className="flex items-center gap-4">
                  <div className="w-20 h-20 rounded-xl overflow-hidden border border-slate-300 bg-white shadow-2xs shrink-0 flex items-center justify-center">
                    {logoInput ? (
                      <img src={logoInput} alt="Hotel Logo" className="w-full h-full object-cover" />
                    ) : (
                      <Building className="w-8 h-8 text-slate-400" />
                    )}
                  </div>
                  <div className="flex-1 space-y-2">
                    <input
                      type="file"
                      ref={logoFileRef}
                      onChange={handleLogoFileChange}
                      accept="image/*"
                      className="hidden"
                    />
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => logoFileRef.current?.click()}
                        className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold text-xs flex items-center gap-2 transition-colors shadow-2xs"
                      >
                        <Upload className="w-4 h-4" />
                        <span>Upload Logo from Device</span>
                      </button>
                      {logoInput && (
                        <button
                          type="button"
                          onClick={() => setLogoInput('')}
                          className="px-3 py-2.5 bg-white border border-slate-200 hover:bg-slate-50 text-rose-600 rounded-xl font-semibold text-xs transition-colors"
                        >
                          Remove
                        </button>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400 block">Clicking upload opens your computer file explorer to select any image file.</span>
                  </div>
                </div>
              </div>

              {/* Hotel Pictures Gallery Uploader (Device File Upload) */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <div className="font-bold text-slate-900 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ImageIcon className="w-4 h-4 text-blue-600" />
                    <span>Hotel Pictures & Exterior Gallery ({photosList.length})</span>
                  </div>
                  <span className="text-[11px] text-slate-500 font-normal">Upload photos from device</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {photosList.map((photo, idx) => (
                    <div key={idx} className="relative group rounded-lg overflow-hidden border border-slate-200 bg-white h-24">
                      <img src={photo} alt={`Hotel Pic ${idx + 1}`} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                      <button
                        type="button"
                        onClick={() => handleRemovePhoto(idx)}
                        className="absolute top-1 right-1 w-6 h-6 bg-rose-600 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-sm"
                        title="Delete photo"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                <input
                  type="file"
                  ref={galleryFileRef}
                  onChange={handleGalleryFilesChange}
                  accept="image/*"
                  multiple
                  className="hidden"
                />

                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => galleryFileRef.current?.click()}
                    className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold text-xs flex items-center gap-2 transition-colors shadow-2xs"
                  >
                    <Upload className="w-4 h-4" />
                    <span>Upload Hotel Pictures from Device</span>
                  </button>

                  <div className="flex-1 flex items-center gap-2">
                    <input
                      type="text"
                      value={newPhotoUrl}
                      onChange={e => setNewPhotoUrl(e.target.value)}
                      placeholder="Or paste image URL..."
                      className="flex-1 bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono"
                    />
                    <button
                      type="button"
                      onClick={handleAddPhotoUrl}
                      className="px-3 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg font-semibold text-xs transition-colors"
                    >
                      Add URL
                    </button>
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Hotel Property Name</label>
                <input
                  type="text"
                  value={hotelName}
                  onChange={e => setHotelName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500 font-semibold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">City & Region</label>
                  <input
                    type="text"
                    value={city}
                    onChange={e => setCity(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Country</label>
                  <input
                    type="text"
                    value="Ethiopia"
                    disabled
                    className="w-full bg-slate-100 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-600 cursor-not-allowed"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Physical Address</label>
                <input
                  type="text"
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Official Hotel Phone</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Reservation Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Hotel Website Reference</label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={website}
                    onChange={e => setWebsite(e.target.value)}
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                  <a
                    href={website}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-2 bg-blue-50 text-blue-700 border border-blue-200 rounded-lg text-xs font-semibold hover:bg-blue-100 flex items-center gap-1.5"
                  >
                    <Globe className="w-3.5 h-3.5" />
                    <span>Visit Website</span>
                  </a>
                </div>
              </div>
            </div>
          )}

          {activeSubTab === 'RATES' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Standard Check-In Time</label>
                  <input
                    type="time"
                    value={checkInTime}
                    onChange={e => setCheckInTime(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Standard Check-Out Time</label>
                  <input
                    type="time"
                    value={checkOutTime}
                    onChange={e => setCheckOutTime(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200 text-blue-900 text-[11px] space-y-1">
                <div className="font-bold">Burqito International Hotel Policy:</div>
                <div>24-Hour flexible front desk check-in is supported for late flight arrivals at Awassa Airport (22.8 km away).</div>
              </div>
            </div>
          )}

          {activeSubTab === 'TAX' && (
            <div className="space-y-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Primary Operating Currency</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setCurrency('ETB')}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      currency === 'ETB'
                        ? 'bg-blue-50 border-blue-600 text-blue-900 ring-1 ring-blue-600'
                        : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="font-bold flex items-center justify-between">
                      <span>🇪🇹 ETB (Ethiopian Birr)</span>
                      {currency === 'ETB' && <CheckCircle2 className="w-4 h-4 text-blue-600" />}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">Primary currency for local guests and Hawassa outlets</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setCurrency('USD')}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      currency === 'USD'
                        ? 'bg-blue-50 border-blue-600 text-blue-900 ring-1 ring-blue-600'
                        : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="font-bold flex items-center justify-between">
                      <span>🇺🇸 USD (US Dollar)</span>
                      {currency === 'USD' && <CheckCircle2 className="w-4 h-4 text-blue-600" />}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">International business & diplomatic guest billing</div>
                  </button>
                </div>
                <div className="text-[11px] text-slate-500 mt-1.5">
                  Current Official Exchange Rate: <strong>1 USD = {exchangeRate} ETB</strong>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Ethiopian VAT (%)</label>
                  <input
                    type="number"
                    value={vatRate}
                    onChange={e => setVatRate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">Standard 15% rate</span>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Service Charge (%)</label>
                  <input
                    type="number"
                    value={serviceChargeRate}
                    onChange={e => setServiceChargeRate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">Staff tip pool (10%)</span>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Lake Tourism Levy (ETB / night)</label>
                  <input
                    type="number"
                    value={tourismFee}
                    onChange={e => setTourismFee(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">Hawassa municipal levy</span>
                </div>
              </div>
            </div>
          )}

          <div className="mt-8 pt-6 border-t border-red-100 bg-red-50/50 p-4 rounded-xl border">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-xs font-bold text-red-900">Danger Zone: Reset All Data & Clear Datasets</h3>
                <p className="text-[11px] text-red-700 mt-0.5">Completely remove all data, bookings, inventory, rooms, staff, and records from both frontend and backend for a clean slate.</p>
              </div>
              <button
                type="button"
                onClick={async () => {
                  if (window.confirm('Are you sure you want to completely wipe all data and datasets from frontend and backend? This action cannot be undone.')) {
                    await resetAllData();
                  }
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-lg transition-colors shadow-2xs whitespace-nowrap"
              >
                Reset All Datasets
              </button>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-end">
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold text-xs transition-colors shadow-2xs"
            >
              Save Configuration
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
