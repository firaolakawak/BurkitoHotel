import React, { useState, useMemo } from 'react';
import { useHotel } from '../../context/HotelContext.tsx';
import {
  Banknote,
  DollarSign,
  TrendingUp,
  Download,
  CreditCard,
  Receipt,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  PieChart
} from 'lucide-react';

export const FinanceView: React.FC = () => {
  const { bookings, kpis, rooms, addToast, formatMoney, currency, exchangeRate, hotelInfo } = useHotel();
  const [subTab, setSubTab] = useState<'REVENUE' | 'LEDGER' | 'TAX'>('REVENUE');

  const totalRoomRevenue = 328000; // Daily room revenue in ETB
  const posRevenue = 115300; // Current shift POS revenue in ETB
  const totalGross = totalRoomRevenue + posRevenue;

  const handleExport = () => {
    addToast({
      type: 'success',
      title: 'Financial Audit Exported',
      message: 'Burqito International Hotel daily revenue ledger and tax closing data exported to CSV format.'
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">Finance & Revenue Management</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
              Burqito International Hotel (BIH)
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">Daily hotel revenue accounting, room folio settlements, and Ethiopian VAT & service charge ledger</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="px-4 py-2.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-2 shadow-2xs transition-colors"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Export Financial Ledger</span>
          </button>
        </div>
      </div>

      {/* 4 Financial KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-3.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-medium text-slate-500">Gross Hotel Revenue</div>
          <div className="text-xl font-bold text-slate-900 font-mono mt-1">
            {formatMoney(totalGross)}
          </div>
          <div className="text-[10px] text-emerald-600 mt-0.5 font-semibold flex items-center gap-0.5">
            <TrendingUp className="w-3 h-3" />
            <span>+14.8% vs last month · {currency === 'ETB' ? `≈ $${(totalGross / exchangeRate).toFixed(0)} USD` : `≈ ETB ${totalGross.toLocaleString()}`}</span>
          </div>
        </div>

        <div className="p-3.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-medium text-slate-500">Room Revenue (PMS)</div>
          <div className="text-xl font-bold text-blue-600 font-mono mt-1">
            {formatMoney(totalRoomRevenue)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">
            Avg. ADR: {formatMoney(6800)}
          </div>
        </div>

        <div className="p-3.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-medium text-slate-500">Food & Beverage (POS)</div>
          <div className="text-xl font-bold text-emerald-600 font-mono mt-1">
            {formatMoney(posRevenue)}
          </div>
          <div className="text-[10px] text-emerald-600 mt-0.5">Across 4 Hawassa outlets</div>
        </div>

        <div className="p-3.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-medium text-slate-500">Ethiopian VAT (15%) & Service</div>
          <div className="text-xl font-bold text-slate-900 font-mono mt-1">
            {formatMoney(Math.round(totalGross * 0.15))}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">15% Standard Ethiopian VAT</div>
        </div>
      </div>

      {/* Sub Tabs & Transaction Ledger */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-4 space-y-4 shadow-2xs">
        <div className="flex space-x-2 text-xs border-b border-slate-100 pb-3">
          {[
            { id: 'REVENUE', label: 'Revenue Ledger' },
            { id: 'LEDGER', label: 'Folio Invoicing Balances' },
            { id: 'TAX', label: 'Tax & Municipal Surcharges' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setSubTab(tab.id as any)}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                subTab === tab.id
                  ? 'bg-blue-50 text-blue-700 border border-blue-200'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Ledger Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-100 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-2.5 px-3">Transaction Date</th>
                <th className="py-2.5 px-3">Folio Ref / Account</th>
                <th className="py-2.5 px-3">Revenue Category</th>
                <th className="py-2.5 px-3">Department Outlet</th>
                <th className="py-2.5 px-3">Amount</th>
                <th className="py-2.5 px-3">Payment Method</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {[
                { date: '14 Oct 2025, 14:15', folio: '#RES-45872 (Room 502)', cat: 'Room Lodging', outlet: 'Front Desk', amt: 13600, method: 'Credit Card (Visa)', status: 'Captured' },
                { date: '14 Oct 2025, 15:30', folio: '#ORD-POS-892', cat: 'F&B Dining', outlet: 'BIH Open Kitchen Restaurant', amt: 2240, method: 'Room Charge (Room 502)', status: 'Posted to Folio' },
                { date: '14 Oct 2025, 16:00', folio: '#RES-45873 (Room 505)', cat: 'Room Lodging', outlet: 'Front Desk', amt: 20400, method: 'Corporate Direct Billing', status: 'Approved' },
                { date: '14 Oct 2025, 17:20', folio: '#ORD-POS-893', cat: 'Bar & Lounge', outlet: 'Lake Hawassa Terrace Bar', amt: 1450, method: 'Telebirr', status: 'Settled' },
                { date: '14 Oct 2025, 18:45', folio: '#ORD-COF-104', cat: 'Coffee Garden', outlet: 'Sidama Coffee Ceremony', amt: 720, method: 'Room Charge (Room 523)', status: 'Posted to Folio' }
              ].map((tx, idx) => (
                <tr key={idx} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-3 text-slate-600 font-medium">{tx.date}</td>
                  <td className="py-3 px-3 font-semibold text-slate-900">{tx.folio}</td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-50 text-blue-700 border border-blue-200">
                      {tx.cat}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-600">{tx.outlet}</td>
                  <td className="py-3 px-3 font-mono font-bold text-slate-900">
                    {formatMoney(tx.amt, { showBoth: true })}
                  </td>
                  <td className="py-3 px-3 text-slate-600">{tx.method}</td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 inline-flex items-center gap-1">
                      <CheckCircle2 className="w-2.5 h-2.5" />
                      <span>{tx.status}</span>
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
