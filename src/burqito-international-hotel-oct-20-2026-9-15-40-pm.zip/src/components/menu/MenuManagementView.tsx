import React, { useState, useMemo } from 'react';
import { useHotel } from '../../context/HotelContext.tsx';
import { PosMenuItem } from '../../data/posMenuData.ts';
import {
  UtensilsCrossed,
  Plus,
  Search,
  Filter,
  SlidersHorizontal,
  Flame,
  Leaf,
  DollarSign,
  Clock,
  Coffee,
  Fish,
  Pizza,
  Wine,
  CheckCircle2,
  AlertOctagon,
  Percent,
  Edit3,
  Trash2,
  X,
  Save,
  Check,
  Star,
  Printer,
  TrendingUp,
  Tag,
  Soup,
  Salad,
  Cake,
  GlassWater,
  Sparkles,
  Layers
} from 'lucide-react';

const CATEGORIES = [
  'All Menu Items',
  'Ethiopian Specialties',
  'Lake Hawassa Seafood',
  'Grill & Barbecue',
  'Pizza & Pasta',
  'Breakfast',
  'Salads',
  'Soups',
  'Vegetarian',
  'Desserts',
  'Beverages'
];

const KITCHEN_STATIONS = [
  'ALL',
  'Hot Kitchen',
  'Fish Station',
  'Grill Station',
  'Coffee Counter',
  'Bar & Cellar',
  'Pastry & Bakery',
  'Cold Larder'
];

const PRESET_IMAGES = [
  { label: 'Doro Wat with Injera', url: 'https://images.unsplash.com/photo-1541518763669-27fef04b14ea?w=400&auto=format&fit=crop&q=80' },
  { label: 'Fresh Lake Tilapia Fish', url: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=400&auto=format&fit=crop&q=80' },
  { label: 'Sidama Beef Tibs', url: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=400&auto=format&fit=crop&q=80' },
  { label: 'Claypot Shiro Tegabino', url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&auto=format&fit=crop&q=80' },
  { label: 'Sidama Coffee Ceremony', url: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=400&auto=format&fit=crop&q=80' },
  { label: 'Layered Fruit Spris Juice', url: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?w=400&auto=format&fit=crop&q=80' },
  { label: 'Burqito Classic Burger', url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&auto=format&fit=crop&q=80' },
  { label: 'Wood-fired Pizza', url: 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=400&auto=format&fit=crop&q=80' },
  { label: 'Grilled Steak', url: 'https://images.unsplash.com/photo-1558030006-450675393462?w=400&auto=format&fit=crop&q=80' },
  { label: 'Cold Ethiopian Beer', url: 'https://images.unsplash.com/photo-1608270192799-59e8f8b89410?w=400&auto=format&fit=crop&q=80' }
];

export const MenuManagementView: React.FC = () => {
  const {
    menuItems,
    addMenuItem,
    updateMenuItem,
    deleteMenuItem,
    toggleMenuItemAvailability,
    bulkUpdateMenuPrices,
    formatMoney,
    currency,
    exchangeRate,
    addToast
  } = useHotel();

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All Menu Items');
  const [selectedStation, setSelectedStation] = useState<string>('ALL');
  const [selectedAvailability, setSelectedAvailability] = useState<'ALL' | 'IN_STOCK' | 'SOLD_OUT'>('ALL');
  const [selectedTag, setSelectedTag] = useState<string>('ALL');
  const [viewMode, setViewMode] = useState<'GRID' | 'TABLE'>('GRID');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<PosMenuItem | null>(null);
  const [isBulkPriceModalOpen, setIsBulkPriceModalOpen] = useState(false);
  const [bulkAdjustmentValue, setBulkAdjustmentValue] = useState<number>(10);
  const [bulkAdjustmentType, setBulkAdjustmentType] = useState<'PERCENT' | 'FIXED'>('PERCENT');
  const [bulkTargetCategory, setBulkTargetCategory] = useState<string>('ALL');

  // Form State for Add / Edit
  const [formName, setFormName] = useState('');
  const [formPriceETB, setFormPriceETB] = useState<number>(550);
  const [formCostPriceETB, setFormCostPriceETB] = useState<number>(200);
  const [formCategory, setFormCategory] = useState<string>('Ethiopian Specialties');
  const [formDescription, setFormDescription] = useState('');
  const [formImage, setFormImage] = useState(PRESET_IMAGES[0].url);
  const [formKitchenStation, setFormKitchenStation] = useState<'Hot Kitchen' | 'Grill Station' | 'Fish Station' | 'Bar & Cellar' | 'Coffee Counter' | 'Pastry & Bakery' | 'Cold Larder'>('Hot Kitchen');
  const [formPrepTime, setFormPrepTime] = useState<number>(20);
  const [formTag, setFormTag] = useState<string>("Chef's Special");
  const [formIsVegetarian, setFormIsVegetarian] = useState(false);
  const [formIsSpicy, setFormIsSpicy] = useState(false);
  const [formIsAvailable, setFormIsAvailable] = useState(true);
  const [formDefaultNote, setFormDefaultNote] = useState('');
  const [formSku, setFormSku] = useState('FB-001');

  const openAddModal = () => {
    setFormName('');
    setFormPriceETB(550);
    setFormCostPriceETB(210);
    setFormCategory('Ethiopian Specialties');
    setFormDescription('Freshly prepared dish with authentic Ethiopian spices and herbs.');
    setFormImage(PRESET_IMAGES[0].url);
    setFormKitchenStation('Hot Kitchen');
    setFormPrepTime(20);
    setFormTag("Chef's Special");
    setFormIsVegetarian(false);
    setFormIsSpicy(false);
    setFormIsAvailable(true);
    setFormDefaultNote('Regular spice with Injera');
    setFormSku('FB-001');
    setIsAddModalOpen(true);
  };

  const openEditModal = (item: PosMenuItem) => {
    setEditingItem(item);
    setFormName(item.name);
    setFormPriceETB(item.price);
    setFormCostPriceETB(item.costPrice || Math.round(item.price * 0.38));
    setFormCategory(item.category);
    setFormDescription(item.description);
    setFormImage(item.image);
    setFormKitchenStation((item.kitchenStation as any) || 'Hot Kitchen');
    setFormPrepTime(item.prepTimeMinutes || 18);
    setFormTag(item.tag || '');
    setFormIsVegetarian(item.isVegetarian || false);
    setFormIsSpicy(item.isSpicy || false);
    setFormIsAvailable(item.isAvailable !== false);
    setFormDefaultNote(item.defaultNote || '');
    setFormSku(item.linkedInventorySku || 'FB-001');
  };

  const handleSaveAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      addToast({ type: 'error', title: 'Invalid Dish Name', message: 'Please provide a name for the menu item.' });
      return;
    }

    addMenuItem({
      name: formName.trim(),
      price: Number(formPriceETB),
      costPrice: Number(formCostPriceETB),
      category: formCategory,
      description: formDescription,
      image: formImage,
      kitchenStation: formKitchenStation,
      prepTimeMinutes: formPrepTime,
      tag: formTag ? (formTag as any) : undefined,
      isVegetarian: formIsVegetarian,
      isSpicy: formIsSpicy,
      isAvailable: formIsAvailable,
      defaultNote: formDefaultNote,
      linkedInventorySku: formSku,
      outlets: ['BIH Lake Terrace Bar', 'Room Service & Minibar', 'Main Dining Hall']
    });

    setIsAddModalOpen(false);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;

    updateMenuItem(editingItem.id, {
      name: formName.trim(),
      price: Number(formPriceETB),
      costPrice: Number(formCostPriceETB),
      category: formCategory,
      description: formDescription,
      image: formImage,
      kitchenStation: formKitchenStation,
      prepTimeMinutes: formPrepTime,
      tag: formTag ? (formTag as any) : undefined,
      isVegetarian: formIsVegetarian,
      isSpicy: formIsSpicy,
      isAvailable: formIsAvailable,
      defaultNote: formDefaultNote,
      linkedInventorySku: formSku
    });

    setEditingItem(null);
  };

  // Filtered Menu Items
  const filteredItems = useMemo(() => {
    return menuItems.filter(item => {
      // Category filter
      if (selectedCategory !== 'All Menu Items') {
        if (selectedCategory === 'Vegetarian') {
          if (!item.isVegetarian) return false;
        } else if (item.category !== selectedCategory) {
          return false;
        }
      }

      // Kitchen Station
      if (selectedStation !== 'ALL' && item.kitchenStation !== selectedStation) {
        return false;
      }

      // Availability (86'd vs In Stock)
      if (selectedAvailability === 'IN_STOCK' && item.isAvailable === false) return false;
      if (selectedAvailability === 'SOLD_OUT' && item.isAvailable !== false) return false;

      // Tag filter
      if (selectedTag !== 'ALL') {
        if (selectedTag === 'Vegetarian' && !item.isVegetarian) return false;
        if (selectedTag === 'Spicy' && !item.isSpicy) return false;
        if (selectedTag === "Chef's Special" && item.tag !== "Chef's Special") return false;
      }

      // Search Query
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase();
        return (
          item.name.toLowerCase().includes(q) ||
          item.description.toLowerCase().includes(q) ||
          item.category.toLowerCase().includes(q) ||
          (item.linkedInventorySku && item.linkedInventorySku.toLowerCase().includes(q))
        );
      }

      return true;
    });
  }, [menuItems, selectedCategory, selectedStation, selectedAvailability, selectedTag, searchQuery]);

  // Derived KPIs
  const totalItemsCount = menuItems.length;
  const inStockCount = menuItems.filter(i => i.isAvailable !== false).length;
  const soldOutCount = menuItems.filter(i => i.isAvailable === false).length;
  const ethiopianCount = menuItems.filter(i => i.category.includes('Ethiopian') || i.category.includes('Hawassa') || i.category.includes('Coffee')).length;
  
  const avgMargin = useMemo(() => {
    if (menuItems.length === 0) return 0;
    const margins = menuItems.map(item => {
      const cost = item.costPrice || Math.round(item.price * 0.38);
      if (item.price <= 0) return 0;
      return Math.round(((item.price - cost) / item.price) * 100);
    });
    return Math.round(margins.reduce((a, b) => a + b, 0) / margins.length);
  }, [menuItems]);

  const avgDishPriceETB = totalItemsCount > 0
    ? Math.round(menuItems.reduce((acc, i) => acc + i.price, 0) / totalItemsCount)
    : 0;

  const handleApplyBulkPrice = () => {
    bulkUpdateMenuPrices(
      bulkTargetCategory,
      bulkAdjustmentValue,
      bulkAdjustmentType === 'PERCENT'
    );
    setIsBulkPriceModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* 1. Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">Menu Management</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
              Burqito F&B Outlets · Hawassa
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Food & Beverage catalog for Lake Terrace Bar, Sidama Coffee Lounge & Traditional Fish House · Instant 86'd stock controls and dual ETB/USD pricing
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={() => setIsBulkPriceModalOpen(true)}
            className="px-3.5 py-2.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors shadow-2xs"
          >
            <TrendingUp className="w-4 h-4 text-slate-500" />
            <span>Bulk Price Adjustment</span>
          </button>

          <button
            onClick={() => {
              window.print();
              addToast({ type: 'info', title: 'Kitchen Menu Export', message: 'Print dialog triggered for F&B preparation sheet.' });
            }}
            className="px-3.5 py-2.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors shadow-2xs"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            <span>Print Menu</span>
          </button>

          <button
            onClick={openAddModal}
            className="px-4 py-2.5 bg-[#2563EB] hover:bg-blue-700 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Menu Item</span>
          </button>
        </div>
      </div>

      {/* 2. KPI Metrics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Total Menu Items</div>
          <div className="text-2xl font-bold text-slate-900 mt-1 font-mono">{totalItemsCount}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Across 8 Categories</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-semibold text-emerald-700 uppercase tracking-wider">In Stock / Live</div>
          <div className="text-2xl font-bold text-emerald-600 mt-1 font-mono">{inStockCount}</div>
          <div className="text-[11px] text-emerald-600 mt-0.5 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            <span>Available on POS</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-semibold text-rose-700 uppercase tracking-wider">86'd / Sold Out</div>
          <div className="text-2xl font-bold text-rose-600 mt-1 font-mono">{soldOutCount}</div>
          <div className="text-[11px] text-rose-600 mt-0.5 flex items-center gap-1">
            <AlertOctagon className="w-3 h-3" />
            <span>Kitchen Restricted</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-semibold text-amber-700 uppercase tracking-wider">Ethiopian & Lake</div>
          <div className="text-2xl font-bold text-amber-700 mt-1 font-mono">{ethiopianCount}</div>
          <div className="text-[11px] text-amber-700 mt-0.5">Local Specialties</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Average Dish Margin</div>
          <div className="text-2xl font-bold text-blue-600 mt-1 font-mono">{avgMargin}%</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Gross Food Margin</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Avg Menu Price</div>
          <div className="text-lg font-bold text-slate-900 mt-1 font-mono truncate">
            {formatMoney(avgDishPriceETB)}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5 font-mono">
            {currency === 'ETB' ? `≈ $${(avgDishPriceETB / exchangeRate).toFixed(2)} USD` : `≈ ETB ${avgDishPriceETB}`}
          </div>
        </div>
      </div>

      {/* 3. Search & Category Filters */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-2xs space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by dish name, recipe description, SKU or station..."
              className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-4 py-2 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* View Toggle */}
          <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200 shrink-0">
            <button
              onClick={() => setViewMode('GRID')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                viewMode === 'GRID' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Cards View
            </button>
            <button
              onClick={() => setViewMode('TABLE')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                viewMode === 'TABLE' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Table View
            </button>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white font-semibold shadow-2xs'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200/60'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Secondary Filters: Station & Availability */}
        <div className="flex items-center gap-3 pt-2 border-t border-slate-100 flex-wrap text-xs text-slate-600">
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Station:</span>
            <select
              value={selectedStation}
              onChange={e => setSelectedStation(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-md px-2 py-1 text-xs text-slate-800 font-medium"
            >
              {KITCHEN_STATIONS.map(st => (
                <option key={st} value={st}>{st === 'ALL' ? 'All Kitchen Stations' : st}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Stock:</span>
            <div className="flex bg-slate-100 p-0.5 rounded-md">
              {[
                { id: 'ALL', label: 'All Items' },
                { id: 'IN_STOCK', label: 'In Stock' },
                { id: 'SOLD_OUT', label: "86'd / Sold Out" }
              ].map(st => (
                <button
                  key={st.id}
                  onClick={() => setSelectedAvailability(st.id as any)}
                  className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                    selectedAvailability === st.id
                      ? 'bg-white text-slate-900 shadow-2xs font-bold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {st.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Dietary:</span>
            {[
              { id: 'ALL', label: 'All' },
              { id: "Chef's Special", label: "Chef's Pick" },
              { id: 'Vegetarian', label: 'Vegetarian' },
              { id: 'Spicy', label: 'Spicy' }
            ].map(t => (
              <button
                key={t.id}
                onClick={() => setSelectedTag(t.id)}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                  selectedTag === t.id
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200/60'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 4. Filter Results Count */}
      <div className="text-xs text-slate-500 px-1">
        Showing <strong className="text-slate-900">{filteredItems.length}</strong> of {totalItemsCount} catalog menu items
      </div>

      {/* 5. GRID VIEW */}
      {viewMode === 'GRID' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredItems.map(item => {
            const isSoldOut = item.isAvailable === false;
            const cost = item.costPrice || Math.round(item.price * 0.38);
            const margin = item.price > 0 ? Math.round(((item.price - cost) / item.price) * 100) : 0;

            return (
              <div
                key={item.id}
                className={`bg-white rounded-xl border transition-all shadow-2xs hover:shadow-md flex flex-col justify-between overflow-hidden relative group ${
                  isSoldOut ? 'border-rose-200 bg-slate-50/70' : 'border-slate-200/90'
                }`}
              >
                <div>
                  {/* Food Image with Status Overlays */}
                  <div className="relative h-36 w-full overflow-hidden bg-slate-100">
                    <img
                      src={item.image}
                      alt={item.name}
                      className={`w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 ${
                        isSoldOut ? 'grayscale-[40%] opacity-70' : ''
                      }`}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

                    {/* Category Chip */}
                    <div className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-xs text-white text-[10px] font-medium">
                      {item.category}
                    </div>

                    {/* Sold out badge */}
                    {isSoldOut ? (
                      <div className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded bg-rose-600 text-white font-extrabold text-[10px] tracking-wider shadow-md">
                        86'D · SOLD OUT
                      </div>
                    ) : (
                      <div className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded bg-emerald-600/90 backdrop-blur-xs text-white font-bold text-[10px] shadow-sm">
                        IN STOCK
                      </div>
                    )}

                    {/* Prep time badge */}
                    <div className="absolute bottom-2 left-2.5 flex items-center gap-1 text-[10px] text-white/90 drop-shadow-sm font-medium">
                      <Clock className="w-3 h-3" />
                      <span>{item.prepTimeMinutes || 18} mins · {item.kitchenStation || 'Kitchen'}</span>
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-3.5 space-y-2">
                    <div className="flex items-start justify-between gap-1">
                      <div>
                        <h4 className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-1">
                          {item.name}
                        </h4>
                        <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                          SKU: {item.linkedInventorySku || 'FB-001'}
                        </div>
                      </div>

                      {/* Dietary icons */}
                      <div className="flex items-center gap-1 shrink-0">
                        {item.isVegetarian && (
                          <span title="Vegetarian / Fasting">
                            <Leaf className="w-3.5 h-3.5 text-emerald-600" />
                          </span>
                        )}
                        {item.isSpicy && (
                          <span title="Spicy Dish">
                            <Flame className="w-3.5 h-3.5 text-rose-600" />
                          </span>
                        )}
                      </div>
                    </div>

                    <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>

                    {/* Price and Profit Margin */}
                    <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100 flex items-center justify-between">
                      <div>
                        <div className="text-[10px] text-slate-400 uppercase font-semibold">Selling Price</div>
                        <div className="text-xs font-bold text-slate-900 font-mono">
                          {formatMoney(item.price)}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          ${(item.price / exchangeRate).toFixed(2)} USD
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-[10px] text-slate-400 uppercase font-semibold">Cost & Margin</div>
                        <div className="text-xs font-bold text-emerald-700 font-mono">
                          {margin}% Margin
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          Cost: ETB {cost}
                        </div>
                      </div>
                    </div>

                    {/* Tags */}
                    {item.tag && (
                      <div className="pt-0.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold border ${
                          item.tag === "Chef's Special"
                            ? 'bg-rose-50 text-rose-700 border-rose-200'
                            : item.tag === 'Vegetarian'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : 'bg-amber-50 text-amber-700 border-amber-200'
                        }`}>
                          {item.tag}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Bottom Action Footer */}
                <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs">
                  {/* Instant 86'd / In Stock Switch */}
                  <button
                    onClick={() => toggleMenuItemAvailability(item.id)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all flex items-center gap-1.5 border ${
                      isSoldOut
                        ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-200'
                        : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-200'
                    }`}
                    title="Click to toggle item availability across all POS terminals"
                  >
                    <span className={`w-2 h-2 rounded-full ${isSoldOut ? 'bg-rose-600' : 'bg-emerald-600'}`} />
                    <span>{isSoldOut ? "86'd (Click to Restock)" : 'In Stock (Live)'}</span>
                  </button>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => openEditModal(item)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-white border border-transparent hover:border-slate-200 transition-colors"
                      title="Edit Item Details & Price"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteMenuItem(item.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-white border border-transparent hover:border-slate-200 transition-colors"
                      title="Delete from Catalog"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 6. TABLE VIEW */}
      {viewMode === 'TABLE' && (
        <div className="bg-white rounded-xl border border-slate-200/90 overflow-hidden shadow-2xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-3 px-4">Dish / Product</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Selling Price (ETB / USD)</th>
                  <th className="py-3 px-4">COGS & Margin</th>
                  <th className="py-3 px-4">Station & Time</th>
                  <th className="py-3 px-4">Tags</th>
                  <th className="py-3 px-4">POS Availability</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredItems.map(item => {
                  const isSoldOut = item.isAvailable === false;
                  const cost = item.costPrice || Math.round(item.price * 0.38);
                  const margin = item.price > 0 ? Math.round(((item.price - cost) / item.price) * 100) : 0;

                  return (
                    <tr
                      key={item.id}
                      className={`hover:bg-slate-50/80 transition-colors ${
                        isSoldOut ? 'bg-rose-50/20' : ''
                      }`}
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={item.image}
                            alt={item.name}
                            className="w-10 h-10 rounded-lg object-cover border border-slate-200 shrink-0"
                          />
                          <div>
                            <div className="font-bold text-slate-900">{item.name}</div>
                            <div className="text-[11px] text-slate-400 line-clamp-1 max-w-xs">{item.description}</div>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700 border border-slate-200">
                          {item.category}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono">
                        <div className="font-bold text-slate-900">{formatMoney(item.price)}</div>
                        <div className="text-[10px] text-slate-400">${(item.price / exchangeRate).toFixed(2)} USD</div>
                      </td>
                      <td className="py-3 px-4 font-mono">
                        <div className="font-bold text-emerald-700">{margin}% Margin</div>
                        <div className="text-[10px] text-slate-400">Cost: ETB {cost}</div>
                      </td>
                      <td className="py-3 px-4 text-slate-600">
                        <div>{item.kitchenStation || 'Hot Kitchen'}</div>
                        <div className="text-[10px] text-slate-400">{item.prepTimeMinutes || 18} mins prep</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1">
                          {item.tag && (
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                              {item.tag}
                            </span>
                          )}
                          {item.isVegetarian && <Leaf className="w-3.5 h-3.5 text-emerald-600" />}
                          {item.isSpicy && <Flame className="w-3.5 h-3.5 text-rose-600" />}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <button
                          onClick={() => toggleMenuItemAvailability(item.id)}
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition-colors flex items-center gap-1 ${
                            isSoldOut
                              ? 'bg-rose-50 text-rose-700 border-rose-200'
                              : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          }`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${isSoldOut ? 'bg-rose-600' : 'bg-emerald-600'}`} />
                          <span>{isSoldOut ? "86'd (Sold Out)" : 'In Stock (Live)'}</span>
                        </button>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => openEditModal(item)}
                            className="p-1.5 rounded-lg text-slate-600 hover:text-blue-600 hover:bg-slate-100"
                            title="Edit Item"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => deleteMenuItem(item.id)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-slate-100"
                            title="Delete Item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 7. ADD MENU ITEM MODAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl border border-slate-200 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <UtensilsCrossed className="w-5 h-5 text-blue-600" />
                <h3 className="text-base font-bold text-slate-900">Add New Menu Item</h3>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveAdd} className="space-y-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Dish / Item Name *</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={e => setFormName(e.target.value)}
                  placeholder="e.g. Traditional Doro Wat with Injera"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-bold text-slate-900 focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Category *</label>
                  <select
                    value={formCategory}
                    onChange={e => setFormCategory(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-900 focus:ring-1 focus:ring-blue-500"
                  >
                    {CATEGORIES.filter(c => c !== 'All Menu Items').map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kitchen Station *</label>
                  <select
                    value={formKitchenStation}
                    onChange={e => setFormKitchenStation(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-900 focus:ring-1 focus:ring-blue-500"
                  >
                    {KITCHEN_STATIONS.filter(s => s !== 'ALL').map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Pricing & Cost */}
              <div className="grid grid-cols-3 gap-3 bg-blue-50/50 p-3 rounded-xl border border-blue-100">
                <div>
                  <label className="block font-semibold text-blue-900 mb-1">Price (ETB) *</label>
                  <input
                    type="number"
                    required
                    min={10}
                    value={formPriceETB}
                    onChange={e => setFormPriceETB(Number(e.target.value))}
                    className="w-full bg-white border border-blue-200 rounded-lg px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:ring-1 focus:ring-blue-500"
                  />
                  <div className="text-[10px] text-blue-700 mt-1 font-mono">
                    ${(formPriceETB / exchangeRate).toFixed(2)} USD
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-blue-900 mb-1">Cost (COGS ETB)</label>
                  <input
                    type="number"
                    min={0}
                    value={formCostPriceETB}
                    onChange={e => setFormCostPriceETB(Number(e.target.value))}
                    className="w-full bg-white border border-blue-200 rounded-lg px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:ring-1 focus:ring-blue-500"
                  />
                  <div className="text-[10px] text-blue-700 mt-1 font-mono">
                    Food cost
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-blue-900 mb-1">Est. Gross Margin</label>
                  <div className="px-3 py-2 bg-white rounded-lg border border-blue-200 font-mono font-bold text-emerald-700 text-xs mt-0.5">
                    {formPriceETB > 0 ? Math.round(((formPriceETB - formCostPriceETB) / formPriceETB) * 100) : 0}% Margin
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Description & Ingredients</label>
                <textarea
                  rows={2}
                  value={formDescription}
                  onChange={e => setFormDescription(e.target.value)}
                  placeholder="Ingredients, culinary notes, or accompaniments..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:ring-1 focus:ring-blue-500"
                />
              </div>

              {/* Photo Preset Selector */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1.5">Preset Image Selection or Custom URL</label>
                <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
                  {PRESET_IMAGES.map((img, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setFormImage(img.url)}
                      className={`relative w-14 h-14 rounded-lg overflow-hidden shrink-0 border-2 transition-all ${
                        formImage === img.url ? 'border-blue-600 ring-2 ring-blue-500/20' : 'border-slate-200 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img src={img.url} alt={img.label} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
                <input
                  type="text"
                  value={formImage}
                  onChange={e => setFormImage(e.target.value)}
                  placeholder="Image URL"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-[11px] text-slate-700 mt-2 font-mono"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Prep Time (mins)</label>
                  <input
                    type="number"
                    min={1}
                    value={formPrepTime}
                    onChange={e => setFormPrepTime(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-mono text-slate-900 focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Badge Tag</label>
                  <select
                    value={formTag}
                    onChange={e => setFormTag(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-900 focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="">None</option>
                    <option value="Chef's Special">Chef's Special</option>
                    <option value="Vegetarian">Vegetarian</option>
                    <option value="Spicy">Spicy</option>
                    <option value="Gluten Free">Gluten Free</option>
                    <option value="Ethiopian Special">Ethiopian Special</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Inventory SKU</label>
                  <input
                    type="text"
                    value={formSku}
                    onChange={e => setFormSku(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-mono text-slate-900 focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Toggles */}
              <div className="flex items-center gap-6 pt-1">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formIsVegetarian}
                    onChange={e => setFormIsVegetarian(e.target.checked)}
                    className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                  />
                  <span className="text-slate-700 font-medium">Vegetarian / Fasting (Tsom)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formIsSpicy}
                    onChange={e => setFormIsSpicy(e.target.checked)}
                    className="rounded border-slate-300 text-rose-600 focus:ring-rose-500"
                  />
                  <span className="text-slate-700 font-medium">Spicy / Mitmita</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formIsAvailable}
                    onChange={e => setFormIsAvailable(e.target.checked)}
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-slate-700 font-medium">In Stock / Live on POS</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-700 rounded-xl hover:bg-slate-50 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#2563EB] hover:bg-blue-700 text-white rounded-xl font-semibold flex items-center gap-1.5 shadow-sm"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Menu Item</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 8. EDIT MENU ITEM MODAL */}
      {editingItem && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl border border-slate-200 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-blue-600" />
                <h3 className="text-base font-bold text-slate-900">Edit Dish: {editingItem.name}</h3>
              </div>
              <button
                onClick={() => setEditingItem(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Dish / Item Name *</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={e => setFormName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-bold text-slate-900 focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Category *</label>
                  <select
                    value={formCategory}
                    onChange={e => setFormCategory(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-900 focus:ring-1 focus:ring-blue-500"
                  >
                    {CATEGORIES.filter(c => c !== 'All Menu Items').map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kitchen Station *</label>
                  <select
                    value={formKitchenStation}
                    onChange={e => setFormKitchenStation(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-900 focus:ring-1 focus:ring-blue-500"
                  >
                    {KITCHEN_STATIONS.filter(s => s !== 'ALL').map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Pricing & Cost */}
              <div className="grid grid-cols-3 gap-3 bg-blue-50/50 p-3 rounded-xl border border-blue-100">
                <div>
                  <label className="block font-semibold text-blue-900 mb-1">Price (ETB) *</label>
                  <input
                    type="number"
                    required
                    min={10}
                    value={formPriceETB}
                    onChange={e => setFormPriceETB(Number(e.target.value))}
                    className="w-full bg-white border border-blue-200 rounded-lg px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:ring-1 focus:ring-blue-500"
                  />
                  <div className="text-[10px] text-blue-700 mt-1 font-mono">
                    ${(formPriceETB / exchangeRate).toFixed(2)} USD
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-blue-900 mb-1">Cost (COGS ETB)</label>
                  <input
                    type="number"
                    min={0}
                    value={formCostPriceETB}
                    onChange={e => setFormCostPriceETB(Number(e.target.value))}
                    className="w-full bg-white border border-blue-200 rounded-lg px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:ring-1 focus:ring-blue-500"
                  />
                  <div className="text-[10px] text-blue-700 mt-1 font-mono">
                    Food cost
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-blue-900 mb-1">Est. Gross Margin</label>
                  <div className="px-3 py-2 bg-white rounded-lg border border-blue-200 font-mono font-bold text-emerald-700 text-xs mt-0.5">
                    {formPriceETB > 0 ? Math.round(((formPriceETB - formCostPriceETB) / formPriceETB) * 100) : 0}% Margin
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Description & Ingredients</label>
                <textarea
                  rows={2}
                  value={formDescription}
                  onChange={e => setFormDescription(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:ring-1 focus:ring-blue-500"
                />
              </div>

              {/* Photo Preset Selector */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1.5">Preset Image Selection or Custom URL</label>
                <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
                  {PRESET_IMAGES.map((img, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setFormImage(img.url)}
                      className={`relative w-14 h-14 rounded-lg overflow-hidden shrink-0 border-2 transition-all ${
                        formImage === img.url ? 'border-blue-600 ring-2 ring-blue-500/20' : 'border-slate-200 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img src={img.url} alt={img.label} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
                <input
                  type="text"
                  value={formImage}
                  onChange={e => setFormImage(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-[11px] text-slate-700 mt-2 font-mono"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Prep Time (mins)</label>
                  <input
                    type="number"
                    min={1}
                    value={formPrepTime}
                    onChange={e => setFormPrepTime(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-mono text-slate-900 focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Badge Tag</label>
                  <select
                    value={formTag}
                    onChange={e => setFormTag(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-900 focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="">None</option>
                    <option value="Chef's Special">Chef's Special</option>
                    <option value="Vegetarian">Vegetarian</option>
                    <option value="Spicy">Spicy</option>
                    <option value="Gluten Free">Gluten Free</option>
                    <option value="Ethiopian Special">Ethiopian Special</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Inventory SKU</label>
                  <input
                    type="text"
                    value={formSku}
                    onChange={e => setFormSku(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-mono text-slate-900 focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Toggles */}
              <div className="flex items-center gap-6 pt-1">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formIsVegetarian}
                    onChange={e => setFormIsVegetarian(e.target.checked)}
                    className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                  />
                  <span className="text-slate-700 font-medium">Vegetarian / Fasting (Tsom)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formIsSpicy}
                    onChange={e => setFormIsSpicy(e.target.checked)}
                    className="rounded border-slate-300 text-rose-600 focus:ring-rose-500"
                  />
                  <span className="text-slate-700 font-medium">Spicy / Mitmita</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formIsAvailable}
                    onChange={e => setFormIsAvailable(e.target.checked)}
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-slate-700 font-medium">In Stock / Live on POS</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingItem(null)}
                  className="px-4 py-2 border border-slate-200 text-slate-700 rounded-xl hover:bg-slate-50 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#2563EB] hover:bg-blue-700 text-white rounded-xl font-semibold flex items-center gap-1.5 shadow-sm"
                >
                  <Save className="w-4 h-4" />
                  <span>Update Dish</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 9. BULK PRICE UPDATE MODAL */}
      {isBulkPriceModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">Bulk Menu Price Adjustment</h3>
              <button
                onClick={() => setIsBulkPriceModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Target Category</label>
                <select
                  value={bulkTargetCategory}
                  onChange={e => setBulkTargetCategory(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-900"
                >
                  <option value="ALL">All Categories ({menuItems.length} items)</option>
                  {CATEGORIES.filter(c => c !== 'All Menu Items').map(c => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Adjustment Method</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setBulkAdjustmentType('PERCENT')}
                    className={`p-2 rounded-lg text-center font-semibold border transition-all ${
                      bulkAdjustmentType === 'PERCENT'
                        ? 'bg-blue-50 border-blue-500 text-blue-700'
                        : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    Percentage (%)
                  </button>
                  <button
                    type="button"
                    onClick={() => setBulkAdjustmentType('FIXED')}
                    className={`p-2 rounded-lg text-center font-semibold border transition-all ${
                      bulkAdjustmentType === 'FIXED'
                        ? 'bg-blue-50 border-blue-500 text-blue-700'
                        : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    Fixed Amount (ETB)
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {bulkAdjustmentType === 'PERCENT' ? 'Percentage Change (+/- %)' : 'Amount in ETB (+/-)'}
                </label>
                <input
                  type="number"
                  value={bulkAdjustmentValue}
                  onChange={e => setBulkAdjustmentValue(Number(e.target.value))}
                  placeholder="e.g. 10 for +10%, or -5 for -5%"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-mono font-bold text-slate-900"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
              <button
                onClick={() => setIsBulkPriceModalOpen(false)}
                className="px-4 py-2 border border-slate-200 text-slate-700 rounded-xl hover:bg-slate-50 font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleApplyBulkPrice}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold shadow-sm"
              >
                Apply Price Adjustment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
