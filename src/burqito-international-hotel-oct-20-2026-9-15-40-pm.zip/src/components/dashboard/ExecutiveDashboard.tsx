import React, { useState } from 'react';
import { useHotel } from '../../context/HotelContext.tsx';
import {
  TrendingUp,
  Building2,
  Users,
  DollarSign,
  Bed,
  CheckCircle2,
  Clock,
  Sparkles,
  Wrench,
  AlertTriangle,
  ArrowRight,
  ChevronRight,
  Store,
  ShoppingCart,
  Calendar,
  KeyRound,
  Star,
  Globe
} from 'lucide-react';

export const ExecutiveDashboard: React.FC = () => {
  const {
    kpis,
    rooms,
    bookings,
    inventoryItems,
    employees,
    setActiveTab,
    setSelectedRoom,
    openBookingWizardForRoom,
    addToast,
    formatMoney,
    currency,
    exchangeRate,
    hotelInfo
  } = useHotel();

  const totalRoomsCount = rooms.length > 0 ? rooms.length : 800;
  const occupiedRooms = rooms.filter(r => r.status === 'OCCUPIED');
  const dirtyRooms = rooms.filter(r => r.status === 'DIRTY' || r.status === 'CHECKED_OUT');
  const availableRooms = rooms.filter(r => r.status === 'AVAILABLE');
  const maintenanceRooms = rooms.filter(r => r.status === 'MAINTENANCE');
  const outOfOrderRooms = rooms.filter(r => r.status === 'CHECKED_OUT');
  const lowStockItems = inventoryItems.filter(i => i.totalStock <= i.minSafetyStock);

  const occupancyPercent = totalRoomsCount > 0 ? Math.round((occupiedRooms.length / totalRoomsCount) * 100) : 78;

  const [activeTaskFilter, setActiveTaskFilter] = useState<'ALL' | 'HOUSEKEEPING' | 'MAINTENANCE' | 'FINANCE'>('ALL');

  return (
    <div className="space-y-6 pb-10">
      {/* Page Title & Breadcrumb matching Image exactly */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">Burqito International Hotel</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-[#5B0F0F]/10 text-[#5B0F0F] border border-[#5B0F0F]/20">
              Executive Dashboard
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">Real-time hospitality operations, Lakefront room rack & revenue KPIs in {currency}</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => openBookingWizardForRoom()}
            className="px-3.5 py-2 bg-[#2563EB] hover:bg-blue-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-colors"
          >
            <Calendar className="w-4 h-4" />
            <span>New Reservation</span>
          </button>
          <button
            onClick={() => setActiveTab('POS')}
            className="px-3.5 py-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-2xs transition-colors"
          >
            <Store className="w-4 h-4 text-slate-500" />
            <span>Cashier POS</span>
          </button>
        </div>
      </div>

      {/* Top 4 Primary KPI Summary Cards matching image */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Occupancy Rate */}
        <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
              <span>Occupancy Rate</span>
              <span className="w-8 h-8 rounded-lg bg-amber-50 text-amber-800 flex items-center justify-center">
                <Bed className="w-4 h-4" />
              </span>
            </div>
            <div className="flex items-baseline gap-2 mt-2">
              <span className="text-2xl font-bold text-slate-900 font-mono">{occupancyPercent}%</span>
              <span className="text-xs font-semibold text-emerald-600 flex items-center">
                ▲ 6%
              </span>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>{occupiedRooms.length || 624} / {totalRoomsCount} Rooms</span>
            <div className="w-16 h-3 bg-slate-100 rounded-full overflow-hidden">
              <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${occupancyPercent}%` }}></div>
            </div>
          </div>
        </div>

        {/* Total Revenue */}
        <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
              <span>Total Revenue</span>
              <span className="w-8 h-8 rounded-lg bg-amber-50 text-amber-800 flex items-center justify-center">
                <DollarSign className="w-4 h-4" />
              </span>
            </div>
            <div className="flex items-baseline gap-2 mt-2">
              <span className="text-2xl font-bold text-slate-900 font-mono">{formatMoney(284560)}</span>
              <span className="text-xs font-semibold text-emerald-600">▲ 12%</span>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
            <span>vs. last month</span>
            <span className="font-semibold text-slate-700">Oct 2025</span>
          </div>
        </div>

        {/* Total Guests */}
        <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
              <span>Total Guests</span>
              <span className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
                <Users className="w-4 h-4" />
              </span>
            </div>
            <div className="flex items-baseline gap-2 mt-2">
              <span className="text-2xl font-bold text-slate-900 font-mono">1,248</span>
              <span className="text-xs font-semibold text-emerald-600">▲ 10%</span>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
            <span>Check-ins this month</span>
            <span className="font-semibold text-blue-600">86 Arrivals Today</span>
          </div>
        </div>

        {/* Guest Satisfaction */}
        <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
              <span>Guest Satisfaction</span>
              <span className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
              </span>
            </div>
            <div className="flex items-baseline gap-2 mt-2">
              <span className="text-2xl font-bold text-slate-900 font-mono">4.6 / 5</span>
              <span className="text-xs font-semibold text-emerald-600">▲ 0.3</span>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
            <span>Based on 862 reviews</span>
            <span className="font-semibold text-emerald-700">Excellent</span>
          </div>
        </div>
      </div>

      {/* Second Row: Revenue Overview, Revenue by Department, Occupancy Trend */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Overview */}
        <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Revenue Overview</h3>
              <p className="text-[11px] text-slate-500">Total revenue for Oct 2025</p>
            </div>
            <div className="flex items-center gap-1.5 text-xs">
              <span className="px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium flex items-center gap-1">
                {currency} ▾
              </span>
              <span className="px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium flex items-center gap-1">
                Last 6 Months ▾
              </span>
            </div>
          </div>

          <div className="flex items-baseline gap-2 mb-3">
            <span className="text-xl font-bold text-slate-900 font-mono">{formatMoney(284560)}</span>
            <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">▲ 12%</span>
          </div>

          <div className="h-40 flex items-end justify-between gap-2 pt-6 pb-2 px-2 border-b border-slate-100">
            {['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'].map((month, idx) => {
              const heights = ['h-20', 'h-24', 'h-22', 'h-28', 'h-32', 'h-26', 'h-36'];
              const isLast = idx === 6;
              return (
                <div key={month} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end">
                  <div
                    className={`w-full rounded-t-md transition-all ${
                      isLast ? 'bg-amber-500 shadow-sm' : 'bg-amber-300/80 hover:bg-amber-400'
                    } ${heights[idx]}`}
                  ></div>
                  <span className="text-[10px] text-slate-500 font-medium">{month}</span>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-center gap-4 pt-3 text-[11px] text-slate-600">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
              <span>Revenue</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#5B0F0F]"></span>
              <span>Occupancy %</span>
            </div>
          </div>
        </div>

        {/* Revenue by Department */}
        <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-slate-900">Revenue by Department</h3>
          </div>

          <div className="flex items-center justify-center py-4">
            <div className="relative w-36 h-36 rounded-full border-8 border-[#5B0F0F] flex items-center justify-center bg-amber-50 shadow-inner">
              <div className="absolute inset-2 rounded-full border-8 border-emerald-600 opacity-80"></div>
              <div className="absolute inset-4 rounded-full border-8 border-blue-500 opacity-70"></div>
              <div className="text-center z-10">
                <div className="text-[10px] text-slate-500 font-medium">Total Revenue</div>
                <div className="text-xs font-bold text-slate-900 font-mono">{formatMoney(284560, { compact: true })}</div>
              </div>
            </div>
          </div>

          <div className="space-y-2 text-[11px]">
            {[
              { name: 'Rooms', pct: '42%', amt: 'AED 119,520', color: 'bg-[#5B0F0F]' },
              { name: 'F&B', pct: '28%', amt: 'AED 79,677', color: 'bg-amber-500' },
              { name: 'Spa & Wellness', pct: '12%', amt: 'AED 34,147', color: 'bg-emerald-600' },
              { name: 'Events & Banquet', pct: '10%', amt: 'AED 28,456', color: 'bg-blue-600' },
              { name: 'Other Services', pct: '8%', amt: 'AED 22,760', color: 'bg-slate-400' }
            ].map(d => (
              <div key={d.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full ${d.color}`}></span>
                  <span className="text-slate-700 font-medium">{d.name}</span>
                  <span className="text-slate-400 font-mono">{d.pct}</span>
                </div>
                <span className="text-slate-900 font-semibold font-mono">{d.amt}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Occupancy Trend */}
        <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Occupancy Trend</h3>
              <p className="text-[11px] text-slate-500">Daily room utilization curve</p>
            </div>
            <span className="px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs font-medium">
              This Month ▾
            </span>
          </div>

          <div className="relative h-44 bg-emerald-50/40 rounded-xl border border-emerald-100 flex items-end p-2 overflow-hidden">
            <div className="absolute top-6 right-6 bg-white/95 border border-slate-200 p-2 rounded-lg shadow-sm text-[10px]">
              <div className="font-bold text-slate-900">21 Oct 2025</div>
              <div className="text-emerald-600 font-semibold">Occupancy: 82%</div>
            </div>
            <svg className="w-full h-32 text-emerald-600" fill="none" viewBox="0 0 300 100" stroke="currentColor" strokeWidth="2.5">
              <path d="M 0 60 Q 50 30, 100 40 T 200 20 T 300 15" />
            </svg>
          </div>

          <div className="flex items-center justify-between text-[10px] text-slate-400 pt-2 font-mono">
            <span>1 Oct</span>
            <span>7 Oct</span>
            <span>14 Oct</span>
            <span>21 Oct</span>
            <span>28 Oct</span>
          </div>
        </div>
      </div>

      {/* Third Row: Room Status, Arrivals & Departures, Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Room Status Breakdown */}
        <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Room Status</h3>
              <p className="text-[11px] text-slate-500">Live operational rack</p>
            </div>
            <span className="px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs font-medium">
              All Room Types ▾
            </span>
          </div>

          <div className="flex items-center justify-center py-2">
            <div className="relative w-36 h-36 rounded-full border-8 border-[#5B0F0F] flex items-center justify-center bg-rose-50 shadow-inner">
              <div className="absolute inset-3 rounded-full border-8 border-emerald-600"></div>
              <div className="absolute inset-6 rounded-full border-8 border-amber-500"></div>
              <div className="text-center z-10">
                <div className="text-lg font-bold text-slate-900 font-mono">{totalRoomsCount}</div>
                <div className="text-[10px] text-slate-500 uppercase tracking-wide">Total Rooms</div>
              </div>
            </div>
          </div>

          <div className="space-y-2 text-xs">
            {[
              { label: 'Available', count: availableRooms.length || 112, pct: '14%', color: 'bg-emerald-500' },
              { label: 'Occupied', count: occupiedRooms.length || 624, pct: '78%', color: 'bg-[#5B0F0F]' },
              { label: 'Dirty', count: dirtyRooms.length || 32, pct: '4%', color: 'bg-amber-500' },
              { label: 'Maintenance', count: maintenanceRooms.length || 20, pct: '3%', color: 'bg-blue-600' },
              { label: 'Out of Order', count: outOfOrderRooms.length || 12, pct: '1%', color: 'bg-slate-400' }
            ].map(s => (
              <div key={s.label} className="flex items-center justify-between py-1 border-b border-slate-50 last:border-0">
                <div className="flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full ${s.color}`}></span>
                  <span className="text-slate-700 font-medium">{s.label}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-bold text-slate-900 font-mono">{s.count}</span>
                  <span className="text-slate-400 font-mono w-8 text-right">{s.pct}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Arrivals & Departures */}
        <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Arrivals & Departures</h3>
              <p className="text-[11px] text-slate-500">Front desk daily movement</p>
            </div>
            <span className="px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-xs font-medium">
              Today, 14 Oct 2025 ▾
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl">
              <div className="flex items-center justify-between text-xs text-emerald-800 font-semibold">
                <span>Arrivals</span>
                <span className="text-lg font-bold font-mono">86</span>
              </div>
              <div className="text-[10px] text-emerald-600 mt-1 flex justify-between">
                <span>62 Checked In</span>
                <span>24 Pending</span>
              </div>
            </div>

            <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl">
              <div className="flex items-center justify-between text-xs text-amber-900 font-semibold">
                <span>Departures</span>
                <span className="text-lg font-bold font-mono">72</span>
              </div>
              <div className="text-[10px] text-amber-700 mt-1 flex justify-between">
                <span>50 Checked Out</span>
                <span>22 Pending</span>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left text-xs">
              <thead className="text-[10px] text-slate-400 uppercase border-b border-slate-100">
                <tr>
                  <th className="pb-2 font-medium">Time</th>
                  <th className="pb-2 font-medium">Guest Name</th>
                  <th className="pb-2 font-medium">Room</th>
                  <th className="pb-2 font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {[
                  { time: '10:00 AM', name: 'John Smith', room: '502', status: 'Checked In', type: 'bg-emerald-50 text-emerald-700' },
                  { time: '11:30 AM', name: 'Maria Garcia', room: '510', status: 'Pending', type: 'bg-amber-50 text-amber-700' },
                  { time: '02:00 PM', name: 'Ahmed Ali', room: '601', status: 'Check Out', type: 'bg-blue-50 text-blue-700' },
                  { time: '04:15 PM', name: 'Lisa Brown', room: '518', status: 'Checked In', type: 'bg-emerald-50 text-emerald-700' }
                ].map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/80">
                    <td className="py-2 font-mono text-slate-500">{row.time}</td>
                    <td className="py-2 font-semibold text-slate-900">{row.name}</td>
                    <td className="py-2 font-mono text-slate-600">Rm {row.room}</td>
                    <td className="py-2">
                      <span className={`px-2 py-0.5 rounded-md font-semibold text-[10px] ${row.type}`}>
                        {row.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-slate-900">Recent Activity</h3>
            <button onClick={() => setActiveTab('REPORTS')} className="text-xs text-blue-600 font-semibold hover:underline">View All</button>
          </div>

          <div className="space-y-3 text-xs flex-1">
            {[
              { time: '10:15 AM', text: 'John Smith - Checked In Room 502', icon: CheckCircle2, color: 'text-emerald-600 bg-emerald-50' },
              { time: '09:45 AM', text: 'Room 410 - Housekeeping Completed (Clean)', icon: Sparkles, color: 'text-blue-600 bg-blue-50' },
              { time: '09:20 AM', text: 'Restaurant Order - Table 5 · AED 250.00', icon: Store, color: 'text-amber-600 bg-amber-50' },
              { time: '08:50 AM', text: 'Spa Booking - Maria Garcia · AED 350.00', icon: Sparkles, color: 'text-purple-600 bg-purple-50' },
              { time: '08:30 AM', text: 'Room 316 - Checked Out David Kim', icon: KeyRound, color: 'text-slate-600 bg-slate-100' },
              { time: '07:45 AM', text: 'Low Stock Alert - Mineral Water (10 left)', icon: AlertTriangle, color: 'text-rose-600 bg-rose-50' }
            ].map((act, i) => {
              const IconComp = act.icon;
              return (
                <div key={i} className="flex items-start gap-2.5 pb-2.5 border-b border-slate-100 last:border-0 last:pb-0">
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${act.color}`}>
                    <IconComp className="w-3.5 h-3.5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-slate-800 font-medium truncate">{act.text}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{act.time}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Fourth Row: Top Selling F&B, Guest Nationality, Pending Tasks & Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Top Selling Food & Beverage Items */}
        <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-slate-900">Top Selling Food & Beverage Items</h3>
            <button onClick={() => setActiveTab('MENU')} className="text-xs text-blue-600 font-semibold hover:underline">View All</button>
          </div>

          <div className="space-y-3 text-xs">
            {[
              { rank: 1, name: 'Margherita Pizza', orders: '245 orders', price: 'AED 42.00', img: 'https://images.unsplash.com/photo-1604382355076-af4b0eb60143?w=100&auto=format&fit=crop&q=80', growth: '+18%' },
              { rank: 2, name: 'Grilled Salmon', orders: '180 orders', price: 'AED 75.00', img: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=100&auto=format&fit=crop&q=80', growth: '+12%' },
              { rank: 3, name: 'Caesar Salad', orders: '165 orders', price: 'AED 38.00', img: 'https://images.unsplash.com/photo-1550304943-4f24f54ddde9?w=100&auto=format&fit=crop&q=80', growth: '+10%' },
              { rank: 4, name: 'Burger Classic', orders: '150 orders', price: 'AED 48.00', img: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=100&auto=format&fit=crop&q=80', growth: '+8%' },
              { rank: 5, name: 'Fresh Orange Juice', orders: '140 orders', price: 'AED 24.00', img: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?w=100&auto=format&fit=crop&q=80', growth: '+6%' }
            ].map(item => (
              <div key={item.rank} className="flex items-center justify-between gap-3 p-2 rounded-lg hover:bg-slate-50 transition-colors">
                <div className="flex items-center gap-3">
                  <span className="w-5 text-center font-bold text-slate-400 font-mono text-xs">{item.rank}</span>
                  <img src={item.img} alt={item.name} className="w-10 h-10 rounded-lg object-cover border border-slate-200 shrink-0" />
                  <div>
                    <div className="font-semibold text-slate-900">{item.name}</div>
                    <div className="text-[10px] text-slate-500">{item.orders}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-slate-900 font-mono">{item.price}</div>
                  <div className="text-[10px] font-semibold text-emerald-600">{item.growth}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Guest Nationality */}
        <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-slate-900">Guest Nationality</h3>
            <button onClick={() => setActiveTab('GUESTS')} className="text-xs text-blue-600 font-semibold hover:underline">View All</button>
          </div>

          <div className="space-y-3 text-xs">
            {[
              { country: 'UAE', flag: '🇦🇪', pct: 28, count: 350, color: 'bg-[#5B0F0F]' },
              { country: 'Saudi Arabia', flag: '🇸🇦', pct: 18, count: 225, color: 'bg-amber-500' },
              { country: 'United Kingdom', flag: '🇬🇧', pct: 12, count: 150, color: 'bg-emerald-600' },
              { country: 'India', flag: '🇮🇳', pct: 10, count: 125, color: 'bg-amber-400' },
              { country: 'Germany', flag: '🇩🇪', pct: 8, count: 100, color: 'bg-slate-400' },
              { country: 'Others', flag: '🌐', pct: 24, count: 298, color: 'bg-slate-600' }
            ].map(nat => (
              <div key={nat.country} className="space-y-1">
                <div className="flex items-center justify-between text-slate-700">
                  <span className="font-medium flex items-center gap-2">
                    <span>{nat.flag}</span>
                    <span>{nat.country}</span>
                  </span>
                  <span className="font-mono text-slate-500">{nat.pct}% <strong className="text-slate-900">({nat.count})</strong></span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full ${nat.color}`} style={{ width: `${nat.pct}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Pending Tasks & Alerts */}
        <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-slate-900">Pending Tasks & Alerts</h3>
            <button onClick={() => setActiveTab('HOUSEKEEPING')} className="text-xs text-blue-600 font-semibold hover:underline">View All</button>
          </div>

          <div className="flex items-center gap-1.5 mb-3 text-[11px]">
            {[
              { id: 'ALL', label: 'All 12' },
              { id: 'HOUSEKEEPING', label: 'Housekeeping 5' },
              { id: 'MAINTENANCE', label: 'Maintenance 3' },
              { id: 'FINANCE', label: 'Finance 2' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTaskFilter(tab.id as any)}
                className={`px-2.5 py-1 rounded-lg font-semibold transition-colors ${
                  activeTaskFilter === tab.id
                    ? 'bg-[#5B0F0F] text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="space-y-3 text-xs flex-1">
            {[
              { title: 'Room 316 - Cleaning Required', desc: 'Guest checked out 30 minutes ago', priority: 'High', color: 'bg-rose-50 text-rose-700 border-rose-200', category: 'HOUSEKEEPING' },
              { title: 'Room 410 - Maintenance Issue', desc: 'AC not working properly in suite', priority: 'High', color: 'bg-rose-50 text-rose-700 border-rose-200', category: 'MAINTENANCE' },
              { title: '3 Pending Invoices', desc: 'Guest departure today awaiting folio settlement', priority: 'Medium', color: 'bg-amber-50 text-amber-800 border-amber-200', category: 'FINANCE' },
              { title: 'Low Stock - Tea Bags', desc: 'Inventory below safety threshold (12 left)', priority: 'Medium', color: 'bg-amber-50 text-amber-800 border-amber-200', category: 'HOUSEKEEPING' }
            ]
              .filter(t => activeTaskFilter === 'ALL' || t.category === activeTaskFilter)
              .map((task, idx) => (
                <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-start justify-between gap-3">
                  <div className="space-y-0.5">
                    <div className="font-bold text-slate-900">{task.title}</div>
                    <div className="text-[11px] text-slate-500">{task.desc}</div>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold border shrink-0 ${task.color}`}>
                    {task.priority}
                  </span>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};
