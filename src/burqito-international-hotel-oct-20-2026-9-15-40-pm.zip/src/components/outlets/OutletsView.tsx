import React from 'react';
import { useHotel } from '../../context/HotelContext.tsx';
import {
  Store,
  Utensils,
  Wine,
  Coffee,
  Sparkles,
  TrendingUp,
  Clock,
  Users,
  ChevronRight,
  ArrowRight,
  Flame,
  Award
} from 'lucide-react';

export const OutletsView: React.FC = () => {
  const { setActiveTab, formatMoney, currency, exchangeRate, hotelInfo } = useHotel();

  const outlets = [
    {
      id: 'out-1',
      name: 'BIH Open Kitchen Restaurant',
      category: 'Family Dining & Authentic Ethiopian Cuisine',
      location: 'Ground Floor, Lake Promenade Terrace',
      hours: '06:00 - 23:30',
      status: 'Open',
      coversToday: 168,
      openChecks: 6,
      dailyRevenue: 52400,
      icon: Utensils,
      color: 'bg-amber-50 text-amber-700 border-amber-200'
    },
    {
      id: 'out-2',
      name: 'Lake Hawassa Terrace Bar & Lounge',
      category: 'Sunset Cocktails, Habesha Beers & Tapas',
      location: 'Rooftop Level 4, Lakeview Deck',
      hours: '11:00 - 01:00',
      status: 'Open',
      coversToday: 95,
      openChecks: 4,
      dailyRevenue: 28600,
      icon: Wine,
      color: 'bg-blue-50 text-blue-700 border-blue-200'
    },
    {
      id: 'out-3',
      name: 'Sidama Coffee Ceremony House',
      category: 'Traditional Clay Pot Roasting & Garden Cafe',
      location: 'Lush Botanical Garden Pavilion',
      hours: '07:00 - 20:00',
      status: 'Open',
      coversToday: 112,
      openChecks: 3,
      dailyRevenue: 14800,
      icon: Coffee,
      color: 'bg-emerald-50 text-emerald-700 border-emerald-200'
    },
    {
      id: 'out-4',
      name: 'Burqito In-Room Butler Dining',
      category: '24/7 Private Room Delivery',
      location: 'Central Executive Pantry',
      hours: '24 Hours Open',
      status: 'Open',
      coversToday: 42,
      openChecks: 2,
      dailyRevenue: 19500,
      icon: Sparkles,
      color: 'bg-purple-50 text-purple-700 border-purple-200'
    },
    {
      id: 'out-5',
      name: 'Grand Sidama Conference & Banquet Hall',
      category: 'Corporate Seminars, Weddings & Receptions',
      location: 'Convention Center Wing (300 Pax)',
      hours: 'Event Schedule (08:00 - 22:00)',
      status: 'In Session',
      coversToday: 180,
      openChecks: 1,
      dailyRevenue: 85000,
      icon: Award,
      color: 'bg-indigo-50 text-indigo-700 border-indigo-200'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">Hospitality Outlets & Points of Sale</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
              Burqito International Hotel
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">Live restaurant table checks, Lakeview terrace orders, Sidama coffee ceremony & room dining</p>
        </div>

        <button
          onClick={() => setActiveTab('POS')}
          className="px-4 py-2.5 bg-[#2563EB] hover:bg-blue-700 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-sm transition-colors"
        >
          <Store className="w-4 h-4" />
          <span>Launch Cashier POS</span>
        </button>
      </div>

      {/* Outlets Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {outlets.map(out => {
          const Icon = out.icon;
          return (
            <div
              key={out.id}
              className="p-5 rounded-xl border border-slate-200/90 bg-white shadow-2xs hover:border-blue-300 transition-all flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${out.color} shrink-0`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-900">{out.name}</h3>
                      <div className="text-[11px] text-slate-500">{out.category} · {out.location}</div>
                    </div>
                  </div>

                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                    <span>{out.status}</span>
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 mt-4 p-3 bg-slate-50 rounded-xl text-xs">
                  <div>
                    <div className="text-[10px] text-slate-400 uppercase tracking-wider">Today's Revenue</div>
                    <div className="text-sm font-bold text-slate-900 font-mono mt-0.5">
                      {formatMoney(out.dailyRevenue)}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      {currency === 'ETB' ? `≈ $${(out.dailyRevenue / exchangeRate).toFixed(0)}` : `≈ ETB ${out.dailyRevenue.toLocaleString()}`}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400 uppercase tracking-wider">Covers Served</div>
                    <div className="text-sm font-bold text-slate-900 font-mono mt-0.5">{out.coversToday} Guests</div>
                    <div className="text-[10px] text-slate-400">Daily throughput</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400 uppercase tracking-wider">Active Tables</div>
                    <div className="text-sm font-bold text-blue-600 font-mono mt-0.5">{out.openChecks} Checks</div>
                    <div className="text-[10px] text-blue-500">Live ordering</div>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-[11px] text-slate-400 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Operating hours: {out.hours}</span>
                </span>

                <button
                  onClick={() => setActiveTab('POS')}
                  className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold rounded-lg text-xs flex items-center gap-1.5 border border-blue-200 transition-colors"
                >
                  <span>Open Register</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
