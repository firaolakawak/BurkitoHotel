import React, { useState, useMemo } from 'react';
import { useHotel } from '../../context/HotelContext.tsx';
import { Booking, BookingStatus } from '../../types/index.ts';
import {
  Calendar,
  Search,
  Plus,
  Filter,
  CheckCircle2,
  Clock,
  ArrowRight,
  MoreHorizontal,
  FileText,
  User,
  Bed,
  CreditCard,
  Building,
  Check
} from 'lucide-react';

export const ReservationsView: React.FC = () => {
  const {
    bookings,
    openBookingWizardForRoom,
    openCheckOutModal,
    openFolioModal,
    setSelectedRoom,
    rooms,
    setActiveTab,
    formatMoney,
    currency,
    exchangeRate,
    hotelInfo
  } = useHotel();

  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredBookings = useMemo(() => {
    return bookings.filter(b => {
      if (statusFilter !== 'ALL' && b.status !== statusFilter) return false;
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase();
        const guestName = b.guest ? `${b.guest.firstName} ${b.guest.lastName}`.toLowerCase() : '';
        const ref = b.bookingReference.toLowerCase();
        const roomNum = b.room?.roomNumber?.toLowerCase() || '';
        return guestName.includes(q) || ref.includes(q) || roomNum.includes(q);
      }
      return true;
    });
  }, [bookings, statusFilter, searchQuery]);

  const totalRevenue = useMemo(() => {
    return bookings.reduce((acc, b) => acc + (b.ratePerNight * b.totalNights), 0);
  }, [bookings]);

  const checkedInCount = bookings.filter(b => b.status === 'CHECKED_IN').length;
  const confirmedCount = bookings.filter(b => b.status === 'CONFIRMED').length;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">Reservations Management</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
              Burqito International Hotel
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">Master reservations roster, room assignments & folio balances in {currency}</p>
        </div>

        <button
          onClick={() => openBookingWizardForRoom()}
          className="px-4 py-2.5 bg-[#2563EB] hover:bg-blue-700 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-sm transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>New Reservation</span>
        </button>
      </div>

      {/* 4 Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-3.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-medium text-slate-500">Total Reservations</div>
          <div className="text-xl font-bold text-slate-900 font-mono mt-1">{bookings.length}</div>
          <div className="text-[10px] text-slate-400 mt-0.5">Active ledger entries</div>
        </div>

        <div className="p-3.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-medium text-slate-500">In-House (Checked In)</div>
          <div className="text-xl font-bold text-blue-600 font-mono mt-1">{checkedInCount}</div>
          <div className="text-[10px] text-blue-600 mt-0.5">Currently occupying rooms</div>
        </div>

        <div className="p-3.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-medium text-slate-500">Confirmed (Upcoming)</div>
          <div className="text-xl font-bold text-emerald-600 font-mono mt-1">{confirmedCount}</div>
          <div className="text-[10px] text-emerald-600 mt-0.5">Guaranteed with credit card</div>
        </div>

        <div className="p-3.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="text-[11px] font-medium text-slate-500">Committed Room Revenue</div>
          <div className="text-xl font-bold text-slate-900 font-mono mt-1">{formatMoney(totalRevenue)}</div>
          <div className="text-[10px] text-slate-500 mt-0.5 font-medium">
            {currency === 'ETB' ? `≈ $${(totalRevenue / exchangeRate).toFixed(0)} USD` : `≈ ETB ${totalRevenue.toLocaleString()}`}
          </div>
        </div>
      </div>

      {/* Sub Tabs & Search */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-4 space-y-4 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          {/* Status Sub Tabs */}
          <div className="flex space-x-2 text-xs overflow-x-auto scrollbar-none">
            {[
              { id: 'ALL', label: 'All Reservations' },
              { id: 'CHECKED_IN', label: 'Checked-In' },
              { id: 'CONFIRMED', label: 'Confirmed' },
              { id: 'CHECKED_OUT', label: 'Completed / Checked-Out' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setStatusFilter(tab.id)}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                  statusFilter === tab.id
                    ? 'bg-blue-50 text-blue-700 border border-blue-200'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Search Bar */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search guest or #RES..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Reservations Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-100 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-2.5 px-3">Reservation Ref</th>
                <th className="py-2.5 px-3">Guest</th>
                <th className="py-2.5 px-3">Room Assigned</th>
                <th className="py-2.5 px-3">Stay Dates</th>
                <th className="py-2.5 px-3">Duration</th>
                <th className="py-2.5 px-3">Total Amount</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredBookings.map(b => {
                const guestName = b.guest ? `${b.guest.firstName} ${b.guest.lastName}` : 'Guest';
                const isCheckedIn = b.status === 'CHECKED_IN';
                const room = b.room || rooms.find(r => r.id === b.roomId);

                return (
                  <tr key={b.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-3 font-mono font-bold text-blue-600">
                      {b.bookingReference}
                    </td>

                    <td className="py-3 px-3">
                      <div className="font-semibold text-slate-900">{guestName}</div>
                      <div className="text-[11px] text-slate-500">{b.guest?.email || 'email@guest.com'}</div>
                    </td>

                    <td className="py-3 px-3">
                      <button
                        onClick={() => {
                          if (room) {
                            setSelectedRoom(room);
                            setActiveTab('PMS_GRID');
                          }
                        }}
                        className="font-semibold text-slate-900 hover:text-blue-600 hover:underline flex items-center gap-1.5"
                      >
                        <Bed className="w-3.5 h-3.5 text-slate-400" />
                        <span>Room {room?.roomNumber || '502'}</span>
                        <span className="text-[10px] text-slate-400 capitalize">({room?.category?.toLowerCase() || 'Deluxe'})</span>
                      </button>
                    </td>

                    <td className="py-3 px-3">
                      <div className="font-medium text-slate-700">{b.checkInDate}</div>
                      <div className="text-[11px] text-slate-400">until {b.checkOutDate}</div>
                    </td>

                    <td className="py-3 px-3 font-medium text-slate-700">
                      {b.totalNights} nights
                    </td>

                    <td className="py-3 px-3 font-mono font-bold text-slate-900">
                      {formatMoney(b.ratePerNight * b.totalNights, { showBoth: true })}
                    </td>

                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold inline-flex items-center gap-1 ${
                        isCheckedIn
                          ? 'bg-blue-50 text-blue-700 border border-blue-200'
                          : b.status === 'CONFIRMED'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-slate-100 text-slate-700'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${isCheckedIn ? 'bg-blue-600' : 'bg-emerald-600'}`} />
                        <span>{isCheckedIn ? 'Checked In' : b.status === 'CONFIRMED' ? 'Confirmed' : 'Checked Out'}</span>
                      </span>
                    </td>

                    <td className="py-3 px-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => openFolioModal(b)}
                          className="px-2.5 py-1 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg text-[11px] font-medium"
                          title="Open Folio Ledger"
                        >
                          Folio
                        </button>
                        {isCheckedIn && (
                          <button
                            onClick={() => openCheckOutModal(b)}
                            className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-[11px] font-medium"
                          >
                            Check Out
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
