import React, { useState } from 'react';
import { useHotel } from '../../context/HotelContext.tsx';
import {
  BarChart3,
  TrendingUp,
  Download,
  Calendar,
  DollarSign,
  Users,
  Bed,
  Package,
  CheckCircle2
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const { kpis, addToast, formatMoney, currency, exchangeRate, hotelInfo } = useHotel();
  const [reportType, setReportType] = useState<'OCCUPANCY' | 'INVENTORY' | 'POS' | 'STAFF'>('OCCUPANCY');
  const [timeRange, setTimeRange] = useState<'TODAY' | 'WEEK' | 'MONTH' | 'YEAR'>('MONTH');

  const handleExport = (format: 'PDF' | 'CSV') => {
    addToast({
      type: 'success',
      title: `Report Exported (${format})`,
      message: `Burqito International Hotel ${reportType} report (${timeRange}) generated in ${currency}.`
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">Analytics & Reports</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
              Burqito International Hotel (BIH)
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">Hawassa property operational telemetry, Lakefront occupancy trends, and ETB/USD revenue ratios</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => handleExport('CSV')}
            className="px-3.5 py-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-2xs transition-colors"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => handleExport('PDF')}
            className="px-3.5 py-2 bg-[#2563EB] hover:bg-blue-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Export PDF</span>
          </button>
        </div>
      </div>

      {/* Filter Strip */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-4 space-y-4 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          {/* Sub Tabs */}
          <div className="flex space-x-2 text-xs overflow-x-auto scrollbar-none">
            {[
              { id: 'OCCUPANCY', label: 'Occupancy & RevPAR' },
              { id: 'INVENTORY', label: 'Inventory Turnover' },
              { id: 'POS', label: 'F&B Outlets Revenue' },
              { id: 'STAFF', label: 'Staff Roster & Labor' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setReportType(tab.id as any)}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                  reportType === tab.id
                    ? 'bg-blue-50 text-blue-700 border border-blue-200'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Time range pills */}
          <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg text-xs font-semibold">
            {(['TODAY', 'WEEK', 'MONTH', 'YEAR'] as const).map(t => (
              <button
                key={t}
                onClick={() => setTimeRange(t)}
                className={`px-3 py-1 rounded-md transition-colors ${
                  timeRange === t ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                {t.charAt(0) + t.slice(1).toLowerCase()}
              </button>
            ))}
          </div>
        </div>

        {/* Visual Monthly Performance Bars */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/80 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm font-bold text-slate-900">Burqito International Hotel Occupancy & Revenue (October 2025)</h4>
              <p className="text-xs text-slate-500">
                Target ADR: {formatMoney(6500)} · Actual Average ADR: {formatMoney(6950)}
              </p>
            </div>
            <div className="text-right">
              <span className="text-xs font-bold text-emerald-600 font-mono">+16.4% YoY Growth</span>
            </div>
          </div>

          <div className="space-y-2 pt-2">
            {[
              { label: 'Week 1 (Oct 1 - Oct 7)', pct: 82, valETB: 1240000, count: '82% Occupancy' },
              { label: 'Week 2 (Oct 8 - Oct 14)', pct: 79, valETB: 1180000, count: '79% Occupancy' },
              { label: 'Week 3 (Oct 15 - Oct 21)', pct: 88, valETB: 1390000, count: '88% Occupancy (Projected)' },
              { label: 'Week 4 (Oct 22 - Oct 28)', pct: 92, valETB: 1480000, count: '92% Occupancy (Peak Lakefront)' }
            ].map((wk, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-medium text-slate-700">{wk.label}</span>
                  <span className="font-mono font-bold text-slate-900">
                    {formatMoney(wk.valETB)} ({wk.count})
                  </span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-200 overflow-hidden">
                  <div className="h-full bg-blue-600 rounded-full" style={{ width: `${wk.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
