import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext.tsx';
import {
  LayoutDashboard,
  Building2,
  Calendar,
  BedDouble,
  Sparkles,
  UtensilsCrossed,
  Package,
  UserCheck,
  Banknote,
  Store,
  TrendingUp,
  BarChart3,
  Settings,
  ChevronLeft,
  ChevronRight,
  Building
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, addToast, hotelInfo } = useHotel();
  const [isCollapsed, setIsCollapsed] = useState(false);

  const navItems = [
    { id: 'DASHBOARD', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'PMS_GRID', label: 'Front Desk', icon: Building2 },
    { id: 'RESERVATIONS', label: 'Reservations', icon: Calendar },
    { id: 'ROOMS', label: 'Room Management', icon: BedDouble },
    { id: 'HOUSEKEEPING', label: 'Housekeeping', icon: Sparkles },
    { id: 'POS', label: 'Restaurant / POS', icon: UtensilsCrossed },
    { id: 'INVENTORY', label: 'Inventory', icon: Package },
    { id: 'STAFF', label: 'Staff Management', icon: UserCheck },
    { id: 'FINANCE', label: 'Finance', icon: Banknote },
    { id: 'POS', label: 'Cashier', icon: Store },
    { id: 'OUTLETS', label: 'Sales & Outlets', icon: TrendingUp },
    { id: 'REPORTS', label: 'Reports', icon: BarChart3 },
    { id: 'SETTINGS', label: 'Settings', icon: Settings },
  ];

  // Dynamic Top Logo (from hotelInfo.logo upload)
  const topLogo = hotelInfo.logo;

  // Dynamic Bottom Hotel Picture (from hotelInfo.photos upload)
  const bottomPhoto = hotelInfo.photos && hotelInfo.photos.length > 0
    ? hotelInfo.photos[0]
    : 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=400&auto=format&fit=crop&q=80';

  return (
    <aside className={`${isCollapsed ? 'w-20' : 'w-64'} bg-[#3A1F0E] text-[#F8F1E8] flex flex-col justify-between shrink-0 h-screen sticky top-0 border-r border-[#E0D5C8]/25 select-none z-30 transition-all duration-300`}>
      {/* Top Brand Logo & Collapse Toggle */}
      <div className="overflow-y-auto scrollbar-none flex-1">
        <div className={`px-4 py-4 flex items-center ${isCollapsed ? 'justify-center flex-col gap-2' : 'justify-between'} border-b border-[#5B0F0F]/40 bg-[#3A1F0E]`}>
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#F28C28] via-[#5B0F0F] to-[#3A1F0E] flex items-center justify-center text-white shadow-md shadow-black/40 shrink-0 overflow-hidden border border-[#F28C28]/40">
              {topLogo ? (
                <img src={topLogo} alt="Hotel Logo" className="w-full h-full object-cover" />
              ) : (
                <span className="text-sm font-extrabold">☕</span>
              )}
            </div>
            {!isCollapsed && (
              <div className="truncate">
                <div className="text-xs font-bold tracking-wider text-white uppercase truncate">{hotelInfo.name || 'Burqito'}</div>
                <div className="text-[10px] font-semibold text-[#F28C28] uppercase tracking-wider">International Hotel</div>
              </div>
            )}
          </div>

          <button
            onClick={() => setIsCollapsed(prev => !prev)}
            className="p-1.5 rounded-lg bg-[#5B0F0F]/60 hover:bg-[#5B0F0F] text-[#E0D5C8] hover:text-white transition-colors"
            title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
          >
            {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Navigation list */}
        <nav className="p-2.5 space-y-1">
          {navItems.map((item, idx) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={idx}
                onClick={() => setActiveTab(item.id as any)}
                title={isCollapsed ? item.label : undefined}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                  isCollapsed ? 'justify-center px-0' : ''
                } ${
                  isActive
                    ? 'bg-[#5B0F0F] text-white font-semibold shadow-md shadow-black/30 border-l-4 border-[#F28C28]'
                    : 'text-[#E0D5C8] hover:text-white hover:bg-[#5B0F0F]/30'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#F28C28]' : 'text-[#E0D5C8]/70'}`} />
                {!isCollapsed && <span className="truncate">{item.label}</span>}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Luxury Hotel Picture Card (Dynamic Upload) */}
      {!isCollapsed && (
        <div className="p-3.5 border-t border-[#5B0F0F]/40 bg-[#2C170A] shrink-0">
          <div className="mb-2 relative rounded-xl overflow-hidden h-24 w-full border border-[#5B0F0F]/50 shadow-inner">
            <img
              src={bottomPhoto}
              alt="Burqito International Hotel Hawassa"
              className="w-full h-full object-cover brightness-95"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#3A1F0E]/95 via-[#3A1F0E]/30 to-transparent flex flex-col justify-end p-2">
              <div className="text-[11px] font-bold text-white tracking-wide">Burqito</div>
              <div className="text-[9px] text-[#F28C28]">International Hotel</div>
            </div>
          </div>

          <div className="px-1 text-center">
            <div className="text-[9px] tracking-widest text-[#E0D5C8]/70 uppercase font-serif">
              Comfort · Hospitality · Beyond Expectations
            </div>
          </div>
        </div>
      )}
    </aside>
  );
};
