import React, { useState } from 'react';
import { useHotel } from '../../context/HotelContext.tsx';
import { FloorConfig, RoomCategory } from '../../types/index.ts';
import {
  Layers,
  Building,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  AlertTriangle,
  Sparkles,
  Sliders,
  SlidersHorizontal,
  Bed,
  RotateCcw,
  CheckCircle2
} from 'lucide-react';

interface FloorPlanConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialFloor?: number;
}

export const FloorPlanConfigModal: React.FC<FloorPlanConfigModalProps> = ({
  isOpen,
  onClose,
  initialFloor
}) => {
  const {
    floors,
    rooms,
    addFloor,
    updateFloor,
    deleteFloor,
    setFloorRoomCount,
    setFloors,
    addToast,
    formatMoney,
    currency
  } = useHotel();

  // Active tab inside modal: 'MANAGE_FLOORS' | 'ADD_FLOOR' | 'QUICK_WIZARD'
  const [activeTab, setActiveTab] = useState<'MANAGE_FLOORS' | 'ADD_FLOOR' | 'QUICK_WIZARD'>('MANAGE_FLOORS');

  // Per-floor target room count state map (floorNumber -> count)
  const [roomCountInputs, setRoomCountInputs] = useState<Record<number, number>>(() => {
    const initialMap: Record<number, number> = {};
    floors.forEach(f => {
      initialMap[f.floorNumber] = rooms.filter(r => r.floor === f.floorNumber).length;
    });
    return initialMap;
  });

  // Editing floor metadata inline (floorNumber -> { name, wing })
  const [editingFloor, setEditingFloor] = useState<number | null>(initialFloor || null);
  const [editName, setEditName] = useState<string>('');
  const [editWing, setEditWing] = useState<string>('');

  // Add Floor Form State
  const nextFloorNum = floors.length > 0 ? Math.max(...floors.map(f => f.floorNumber)) + 1 : 1;
  const [newFloorNumber, setNewFloorNumber] = useState<number>(nextFloorNum);
  const [newFloorName, setNewFloorName] = useState<string>(`Floor ${nextFloorNum}`);
  const [newFloorWing, setNewFloorWing] = useState<string>('Lake Wing');
  const [newFloorRoomCount, setNewFloorRoomCount] = useState<number>(12);
  const [newFloorCategory, setNewFloorCategory] = useState<RoomCategory>('DELUXE');
  const [newFloorRate, setNewFloorRate] = useState<number>(850);

  // Quick Wizard State
  const [wizardTotalFloors, setWizardTotalFloors] = useState<number>(4);
  const [wizardRoomsPerFloor, setWizardRoomsPerFloor] = useState<number>(15);
  const [wizardDefaultCategory, setWizardDefaultCategory] = useState<RoomCategory>('DELUXE');

  if (!isOpen) return null;

  const handleStartEdit = (f: FloorConfig) => {
    setEditingFloor(f.floorNumber);
    setEditName(f.name);
    setEditWing(f.wing || 'Lake Wing');
  };

  const handleSaveEdit = (floorNumber: number) => {
    if (!editName.trim()) return;
    updateFloor(floorNumber, { name: editName.trim(), wing: editWing });
    setEditingFloor(null);
  };

  const handleApplyRoomCount = (floorNumber: number) => {
    const target = roomCountInputs[floorNumber];
    if (target === undefined || target < 0) {
      addToast({ type: 'warning', title: 'Invalid Count', message: 'Room count cannot be negative.' });
      return;
    }
    setFloorRoomCount(floorNumber, target);
  };

  const handleCreateFloor = (e: React.FormEvent) => {
    e.preventDefault();
    if (floors.some(f => f.floorNumber === newFloorNumber)) {
      addToast({ type: 'error', title: 'Floor Exists', message: `Floor ${newFloorNumber} already exists in hotel layout.` });
      return;
    }

    addFloor({
      floorNumber: Number(newFloorNumber),
      name: newFloorName.trim() || `Floor ${newFloorNumber}`,
      wing: newFloorWing,
      roomCount: Math.max(0, Number(newFloorRoomCount)),
      defaultCategory: newFloorCategory,
      defaultRate: Number(newFloorRate)
    });

    // Reset and switch back
    const nextNum = Number(newFloorNumber) + 1;
    setNewFloorNumber(nextNum);
    setNewFloorName(`Floor ${nextNum}`);
    setActiveTab('MANAGE_FLOORS');
  };

  const handleApplyWizard = () => {
    if (wizardTotalFloors < 1 || wizardRoomsPerFloor < 0) {
      addToast({ type: 'warning', title: 'Invalid Configuration', message: 'Floors must be at least 1 and rooms per floor cannot be negative.' });
      return;
    }

    // Configure wizardTotalFloors floors with wizardRoomsPerFloor rooms each
    const newFloorsList: FloorConfig[] = [];
    for (let f = 1; f <= wizardTotalFloors; f++) {
      newFloorsList.push({
        floorNumber: f,
        name: `Floor ${f}`,
        wing: f % 2 === 0 ? 'Central Tower' : 'Lake Wing',
        description: `${wizardRoomsPerFloor} Custom Rooms`
      });
    }
    setFloors(newFloorsList);

    // Set count on each floor
    newFloorsList.forEach(fl => {
      setFloorRoomCount(fl.floorNumber, wizardRoomsPerFloor, wizardDefaultCategory);
    });

    addToast({
      type: 'success',
      title: 'Custom Layout Configured',
      message: `Setup complete: ${wizardTotalFloors} floors with ${wizardRoomsPerFloor} rooms each (${wizardTotalFloors * wizardRoomsPerFloor} total rooms).`
    });
    setActiveTab('MANAGE_FLOORS');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden font-sans">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
              <Building className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Custom Floor Plan & Rooms Manager</h2>
              <p className="text-xs text-slate-500">
                Configure how many floors the hotel has and specify how many rooms belong to each floor
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Tabs */}
        <div className="px-6 pt-3 border-b border-slate-200 bg-white flex items-center gap-4 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('MANAGE_FLOORS')}
            className={`pb-2.5 transition-all relative flex items-center gap-1.5 ${
              activeTab === 'MANAGE_FLOORS'
                ? 'text-blue-600 border-b-2 border-blue-600 font-bold'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Configured Floors ({floors.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('ADD_FLOOR')}
            className={`pb-2.5 transition-all relative flex items-center gap-1.5 ${
              activeTab === 'ADD_FLOOR'
                ? 'text-blue-600 border-b-2 border-blue-600 font-bold'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>Add New Floor</span>
          </button>

          <button
            onClick={() => setActiveTab('QUICK_WIZARD')}
            className={`pb-2.5 transition-all relative flex items-center gap-1.5 ${
              activeTab === 'QUICK_WIZARD'
                ? 'text-blue-600 border-b-2 border-blue-600 font-bold'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>Layout Wizard (Set All Floors & Rooms)</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4 text-xs">
          {/* TAB 1: MANAGE EXISTING FLOORS */}
          {activeTab === 'MANAGE_FLOORS' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-slate-600 bg-blue-50/60 border border-blue-100 rounded-xl p-3">
                <div className="flex items-center gap-2">
                  <SlidersHorizontal className="w-4 h-4 text-blue-600 shrink-0" />
                  <span>
                    Adjust the number of rooms for any floor below. Click <strong>Apply</strong> to immediately update room inventory.
                  </span>
                </div>
                <button
                  onClick={() => setActiveTab('ADD_FLOOR')}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold text-xs flex items-center gap-1 shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Floor</span>
                </button>
              </div>

              {floors.length === 0 ? (
                <div className="text-center py-10 border-2 border-dashed border-slate-200 rounded-2xl space-y-2">
                  <p className="font-semibold text-slate-700">No floors configured yet.</p>
                  <button
                    onClick={() => setActiveTab('ADD_FLOOR')}
                    className="px-4 py-2 bg-blue-600 text-white rounded-xl font-bold"
                  >
                    Create Floor 1
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {[...floors].sort((a, b) => a.floorNumber - b.floorNumber).map(fl => {
                    const floorRooms = rooms.filter(r => r.floor === fl.floorNumber);
                    const occupiedOnFloor = floorRooms.filter(r => r.status === 'OCCUPIED').length;
                    const availableOnFloor = floorRooms.filter(r => r.status === 'AVAILABLE').length;
                    const isEditing = editingFloor === fl.floorNumber;
                    const currentCountInput = roomCountInputs[fl.floorNumber] ?? floorRooms.length;
                    const hasCountChanged = currentCountInput !== floorRooms.length;

                    return (
                      <div
                        key={fl.floorNumber}
                        className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-2xs hover:shadow-xs transition-shadow space-y-3"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          {/* Left: Floor Name & Wing */}
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200 font-mono font-bold text-slate-800 flex items-center justify-center text-sm">
                              F{fl.floorNumber}
                            </div>
                            <div>
                              {isEditing ? (
                                <div className="flex items-center gap-2">
                                  <input
                                    type="text"
                                    value={editName}
                                    onChange={e => setEditName(e.target.value)}
                                    className="bg-slate-50 border border-slate-300 rounded px-2 py-1 text-xs font-bold text-slate-900"
                                    placeholder="Floor Name"
                                  />
                                  <select
                                    value={editWing}
                                    onChange={e => setEditWing(e.target.value)}
                                    className="bg-slate-50 border border-slate-300 rounded px-2 py-1 text-xs text-slate-800"
                                  >
                                    <option value="Lake Wing">Lake Wing</option>
                                    <option value="Central Tower">Central Tower</option>
                                    <option value="Promenade Wing">Promenade Wing</option>
                                  </select>
                                  <button
                                    onClick={() => handleSaveEdit(fl.floorNumber)}
                                    className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                                    title="Save name"
                                  >
                                    <Check className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={() => setEditingFloor(null)}
                                    className="p-1 text-slate-400 hover:bg-slate-100 rounded"
                                  >
                                    <X className="w-4 h-4" />
                                  </button>
                                </div>
                              ) : (
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-slate-900 text-sm">{fl.name}</span>
                                  <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 text-[11px] font-medium">
                                    {fl.wing || 'Lake Wing'}
                                  </span>
                                  <button
                                    onClick={() => handleStartEdit(fl)}
                                    className="text-slate-400 hover:text-slate-700 p-0.5"
                                    title="Edit name and wing"
                                  >
                                    <Edit2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              )}
                              <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-2">
                                <span>Currently: <strong className="text-slate-700">{floorRooms.length} Rooms</strong></span>
                                <span>•</span>
                                <span className="text-emerald-600">{availableOnFloor} Available</span>
                                <span>•</span>
                                <span className="text-blue-600">{occupiedOnFloor} Occupied</span>
                              </div>
                            </div>
                          </div>

                          {/* Right: Room Count Stepper & Apply button */}
                          <div className="flex items-center gap-3">
                            <div className="flex items-center border border-slate-200 rounded-xl bg-slate-50 p-1">
                              <span className="text-[11px] text-slate-500 font-medium px-2">Rooms:</span>
                              <button
                                type="button"
                                onClick={() => {
                                  const current = roomCountInputs[fl.floorNumber] ?? floorRooms.length;
                                  setRoomCountInputs(prev => ({
                                    ...prev,
                                    [fl.floorNumber]: Math.max(0, current - 1)
                                  }));
                                }}
                                className="w-7 h-7 rounded-lg bg-white hover:bg-slate-200 text-slate-800 font-bold flex items-center justify-center border border-slate-200"
                              >
                                -
                              </button>
                              <input
                                type="number"
                                min={0}
                                max={100}
                                value={currentCountInput}
                                onChange={e => {
                                  const val = parseInt(e.target.value, 10);
                                  setRoomCountInputs(prev => ({
                                    ...prev,
                                    [fl.floorNumber]: isNaN(val) ? 0 : Math.max(0, val)
                                  }));
                                }}
                                className="w-12 text-center bg-transparent font-bold font-mono text-slate-900 text-xs focus:outline-none"
                              />
                              <button
                                type="button"
                                onClick={() => {
                                  const current = roomCountInputs[fl.floorNumber] ?? floorRooms.length;
                                  setRoomCountInputs(prev => ({
                                    ...prev,
                                    [fl.floorNumber]: current + 1
                                  }));
                                }}
                                className="w-7 h-7 rounded-lg bg-white hover:bg-slate-200 text-slate-800 font-bold flex items-center justify-center border border-slate-200"
                              >
                                +
                              </button>
                            </div>

                            <button
                              type="button"
                              onClick={() => handleApplyRoomCount(fl.floorNumber)}
                              className={`px-3 py-2 rounded-xl font-semibold text-xs transition-colors shadow-2xs ${
                                hasCountChanged
                                  ? 'bg-blue-600 hover:bg-blue-700 text-white animate-pulse'
                                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                              }`}
                            >
                              {hasCountChanged ? 'Apply Changes' : 'Set Count'}
                            </button>

                            <button
                              type="button"
                              onClick={() => deleteFloor(fl.floorNumber)}
                              title={`Delete Floor ${fl.floorNumber} and all its rooms`}
                              className="p-2 rounded-xl border border-slate-200 transition-colors text-rose-500 hover:bg-rose-50 hover:border-rose-300"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: ADD NEW FLOOR */}
          {activeTab === 'ADD_FLOOR' && (
            <form onSubmit={handleCreateFloor} className="space-y-4 max-w-lg mx-auto bg-slate-50/50 p-5 rounded-2xl border border-slate-200">
              <h3 className="text-sm font-bold text-slate-900 border-b border-slate-200 pb-2">
                Configure New Hotel Floor
              </h3>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Floor Number *</label>
                  <input
                    type="number"
                    required
                    min={0}
                    max={99}
                    value={newFloorNumber}
                    onChange={e => {
                      const num = Number(e.target.value);
                      setNewFloorNumber(num);
                      setNewFloorName(`Floor ${num}`);
                    }}
                    className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 font-mono font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Floor Name *</label>
                  <input
                    type="text"
                    required
                    value={newFloorName}
                    onChange={e => setNewFloorName(e.target.value)}
                    placeholder="e.g. Floor 7 - Sky Deck"
                    className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Building Wing</label>
                  <select
                    value={newFloorWing}
                    onChange={e => setNewFloorWing(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-slate-900 font-medium"
                  >
                    <option value="Lake Wing">Lake Wing</option>
                    <option value="Central Tower">Central Tower</option>
                    <option value="Promenade Wing">Promenade Wing</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">How Many Rooms? *</label>
                  <input
                    type="number"
                    required
                    min={0}
                    max={100}
                    value={newFloorRoomCount}
                    onChange={e => setNewFloorRoomCount(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 font-mono font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Default Room Category</label>
                  <select
                    value={newFloorCategory}
                    onChange={e => setNewFloorCategory(e.target.value as RoomCategory)}
                    className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-slate-900 font-semibold"
                  >
                    <option value="STANDARD">Standard Room</option>
                    <option value="DELUXE">Deluxe Room</option>
                    <option value="SUITE">Executive Suite</option>
                    <option value="PRESIDENTIAL">Presidential Suite</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Default Nightly Rate ({currency})</label>
                  <input
                    type="number"
                    min={50}
                    value={newFloorRate}
                    onChange={e => setNewFloorRate(Number(e.target.value))}
                    className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 font-mono font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('MANAGE_FLOORS')}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-slate-700 font-semibold hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-sm"
                >
                  Create Floor & Rooms
                </button>
              </div>
            </form>
          )}

          {/* TAB 3: QUICK LAYOUT WIZARD */}
          {activeTab === 'QUICK_WIZARD' && (
            <div className="space-y-4 max-w-lg mx-auto bg-slate-50/50 p-5 rounded-2xl border border-slate-200">
              <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                <Sparkles className="w-5 h-5 text-amber-500" />
                <h3 className="text-sm font-bold text-slate-900">
                  Custom Property Setup Wizard
                </h3>
              </div>
              <p className="text-slate-600 text-xs">
                Quickly establish your complete hotel configuration by setting the total number of floors and how many rooms exist on each floor.
              </p>

              <div className="space-y-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    How many total floors does your property have?
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={wizardTotalFloors}
                    onChange={e => setWizardTotalFloors(Number(e.target.value))}
                    className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 font-mono font-bold text-slate-900 text-sm"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    How many rooms on each floor?
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={50}
                    value={wizardRoomsPerFloor}
                    onChange={e => setWizardRoomsPerFloor(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 font-mono font-bold text-slate-900 text-sm"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Default Room Type
                  </label>
                  <select
                    value={wizardDefaultCategory}
                    onChange={e => setWizardDefaultCategory(e.target.value as RoomCategory)}
                    className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-slate-900 font-semibold"
                  >
                    <option value="DELUXE">Deluxe Room</option>
                    <option value="STANDARD">Standard Room</option>
                    <option value="SUITE">Executive Suite</option>
                  </select>
                </div>

                <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-blue-900 text-xs flex items-center justify-between">
                  <span>Calculated Hotel Capacity:</span>
                  <strong className="font-mono text-sm font-bold">
                    {wizardTotalFloors * wizardRoomsPerFloor} Total Rooms
                  </strong>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('MANAGE_FLOORS')}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-slate-700 font-semibold hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleApplyWizard}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-sm"
                >
                  Generate Hotel Layout
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs">
          <span className="text-slate-500">
            Total Property Inventory: <strong className="text-slate-900">{rooms.length} Rooms</strong> across <strong className="text-slate-900">{floors.length} Floors</strong>
          </span>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-semibold shadow-xs"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
