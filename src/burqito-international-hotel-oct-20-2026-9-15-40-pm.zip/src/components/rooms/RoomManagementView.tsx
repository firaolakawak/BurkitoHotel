import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useHotel } from '../../context/HotelContext.tsx';
import { Room, RoomCategory, RoomStatus } from '../../types/index.ts';
import { FloorPlanConfigModal } from './FloorPlanConfigModal.tsx';
import {
  Bed,
  Plus,
  Search,
  Filter,
  SlidersHorizontal,
  Edit3,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Wrench,
  DollarSign,
  Maximize2,
  Users,
  Eye,
  Layers,
  ArrowUpDown,
  Check,
  X,
  MapPin,
  Calendar,
  MoreHorizontal,
  Save,
  RotateCcw,
  Tag,
  Wifi,
  Tv,
  Coffee,
  Wind,
  Download,
  Settings as SettingsIcon,
  Upload,
  Image as ImageIcon,
  Camera,
  ChevronLeft,
  ChevronRight,
  ShieldAlert,
  Lock,
  Brush,
  Grid,
  List,
  Compass,
  Building,
  Home,
  CheckSquare,
  Square,
  DoorClosed,
  Minus
} from 'lucide-react';

// Curated high-res room photography presets
const ROOM_PHOTO_PRESETS = [
  'https://images.unsplash.com/photo-1590490360182-c33d57733427?w=1000&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=1000&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1618773928121-c32242e63f39?w=1000&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1566665797739-1674de7a421a?w=1000&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1591088398332-8a7791972843?w=1000&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=1000&auto=format&fit=crop&q=80'
];

export const RoomManagementView: React.FC = () => {
  const {
    rooms,
    floors,
    addFloor,
    updateFloor,
    deleteFloor,
    setFloorRoomCount,
    addRoom,
    updateRoom,
    deleteRoom,
    toggleRoomStatus,
    uploadRoomPhotos,
    deleteRoomPhoto,
    setRoomCoverPhoto,
    formatMoney,
    currency,
    exchangeRate,
    addToast,
    clearAllOccupiedAndResetFrontDesk
  } = useHotel();

  // Primary View Mode: Room Plan | Grid View | List View
  const [activeView, setActiveView] = useState<'ROOM_PLAN' | 'GRID_VIEW' | 'LIST_VIEW'>('ROOM_PLAN');

  // Selected floor filter: 'ALL' or a specific floor number
  const [selectedFloor, setSelectedFloor] = useState<string>('1');

  // Filter Bar state
  const [filterRoomType, setFilterRoomType] = useState<string>('All Types');
  const [filterStatus, setFilterStatus] = useState<string>('All Status');
  const [filterHousekeeping, setFilterHousekeeping] = useState<string>('All');
  const [filterMaintenance, setFilterMaintenance] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isMoreFiltersOpen, setIsMoreFiltersOpen] = useState(false);

  // Status Tab for the bottom table (All Rooms, Occupied, Available, Dirty, Maintenance, Out of Order)
  const [tableStatusTab, setTableStatusTab] = useState<string>('ALL');

  // Selected Room ID for Right-Hand Detail Panel
  const [selectedRoomNumber, setSelectedRoomNumber] = useState<string>('');
  const [isDetailDrawerOpen, setIsDetailDrawerOpen] = useState<boolean>(true);

  // Detail Panel Sub-tabs: Details | Guest | Housekeeping | Maintenance
  const [detailSubTab, setDetailSubTab] = useState<'DETAILS' | 'GUEST' | 'HOUSEKEEPING' | 'MAINTENANCE'>('DETAILS');

  // Multi-selection checkboxes in table
  const [selectedTableRows, setSelectedTableRows] = useState<string[]>([]);

  // Room Pictures Gallery & Uploader State
  const [activePhotoIndex, setActivePhotoIndex] = useState<number>(0);
  const [isPhotoManagerModalOpen, setIsPhotoManagerModalOpen] = useState<boolean>(false);
  const [newPhotoUrlInput, setNewPhotoUrlInput] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Floor Plan Config Modal State (Allows user to decide how many floors and how many rooms in each floor)
  const [isFloorConfigModalOpen, setIsFloorConfigModalOpen] = useState<boolean>(false);
  const [floorConfigInitialFloor, setFloorConfigInitialFloor] = useState<number | undefined>(undefined);

  // Quick Inline Floor Room Count Adjuster Modal/Popover
  const [isQuickAdjustOpen, setIsQuickAdjustOpen] = useState<boolean>(false);
  const [quickAdjustFloorNum, setQuickAdjustFloorNum] = useState<number>(1);
  const [quickAdjustCount, setQuickAdjustCount] = useState<number>(20);

  // Add Room Modal State
  const [isAddRoomModalOpen, setIsAddRoomModalOpen] = useState<boolean>(false);
  const [formRoomNo, setFormRoomNo] = useState<string>('');
  const [formCategory, setFormCategory] = useState<RoomCategory>('DELUXE');
  const [formFloor, setFormFloor] = useState<number>(1);
  const [formRate, setFormRate] = useState<number>(480);
  const [formBedType, setFormBedType] = useState<string>('King Bed');
  const [formSize, setFormSize] = useState<number>(42);
  const [formStatus, setFormStatus] = useState<RoomStatus>('AVAILABLE');
  const [formView, setFormView] = useState<string>('Lake Hawassa View');
  const [formPhotos, setFormPhotos] = useState<string[]>([...ROOM_PHOTO_PRESETS.slice(0, 3)]);

  // Auto-select first room if none selected
  useEffect(() => {
    if (!selectedRoomNumber && rooms.length > 0) {
      setSelectedRoomNumber(rooms[0].roomNumber);
    }
  }, [rooms, selectedRoomNumber]);

  // If active selected floor is deleted, automatically fallback to available floor or ALL
  useEffect(() => {
    if (selectedFloor !== 'ALL') {
      const parsed = parseInt(selectedFloor, 10);
      const exists = floors.some(f => f.floorNumber === parsed);
      if (!exists) {
        setSelectedFloor(floors.length > 0 ? String(floors[0].floorNumber) : 'ALL');
      }
    }
  }, [floors, selectedFloor]);

  // Determine active floor number for architectural blueprint
  const activeBlueprintFloorNumber = useMemo(() => {
    if (selectedFloor === 'ALL') {
      return floors.length > 0 ? floors[0].floorNumber : 1;
    }
    const parsed = parseInt(selectedFloor, 10);
    return isNaN(parsed) ? 1 : parsed;
  }, [selectedFloor, floors]);

  // Rooms belonging to the active floor blueprint
  const activeFloorRooms = useMemo(() => {
    return rooms
      .filter(r => r.floor === activeBlueprintFloorNumber)
      .sort((a, b) => Number(a.roomNumber) - Number(b.roomNumber));
  }, [rooms, activeBlueprintFloorNumber]);

  // Active Floor Configuration metadata
  const activeFloorConfig = useMemo(() => {
    return floors.find(f => f.floorNumber === activeBlueprintFloorNumber) || {
      floorNumber: activeBlueprintFloorNumber,
      name: `Floor ${activeBlueprintFloorNumber}`,
      wing: 'Lake Wing',
      description: 'Standard & Deluxe Rooms'
    };
  }, [floors, activeBlueprintFloorNumber]);

  // Selected room data for the right panel
  const activeSelectedRoom = useMemo(() => {
    const found = rooms.find(r => r.roomNumber === selectedRoomNumber);
    if (found) return found;
    if (rooms.length > 0) return rooms[0];
    return {
      id: 'rm-default',
      roomNumber: '101',
      floor: 1,
      category: 'STANDARD' as RoomCategory,
      pricePerNight: 480,
      status: 'AVAILABLE' as RoomStatus,
      maxOccupancy: 2,
      bedConfig: 'King Bed',
      amenities: ['High-speed Wi-Fi', 'Smart TV', 'Rain Shower']
    };
  }, [rooms, selectedRoomNumber]);

  // Dynamic KPI Metrics calculated across all rooms
  const metrics = useMemo(() => {
    const total = rooms.length;
    const occupied = rooms.filter(r => r.status === 'OCCUPIED').length;
    const available = rooms.filter(r => r.status === 'AVAILABLE').length;
    const dirty = rooms.filter(r => r.status === 'DIRTY').length;
    const maintenance = rooms.filter(r => r.status === 'MAINTENANCE').length;
    const outOfOrder = rooms.filter(r => r.status === 'CHECKED_OUT').length;

    const calcPct = (val: number) => (total > 0 ? Math.round((val / total) * 100) : 0);

    return {
      total,
      occupied,
      occupiedPct: calcPct(occupied),
      available,
      availablePct: calcPct(available),
      dirty,
      dirtyPct: calcPct(dirty),
      maintenance,
      maintenancePct: calcPct(maintenance),
      outOfOrder,
      outOfOrderPct: calcPct(outOfOrder)
    };
  }, [rooms]);

  // Filtered Table & Grid Rooms
  const filteredTableRooms = useMemo(() => {
    return rooms.filter(r => {
      // Floor filter
      if (selectedFloor !== 'ALL') {
        const floorNum = parseInt(selectedFloor, 10);
        if (!isNaN(floorNum) && r.floor !== floorNum) return false;
      }

      // Subtab filter
      if (tableStatusTab === 'OCCUPIED' && r.status !== 'OCCUPIED') return false;
      if (tableStatusTab === 'AVAILABLE' && r.status !== 'AVAILABLE') return false;
      if (tableStatusTab === 'DIRTY' && r.status !== 'DIRTY') return false;
      if (tableStatusTab === 'MAINTENANCE' && r.status !== 'MAINTENANCE') return false;
      if (tableStatusTab === 'OUT_OF_ORDER' && r.status !== 'CHECKED_OUT') return false;

      // Dropdown filters
      if (filterRoomType !== 'All Types' && r.category !== filterRoomType.toUpperCase()) return false;
      if (filterStatus !== 'All Status' && r.status !== filterStatus.toUpperCase()) return false;
      if (filterHousekeeping === 'Clean' && r.cleaningStatus === 'NEEDS_CLEANING') return false;
      if (filterHousekeeping === 'Dirty' && r.cleaningStatus !== 'NEEDS_CLEANING' && r.status !== 'DIRTY') return false;

      // Search Query
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase();
        return (
          r.roomNumber.toLowerCase().includes(q) ||
          r.category.toLowerCase().includes(q) ||
          (r.guestName && r.guestName.toLowerCase().includes(q))
        );
      }
      return true;
    }).sort((a, b) => Number(a.roomNumber) - Number(b.roomNumber));
  }, [rooms, selectedFloor, tableStatusTab, filterRoomType, filterStatus, filterHousekeeping, searchQuery]);

  // Dynamic Table Status Tab Counts
  const tableStatusCounts = useMemo(() => {
    const baseList = selectedFloor === 'ALL'
      ? rooms
      : rooms.filter(r => r.floor === parseInt(selectedFloor, 10));

    return {
      all: baseList.length,
      occupied: baseList.filter(r => r.status === 'OCCUPIED').length,
      available: baseList.filter(r => r.status === 'AVAILABLE').length,
      dirty: baseList.filter(r => r.status === 'DIRTY').length,
      maintenance: baseList.filter(r => r.status === 'MAINTENANCE').length,
      outOfOrder: baseList.filter(r => r.status === 'CHECKED_OUT').length
    };
  }, [rooms, selectedFloor]);

  // Images for currently active selected room
  const currentRoomPhotos = useMemo(() => {
    if (activeSelectedRoom?.images && activeSelectedRoom.images.length > 0) {
      return activeSelectedRoom.images;
    }
    return ROOM_PHOTO_PRESETS;
  }, [activeSelectedRoom]);

  // Handle Photo Upload via local File Input
  const handleLocalFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const readFilesPromises: Promise<string>[] = Array.from(files).map(file => {
      return new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
    });

    Promise.all(readFilesPromises).then(base64Urls => {
      uploadRoomPhotos(activeSelectedRoom.id, base64Urls);
      setActivePhotoIndex(0);
      addToast({
        type: 'success',
        title: 'Photos Added',
        message: `${base64Urls.length} picture(s) uploaded to Room ${activeSelectedRoom.roomNumber}.`
      });
    }).catch(err => {
      console.error(err);
      addToast({ type: 'error', title: 'Upload Failed', message: 'Could not process selected image files.' });
    });
  };

  const handleAddPhotoUrl = () => {
    if (!newPhotoUrlInput.trim()) return;
    uploadRoomPhotos(activeSelectedRoom.id, [newPhotoUrlInput.trim()]);
    setNewPhotoUrlInput('');
    addToast({
      type: 'success',
      title: 'Picture Linked',
      message: `Image added to Room ${activeSelectedRoom.roomNumber} gallery.`
    });
  };

  const handleDeletePhoto = (photoUrl: string) => {
    deleteRoomPhoto(activeSelectedRoom.id, photoUrl);
    if (activePhotoIndex >= currentRoomPhotos.length - 1) {
      setActivePhotoIndex(Math.max(0, currentRoomPhotos.length - 2));
    }
  };

  const handleSetCoverPhoto = (photoUrl: string) => {
    setRoomCoverPhoto(activeSelectedRoom.id, photoUrl);
  };

  // Open add room modal preset to active floor
  const handleOpenAddRoomModal = () => {
    const flNum = activeBlueprintFloorNumber;
    const currentOnFloor = rooms.filter(r => r.floor === flNum);
    const highestNum = currentOnFloor.reduce((max, r) => {
      const p = parseInt(r.roomNumber, 10);
      return !isNaN(p) && p > max ? p : max;
    }, flNum * 100);

    setFormRoomNo(String(highestNum + 1));
    setFormFloor(flNum);
    setFormRate(flNum >= 5 ? 1200 : flNum >= 3 ? 850 : 480);
    setFormCategory(flNum >= 5 ? 'SUITE' : flNum >= 3 ? 'DELUXE' : 'STANDARD');
    setIsAddRoomModalOpen(true);
  };

  const handleSaveNewRoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRoomNo.trim()) return;

    addRoom({
      roomNumber: formRoomNo.trim(),
      floor: formFloor,
      category: formCategory,
      pricePerNight: Number(formRate),
      status: formStatus,
      maxOccupancy: formCategory === 'SUITE' ? 4 : 2,
      bedConfig: formBedType,
      sizeSqm: formSize,
      amenities: ['King Bed', 'City View', 'Minibar', 'Free Wi-Fi', 'Smart TV'],
      images: formPhotos,
      coverImage: formPhotos[0],
      wing: formFloor % 2 === 0 ? 'Central Tower' : 'Lake Wing',
      cleaningStatus: 'CLEAN'
    });

    setIsAddRoomModalOpen(false);
    setSelectedRoomNumber(formRoomNo.trim());
  };

  // Helper colors for status badges matching exact screenshot styling
  const getStatusBadge = (status: RoomStatus) => {
    switch (status) {
      case 'AVAILABLE':
        return <span className="px-2.5 py-0.5 rounded-md text-xs font-semibold bg-[#EAF8F0] text-[#1E9E60]">Available</span>;
      case 'OCCUPIED':
        return <span className="px-2.5 py-0.5 rounded-md text-xs font-semibold bg-[#EBF3FF] text-[#2563EB]">Occupied</span>;
      case 'DIRTY':
        return <span className="px-2.5 py-0.5 rounded-md text-xs font-semibold bg-[#FFF4E5] text-[#D97706]">Dirty</span>;
      case 'MAINTENANCE':
        return <span className="px-2.5 py-0.5 rounded-md text-xs font-semibold bg-[#FEECEC] text-[#DC2626]">Maintenance</span>;
      case 'CHECKED_OUT':
      default:
        return <span className="px-2.5 py-0.5 rounded-md text-xs font-semibold bg-slate-100 text-slate-700">Out of Order</span>;
    }
  };

  const getHousekeepingBadge = (hk?: string) => {
    switch (hk) {
      case 'CLEAN':
      case 'Clean':
        return <span className="px-2.5 py-0.5 rounded-md text-xs font-semibold bg-[#EAF8F0] text-[#1E9E60]">Clean</span>;
      case 'NEEDS_CLEANING':
      case 'Dirty':
        return <span className="px-2.5 py-0.5 rounded-md text-xs font-semibold bg-[#FEECEC] text-[#DC2626]">Dirty</span>;
      default:
        return <span className="px-2.5 py-0.5 rounded-md text-xs font-semibold bg-slate-100 text-slate-700">Inspected</span>;
    }
  };

  // Floor plan room item styles
  const getPlanRoomStyle = (status: RoomStatus, isSelected: boolean) => {
    let base = 'transition-all cursor-pointer rounded-lg border-2 p-2 flex flex-col justify-between items-center text-center select-none ';
    if (isSelected) {
      base += 'ring-2 ring-blue-600 ring-offset-1 shadow-md ';
    }
    switch (status) {
      case 'AVAILABLE':
        return base + 'bg-[#F0FDF4] border-[#86EFAC] text-[#15803D] hover:bg-[#DCFCE7]';
      case 'OCCUPIED':
        return base + 'bg-[#EFF6FF] border-[#93C5FD] text-[#1D4ED8] hover:bg-[#DBEAFE]';
      case 'DIRTY':
        return base + 'bg-[#FFFBEB] border-[#FCD34D] text-[#B45309] hover:bg-[#FEF3C7]';
      case 'MAINTENANCE':
        return base + 'bg-[#FEF2F2] border-[#FCA5A5] text-[#B91C1C] hover:bg-[#FEE2E2]';
      case 'CHECKED_OUT':
      default:
        return base + 'bg-[#F8FAFC] border-[#CBD5E1] text-[#475569] hover:bg-[#F1F5F9]';
    }
  };

  // Architectural Corridor Partitioning for the blueprint
  const topCorridorRooms = useMemo(() => {
    const half = Math.ceil(activeFloorRooms.length / 2);
    return activeFloorRooms.slice(0, half);
  }, [activeFloorRooms]);

  const bottomCorridorRooms = useMemo(() => {
    const half = Math.ceil(activeFloorRooms.length / 2);
    return activeFloorRooms.slice(half);
  }, [activeFloorRooms]);

  return (
    <div className="space-y-5 pb-12 font-sans">
      {/* 1. Header with Page Title and Action Buttons */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">Room Management</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
              {rooms.length} Rooms · {floors.length} Floors
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage custom floor plans, configure room capacities, room rates, housekeeping, and maintenance
          </p>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          {/* Segmented View Switcher: Room Plan | Grid View | List View */}
          <div className="flex items-center bg-white border border-slate-200 rounded-xl p-1 shadow-2xs">
            <button
              onClick={() => setActiveView('ROOM_PLAN')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeView === 'ROOM_PLAN'
                  ? 'bg-blue-50 text-blue-600 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Compass className="w-3.5 h-3.5" />
              <span>Room Plan</span>
            </button>

            <button
              onClick={() => setActiveView('GRID_VIEW')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeView === 'GRID_VIEW'
                  ? 'bg-blue-50 text-blue-600 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Grid className="w-3.5 h-3.5" />
              <span>Grid View</span>
            </button>

            <button
              onClick={() => setActiveView('LIST_VIEW')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeView === 'LIST_VIEW'
                  ? 'bg-blue-50 text-blue-600 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>List View</span>
            </button>
          </div>

          {/* Customize Floors & Rooms Button (User Request: decide how many floors and how many rooms in each floor) */}
          <button
            onClick={() => {
              setFloorConfigInitialFloor(activeBlueprintFloorNumber);
              setIsFloorConfigModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-blue-400" />
            <span>Customize Floors & Rooms</span>
          </button>

          {/* Clear Mockup & Make All Rooms Available Button */}
          <button
            onClick={() => clearAllOccupiedAndResetFrontDesk()}
            title="Clear all mockup occupied rooms and make all rooms available"
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-xl text-xs font-semibold shadow-2xs transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Make All Available</span>
          </button>

          {/* + Add Room button */}
          <button
            onClick={handleOpenAddRoomModal}
            className="flex items-center gap-1.5 px-4 py-2 bg-[#2563EB] hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Room</span>
          </button>
        </div>
      </div>

      {/* 2. Top Metrics Cards (100% Dynamic calculated from real room inventory) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        {/* Total Rooms */}
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600 shrink-0">
            <Bed className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[11px] font-medium text-slate-500 truncate">Total Rooms</div>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-xl font-bold text-slate-900 font-mono">{metrics.total}</span>
              <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-blue-50 text-blue-600">100%</span>
            </div>
          </div>
        </div>

        {/* Occupied */}
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600 shrink-0">
            <Bed className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[11px] font-medium text-slate-500 truncate">Occupied</div>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-xl font-bold text-slate-900 font-mono">{metrics.occupied}</span>
              <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-blue-50 text-blue-600">{metrics.occupiedPct}%</span>
            </div>
          </div>
        </div>

        {/* Available */}
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-500 shrink-0">
            <Bed className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[11px] font-medium text-slate-500 truncate">Available</div>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-xl font-bold text-slate-900 font-mono">{metrics.available}</span>
              <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-emerald-50 text-emerald-600">{metrics.availablePct}%</span>
            </div>
          </div>
        </div>

        {/* Dirty */}
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center text-amber-500 shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[11px] font-medium text-slate-500 truncate">Dirty</div>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-xl font-bold text-slate-900 font-mono">{metrics.dirty}</span>
              <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-amber-50 text-amber-600">{metrics.dirtyPct}%</span>
            </div>
          </div>
        </div>

        {/* Maintenance */}
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-rose-50 flex items-center justify-center text-rose-500 shrink-0">
            <Wrench className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[11px] font-medium text-slate-500 truncate">Maintenance</div>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-xl font-bold text-slate-900 font-mono">{metrics.maintenance}</span>
              <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-rose-50 text-rose-600">{metrics.maintenancePct}%</span>
            </div>
          </div>
        </div>

        {/* Out of Order */}
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-2xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-50 flex items-center justify-center text-purple-600 shrink-0">
            <Lock className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[11px] font-medium text-slate-500 truncate">Out of Order</div>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-xl font-bold text-slate-900 font-mono">{metrics.outOfOrder}</span>
              <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-purple-50 text-purple-600">{metrics.outOfOrderPct}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Horizontal Filter Row */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-3 shadow-2xs flex flex-wrap items-center gap-3">
        {/* Dynamic Floor Dropdown populated directly from configured floors */}
        <div className="w-36">
          <label className="block text-[10px] font-medium text-slate-400 mb-0.5">Floor</label>
          <select
            value={selectedFloor}
            onChange={e => setSelectedFloor(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 font-medium focus:ring-1 focus:ring-blue-500"
          >
            <option value="ALL">All Floors ({rooms.length})</option>
            {[...floors].sort((a, b) => a.floorNumber - b.floorNumber).map(fl => {
              const count = rooms.filter(r => r.floor === fl.floorNumber).length;
              return (
                <option key={fl.floorNumber} value={String(fl.floorNumber)}>
                  {fl.name} ({count} rooms)
                </option>
              );
            })}
          </select>
        </div>

        {/* Room Type */}
        <div className="w-32">
          <label className="block text-[10px] font-medium text-slate-400 mb-0.5">Room Type</label>
          <select
            value={filterRoomType}
            onChange={e => setFilterRoomType(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 font-medium focus:ring-1 focus:ring-blue-500"
          >
            <option value="All Types">All Types</option>
            <option value="Standard">Standard</option>
            <option value="Deluxe">Deluxe</option>
            <option value="Suite">Suite</option>
            <option value="Presidential">Presidential</option>
          </select>
        </div>

        {/* Status */}
        <div className="w-32">
          <label className="block text-[10px] font-medium text-slate-400 mb-0.5">Status</label>
          <select
            value={filterStatus}
            onChange={e => setFilterStatus(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 font-medium focus:ring-1 focus:ring-blue-500"
          >
            <option value="All Status">All Status</option>
            <option value="Available">Available</option>
            <option value="Occupied">Occupied</option>
            <option value="Dirty">Dirty</option>
            <option value="Maintenance">Maintenance</option>
          </select>
        </div>

        {/* Housekeeping */}
        <div className="w-28">
          <label className="block text-[10px] font-medium text-slate-400 mb-0.5">Housekeeping</label>
          <select
            value={filterHousekeeping}
            onChange={e => setFilterHousekeeping(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 font-medium focus:ring-1 focus:ring-blue-500"
          >
            <option value="All">All</option>
            <option value="Clean">Clean</option>
            <option value="Dirty">Dirty</option>
          </select>
        </div>

        {/* Quick Search input */}
        <div className="flex-1 min-w-[200px]">
          <label className="block text-[10px] font-medium text-slate-400 mb-0.5">Quick Search</label>
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by room number or guest..."
              className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Reset Filter Button */}
        {(searchQuery || filterRoomType !== 'All Types' || filterStatus !== 'All Status' || selectedFloor !== '1') && (
          <div className="self-end">
            <button
              onClick={() => {
                setSearchQuery('');
                setFilterRoomType('All Types');
                setFilterStatus('All Status');
                setSelectedFloor('1');
              }}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs text-slate-500 hover:text-slate-800 hover:bg-slate-50"
              title="Reset Filters"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          </div>
        )}
      </div>

      {/* 4. Main Two-Column Layout: Left (Floor List + Blueprint / Table) | Right (Room Detail Drawer) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left Column (Span 8 or full if drawer closed) */}
        <div className={`${isDetailDrawerOpen ? 'lg:col-span-8' : 'lg:col-span-12'} space-y-5 min-w-0`}>
          {/* Main Container with Floor Navigator + Interactive Architectural Blueprint Floor Plan */}
          {activeView === 'ROOM_PLAN' && (
            <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-2xs flex flex-col md:flex-row gap-4 items-stretch">
              {/* Left Floors Selector - 100% Dynamic from configured floors */}
              <div className="w-full md:w-44 shrink-0 border-r border-slate-100 pr-3 space-y-1 text-xs select-none flex flex-col justify-between">
                <div className="space-y-1">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3 pb-1">
                    Hotel Floors ({floors.length})
                  </div>

                  {/* All Floors Option */}
                  <div
                    onClick={() => setSelectedFloor('ALL')}
                    className={`flex items-center justify-between px-3 py-2 rounded-xl cursor-pointer transition-all ${
                      selectedFloor === 'ALL'
                        ? 'bg-blue-50 text-blue-600 font-bold shadow-2xs'
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span>All Floors</span>
                    <span className="text-[11px] text-slate-400 font-mono font-medium">{rooms.length}</span>
                  </div>

                  {/* Dynamic Floor List with real room counts and quick settings icon */}
                  {[...floors].sort((a, b) => a.floorNumber - b.floorNumber).map(fl => {
                    const count = rooms.filter(r => r.floor === fl.floorNumber).length;
                    const isSelected = selectedFloor === String(fl.floorNumber);

                    return (
                      <div
                        key={fl.floorNumber}
                        onClick={() => setSelectedFloor(String(fl.floorNumber))}
                        className={`group flex items-center justify-between px-3 py-2 rounded-xl cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-blue-50 text-blue-600 font-bold shadow-2xs'
                            : 'text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <div className="truncate flex-1 pr-1">
                          <span className="truncate">{fl.name}</span>
                          <span className="block text-[9px] text-slate-400 font-normal truncate">
                            {fl.wing || 'Lake Wing'}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[11px] font-mono font-medium text-slate-400 group-hover:text-slate-700">
                            {count}
                          </span>
                          <button
                            type="button"
                            onClick={e => {
                              e.stopPropagation();
                              setQuickAdjustFloorNum(fl.floorNumber);
                              setQuickAdjustCount(count);
                              setIsQuickAdjustOpen(true);
                            }}
                            className="opacity-0 group-hover:opacity-100 p-0.5 rounded text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-all"
                            title="Adjust room count on this floor"
                          >
                            <SlidersHorizontal className="w-3 h-3" />
                          </button>

                          <button
                            type="button"
                            onClick={e => {
                              e.stopPropagation();
                              deleteFloor(fl.floorNumber);
                            }}
                            className="opacity-0 group-hover:opacity-100 p-0.5 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-all"
                            title={`Delete Floor ${fl.floorNumber}`}
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Bottom Add Floor & Settings Action */}
                <div className="pt-3 border-t border-slate-100 space-y-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setFloorConfigInitialFloor(activeBlueprintFloorNumber);
                      setIsFloorConfigModalOpen(true);
                    }}
                    className="w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl border border-dashed border-slate-300 text-slate-600 hover:border-blue-500 hover:text-blue-600 text-xs font-semibold hover:bg-blue-50/50 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+ Add New Floor</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsFloorConfigModalOpen(true)}
                    className="w-full flex items-center justify-center gap-1 text-[11px] text-slate-400 hover:text-slate-700 py-1"
                  >
                    <SettingsIcon className="w-3 h-3" />
                    <span>Floor Configuration</span>
                  </button>
                </div>
              </div>

              {/* Interactive Floor Plan Center Section */}
              <div className="flex-1 min-w-0 space-y-3">
                {/* Floor Plan Header & Legend */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <span>{activeFloorConfig.name} - {activeFloorConfig.wing || 'Lake Wing'}</span>
                      <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                        {activeFloorRooms.length} Rooms
                      </span>
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Architectural interactive floor plan · Click any room to inspect or update
                    </p>
                  </div>

                  <div className="flex items-center gap-2 text-[11px] text-slate-600 flex-wrap">
                    {/* Quick Button to Adjust Rooms on this Floor */}
                    <button
                      type="button"
                      onClick={() => {
                        setQuickAdjustFloorNum(activeBlueprintFloorNumber);
                        setQuickAdjustCount(activeFloorRooms.length);
                        setIsQuickAdjustOpen(true);
                      }}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold text-[11px] transition-colors"
                    >
                      <SlidersHorizontal className="w-3 h-3" />
                      <span>Adjust Rooms ({activeFloorRooms.length})</span>
                    </button>

                    {/* Delete Active Floor Button */}
                    <button
                      type="button"
                      onClick={() => {
                        deleteFloor(activeBlueprintFloorNumber);
                      }}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 font-semibold text-[11px] transition-colors"
                      title={`Delete Floor ${activeBlueprintFloorNumber}`}
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Delete Floor</span>
                    </button>

                    <div className="flex items-center gap-2 border-l border-slate-200 pl-2">
                      <div className="flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-[#16A34A]" />
                        <span>Available</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-[#2563EB]" />
                        <span>Occupied</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-[#D97706]" />
                        <span>Dirty</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-[#DC2626]" />
                        <span>Maintenance</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Architectural Blueprint Floor Plan Diagram */}
                <div className="relative border-2 border-slate-300 rounded-xl p-3 bg-[#FDFEFE] shadow-inner select-none overflow-x-auto min-h-[300px]">
                  {activeFloorRooms.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-16 text-center space-y-3">
                      <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
                        <DoorClosed className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-800 text-sm">No Rooms on {activeFloorConfig.name}</h4>
                        <p className="text-xs text-slate-400 mt-1">
                          You can decide how many rooms belong to this floor.
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setFloorRoomCount(activeBlueprintFloorNumber, 12);
                            addToast({ type: 'success', title: 'Rooms Added', message: `Configured 12 default rooms on ${activeFloorConfig.name}.` });
                          }}
                          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs shadow-sm"
                        >
                          Generate 12 Rooms
                        </button>
                        <button
                          type="button"
                          onClick={handleOpenAddRoomModal}
                          className="px-4 py-2 border border-slate-200 rounded-xl text-slate-700 font-semibold text-xs hover:bg-slate-50"
                        >
                          Add Custom Room
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="min-w-[640px] space-y-3">
                      {/* Top Corridor Rooms */}
                      <div className="flex items-stretch gap-2">
                        {/* Lift Lobby graphic on left */}
                        <div className="w-20 bg-slate-100 border border-slate-300 rounded-lg p-2 flex flex-col justify-center items-center text-[10px] text-slate-500 font-semibold shrink-0">
                          <div>Lift Lobby</div>
                          <div className="flex gap-1 mt-1">
                            <span className="px-1 py-0.5 bg-white border rounded text-[9px]">L1</span>
                            <span className="px-1 py-0.5 bg-white border rounded text-[9px]">L2</span>
                          </div>
                          <span className="text-[9px] font-bold text-blue-600 mt-1">
                            FL {activeBlueprintFloorNumber}
                          </span>
                        </div>

                        {/* Top Row of Rooms */}
                        <div
                          className="grid gap-1.5 flex-1"
                          style={{
                            gridTemplateColumns: `repeat(${Math.max(topCorridorRooms.length, 1)}, minmax(0, 1fr))`
                          }}
                        >
                          {topCorridorRooms.map(room => {
                            const isSelected = selectedRoomNumber === room.roomNumber;
                            return (
                              <div
                                key={room.roomNumber}
                                onClick={() => {
                                  setSelectedRoomNumber(room.roomNumber);
                                  setIsDetailDrawerOpen(true);
                                }}
                                className={getPlanRoomStyle(room.status, isSelected)}
                              >
                                <Bed className="w-3.5 h-3.5 opacity-80" />
                                <div className="text-xs font-extrabold font-mono mt-1 leading-none">
                                  {room.roomNumber}
                                </div>
                                <div className="text-[9px] uppercase font-semibold mt-0.5 opacity-75 truncate max-w-full">
                                  {room.category === 'STANDARD' ? 'Std' : room.category === 'DELUXE' ? 'Deluxe' : 'Suite'}
                                </div>
                                {room.status === 'OCCUPIED' && room.guestName && (
                                  <div className="text-[8px] truncate max-w-full font-medium text-blue-800 mt-0.5 bg-blue-100/80 px-1 rounded">
                                    {room.guestName.split(' ')[0]}
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Central Hallway / Walkway */}
                      <div className="h-6 bg-slate-100/70 border-y border-dashed border-slate-300 flex items-center justify-between px-4 text-[10px] text-slate-400 uppercase tracking-widest font-mono">
                        <span>← West Wing / Fire Exit</span>
                        <span className="font-semibold text-slate-500">
                          Main Central Corridor ({activeFloorConfig.name})
                        </span>
                        <span>East Lake Balconies →</span>
                      </div>

                      {/* Bottom Corridor Rooms */}
                      <div className="flex items-stretch gap-2">
                        {/* Left Service Stairs */}
                        <div className="w-20 bg-slate-100 border border-slate-300 rounded-lg p-1.5 flex flex-col justify-center items-center text-[10px] text-slate-500 shrink-0">
                          <span className="font-semibold">Stairs &</span>
                          <span className="text-[9px] text-slate-400">Emergency</span>
                        </div>

                        {/* Bottom Row of Rooms */}
                        <div
                          className="grid gap-1.5 flex-1"
                          style={{
                            gridTemplateColumns: `repeat(${Math.max(bottomCorridorRooms.length + 1, 1)}, minmax(0, 1fr))`
                          }}
                        >
                          {bottomCorridorRooms.map(room => {
                            const isSelected = selectedRoomNumber === room.roomNumber;
                            return (
                              <div
                                key={room.roomNumber}
                                onClick={() => {
                                  setSelectedRoomNumber(room.roomNumber);
                                  setIsDetailDrawerOpen(true);
                                }}
                                className={getPlanRoomStyle(room.status, isSelected)}
                              >
                                <Bed className="w-3.5 h-3.5 opacity-80" />
                                <div className="text-xs font-extrabold font-mono mt-1 leading-none">
                                  {room.roomNumber}
                                </div>
                                <div className="text-[9px] uppercase font-semibold mt-0.5 opacity-75 truncate max-w-full">
                                  {room.category === 'STANDARD' ? 'Std' : room.category === 'DELUXE' ? 'Deluxe' : 'Suite'}
                                </div>
                                {room.status === 'OCCUPIED' && room.guestName && (
                                  <div className="text-[8px] truncate max-w-full font-medium text-blue-800 mt-0.5 bg-blue-100/80 px-1 rounded">
                                    {room.guestName.split(' ')[0]}
                                  </div>
                                )}
                              </div>
                            );
                          })}

                          {/* Quick Add Room Tile at the end of bottom corridor */}
                          <div
                            onClick={handleOpenAddRoomModal}
                            className="border-2 border-dashed border-slate-300 hover:border-blue-500 bg-slate-50/50 hover:bg-blue-50/40 rounded-lg p-2 flex flex-col justify-center items-center text-slate-400 hover:text-blue-600 cursor-pointer transition-all min-h-[58px]"
                            title="Add Room to this Floor"
                          >
                            <Plus className="w-4 h-4" />
                            <span className="text-[9px] font-bold mt-1">+ Room</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Floating Zoom Buttons bottom-right */}
                  <div className="absolute right-4 bottom-4 flex flex-col gap-1 bg-white/95 backdrop-blur-xs border border-slate-200 rounded-lg shadow-sm p-0.5">
                    <button
                      onClick={() => addToast({ type: 'info', title: 'Blueprint Zoom', message: 'Architectural vector zoom standard' })}
                      className="p-1 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => addToast({ type: 'info', title: 'Blueprint Reset', message: 'Floor blueprint scale 100%' })}
                      className="p-1 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Grid View Mode with Room Photo Cards & Thumbnail Gallery */}
          {activeView === 'GRID_VIEW' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {filteredTableRooms.map(r => {
                const isSelected = selectedRoomNumber === r.roomNumber;
                const roomPhotos = r.images && r.images.length > 0 ? r.images : ROOM_PHOTO_PRESETS;

                return (
                  <div
                    key={r.roomNumber}
                    onClick={() => {
                      setSelectedRoomNumber(r.roomNumber);
                      setIsDetailDrawerOpen(true);
                    }}
                    className={`bg-white rounded-2xl border transition-all shadow-2xs hover:shadow-md overflow-hidden cursor-pointer flex flex-col justify-between ${
                      isSelected ? 'border-blue-500 ring-2 ring-blue-500/20' : 'border-slate-200/90'
                    }`}
                  >
                    <div>
                      {/* Photo Thumbnail Hero */}
                      <div className="relative h-36 w-full bg-slate-100 overflow-hidden group">
                        <img
                          src={roomPhotos[0]}
                          alt={`Room ${r.roomNumber}`}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-xs text-white text-[10px] font-bold">
                          Room {r.roomNumber}
                        </div>
                        <div className="absolute top-2 right-2">
                          {getStatusBadge(r.status)}
                        </div>

                        {/* Thumbnail Count overlay */}
                        <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-black/60 backdrop-blur-xs text-white text-[10px] flex items-center gap-1 font-medium">
                          <Camera className="w-3 h-3" />
                          <span>{roomPhotos.length} Photos</span>
                        </div>
                      </div>

                      {/* Mini Thumbnail Gallery Strip */}
                      <div className="p-2.5 pb-0 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
                        {roomPhotos.slice(0, 4).map((img, i) => (
                          <div key={i} className="w-10 h-8 rounded-md overflow-hidden border border-slate-200 shrink-0">
                            <img src={img} alt="" className="w-full h-full object-cover" />
                          </div>
                        ))}
                        <button
                          onClick={e => {
                            e.stopPropagation();
                            setSelectedRoomNumber(r.roomNumber);
                            setIsPhotoManagerModalOpen(true);
                          }}
                          className="w-10 h-8 rounded-md border border-dashed border-slate-300 hover:border-blue-500 flex items-center justify-center text-slate-400 hover:text-blue-600 bg-slate-50 shrink-0"
                          title="Upload / Edit Pictures"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      {/* Card Content */}
                      <div className="p-3 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <div className="font-bold text-slate-900 text-xs">
                            {r.category === 'DELUXE' ? 'Deluxe Room' : r.category === 'SUITE' ? 'Executive Suite' : r.category === 'PRESIDENTIAL' ? 'Presidential Suite' : 'Standard Room'}
                          </div>
                          <div className="font-mono font-bold text-slate-900 text-xs">
                            {formatMoney(r.pricePerNight)}
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-[11px] text-slate-500">
                          <span>Housekeeping:</span>
                          {getHousekeepingBadge(r.cleaningStatus)}
                        </div>

                        {r.guestName && (
                          <div className="text-[11px] text-slate-600 truncate">
                            Guest: <strong className="text-slate-800">{r.guestName}</strong>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Card Footer Actions */}
                    <div className="p-2.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs">
                      <span className="text-[10px] text-slate-400 font-medium">Floor {r.floor}</span>
                      <button
                        onClick={e => {
                          e.stopPropagation();
                          setSelectedRoomNumber(r.roomNumber);
                          setIsPhotoManagerModalOpen(true);
                        }}
                        className="text-blue-600 hover:underline font-semibold text-[11px] flex items-center gap-1"
                      >
                        <Camera className="w-3 h-3" />
                        <span>Manage Photos</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Bottom Rooms Table with Dynamic Status Subtabs */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-2xs space-y-4">
            {/* Table Tabs Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-1.5 overflow-x-auto text-xs font-semibold scrollbar-none">
                {[
                  { id: 'ALL', label: `All Rooms (${tableStatusCounts.all})` },
                  { id: 'OCCUPIED', label: `Occupied (${tableStatusCounts.occupied})` },
                  { id: 'AVAILABLE', label: `Available (${tableStatusCounts.available})` },
                  { id: 'DIRTY', label: `Dirty (${tableStatusCounts.dirty})` },
                  { id: 'MAINTENANCE', label: `Maintenance (${tableStatusCounts.maintenance})` },
                  { id: 'OUT_OF_ORDER', label: `Out of Order (${tableStatusCounts.outOfOrder})` }
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setTableStatusTab(tab.id)}
                    className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
                      tableStatusTab === tab.id
                        ? 'text-blue-600 bg-blue-50 font-bold'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* Export & Table Settings buttons */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => {
                    window.print();
                    addToast({ type: 'info', title: 'Exporting Room Roster', message: 'Generating print/PDF report.' });
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors"
                >
                  <Download className="w-3.5 h-3.5 text-slate-500" />
                  <span>Export</span>
                </button>
                <button
                  onClick={() => setIsFloorConfigModalOpen(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors"
                  title="Configure Floors & Rooms"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5 text-slate-500" />
                  <span>Configure Floors</span>
                </button>
              </div>
            </div>

            {/* Room Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50/80 text-slate-500 font-semibold text-[11px] uppercase tracking-wider">
                  <tr>
                    <th className="py-2.5 px-3 w-8">
                      <input
                        type="checkbox"
                        checked={selectedTableRows.length > 0 && selectedTableRows.length === filteredTableRooms.length}
                        onChange={e => {
                          if (e.target.checked) {
                            setSelectedTableRows(filteredTableRooms.map(r => r.roomNumber));
                          } else {
                            setSelectedTableRows([]);
                          }
                        }}
                        className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                      />
                    </th>
                    <th className="py-2.5 px-3">Room No.</th>
                    <th className="py-2.5 px-3">Floor</th>
                    <th className="py-2.5 px-3">Room Type</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Housekeeping</th>
                    <th className="py-2.5 px-3">Guest Name</th>
                    <th className="py-2.5 px-3">Rate ({currency})</th>
                    <th className="py-2.5 px-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredTableRooms.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-8 text-center text-slate-400">
                        No rooms match the selected floor or filter criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredTableRooms.map(r => {
                      const isSelected = selectedRoomNumber === r.roomNumber;
                      const isChecked = selectedTableRows.includes(r.roomNumber);

                      return (
                        <tr
                          key={r.roomNumber}
                          onClick={() => {
                            setSelectedRoomNumber(r.roomNumber);
                            setIsDetailDrawerOpen(true);
                          }}
                          className={`hover:bg-slate-50/80 cursor-pointer transition-colors ${
                            isSelected ? 'bg-blue-50/30' : ''
                          }`}
                        >
                          <td className="py-2.5 px-3" onClick={e => e.stopPropagation()}>
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={() => {
                                setSelectedTableRows(prev =>
                                  prev.includes(r.roomNumber)
                                    ? prev.filter(num => num !== r.roomNumber)
                                    : [...prev, r.roomNumber]
                                );
                              }}
                              className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                            />
                          </td>
                          <td className="py-2.5 px-3 font-mono font-bold text-slate-900">
                            {r.roomNumber}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-slate-600">
                            Floor {r.floor}
                          </td>
                          <td className="py-2.5 px-3 font-medium text-slate-700">
                            {r.category === 'DELUXE' ? 'Deluxe' : r.category === 'SUITE' ? 'Suite' : r.category === 'PRESIDENTIAL' ? 'Presidential' : 'Standard'}
                          </td>
                          <td className="py-2.5 px-3">
                            {getStatusBadge(r.status)}
                          </td>
                          <td className="py-2.5 px-3">
                            {getHousekeepingBadge(r.cleaningStatus)}
                          </td>
                          <td className="py-2.5 px-3 text-slate-600 font-medium">
                            {r.guestName || '-'}
                          </td>
                          <td className="py-2.5 px-3 font-mono font-bold text-slate-900">
                            {formatMoney(r.pricePerNight)}
                          </td>
                          <td className="py-2.5 px-3 text-right" onClick={e => e.stopPropagation()}>
                            <button
                              onClick={() => {
                                setSelectedRoomNumber(r.roomNumber);
                                setIsDetailDrawerOpen(true);
                              }}
                              className="p-1 text-slate-400 hover:text-slate-700 rounded"
                            >
                              <MoreHorizontal className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* 5. Right-Hand Room Detail Card / Drawer */}
        {isDetailDrawerOpen && (
          <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden sticky top-6 space-y-4 select-none">
            {/* Header: Room Title + Status badge + Close X */}
            <div className="p-4 pb-0 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <h3 className="text-xl font-bold text-slate-900">Room {activeSelectedRoom.roomNumber}</h3>
                {getStatusBadge(activeSelectedRoom.status)}
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => setIsPhotoManagerModalOpen(true)}
                  className="p-1.5 text-slate-400 hover:text-blue-600 rounded-lg hover:bg-slate-100"
                  title="Upload / Manage Room Photos"
                >
                  <Camera className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setIsDetailDrawerOpen(false)}
                  className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
                  title="Close Drawer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Room Image Carousel Hero */}
            <div className="px-4">
              <div className="relative h-44 rounded-xl overflow-hidden bg-slate-900 border border-slate-200 group">
                <img
                  src={currentRoomPhotos[activePhotoIndex] || ROOM_PHOTO_PRESETS[0]}
                  alt={`Room ${activeSelectedRoom.roomNumber}`}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />

                {/* Left/Right Prev/Next Photo Buttons */}
                {currentRoomPhotos.length > 1 && (
                  <>
                    <button
                      onClick={e => {
                        e.stopPropagation();
                        setActivePhotoIndex(prev => (prev === 0 ? currentRoomPhotos.length - 1 : prev - 1));
                      }}
                      className="absolute left-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-black/50 hover:bg-black/70 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <button
                      onClick={e => {
                        e.stopPropagation();
                        setActivePhotoIndex(prev => (prev === currentRoomPhotos.length - 1 ? 0 : prev + 1));
                      }}
                      className="absolute right-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-black/50 hover:bg-black/70 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </>
                )}

                {/* Photo Count badge */}
                <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-black/60 backdrop-blur-xs text-white text-[10px] flex items-center gap-1 font-mono">
                  <Camera className="w-3 h-3" />
                  <span>{activePhotoIndex + 1}/{currentRoomPhotos.length}</span>
                </div>
              </div>
            </div>

            {/* Room Info Row: Category + Rate */}
            <div className="px-4 flex items-baseline justify-between border-b border-slate-100 pb-3">
              <div>
                <div className="text-base font-bold text-slate-900">
                  {activeSelectedRoom.category === 'DELUXE' ? 'Deluxe Room' : activeSelectedRoom.category === 'SUITE' ? 'Executive Suite' : activeSelectedRoom.category === 'PRESIDENTIAL' ? 'Presidential Suite' : 'Standard Room'}
                </div>
                <div className="text-xs text-slate-400 mt-0.5">
                  Floor {activeSelectedRoom.floor} · {activeSelectedRoom.wing || 'Lake Wing'}
                </div>
              </div>

              <div className="text-right">
                <div className="text-base font-extrabold text-slate-900 font-mono">
                  {formatMoney(activeSelectedRoom.pricePerNight)}
                </div>
                <div className="text-[10px] text-slate-400 uppercase tracking-wider font-medium">Nightly Rate</div>
              </div>
            </div>

            {/* Sub-Tabs: Details | Guest | Housekeeping | Maintenance */}
            <div className="px-4">
              <div className="flex border-b border-slate-200 text-xs font-semibold space-x-5">
                {[
                  { id: 'DETAILS', label: 'Details' },
                  { id: 'GUEST', label: 'Guest' },
                  { id: 'HOUSEKEEPING', label: 'Housekeeping' },
                  { id: 'MAINTENANCE', label: 'Maintenance' }
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setDetailSubTab(tab.id as any)}
                    className={`pb-2 transition-all relative ${
                      detailSubTab === tab.id
                        ? 'text-blue-600 font-bold'
                        : 'text-slate-400 hover:text-slate-700'
                    }`}
                  >
                    <span>{tab.label}</span>
                    {detailSubTab === tab.id && (
                      <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600 rounded-full" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Sub-tab Content: Details */}
            {detailSubTab === 'DETAILS' && (
              <div className="px-4 space-y-4 text-xs">
                {/* Key-Value Specifications */}
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Room Status</span>
                    {getStatusBadge(activeSelectedRoom.status)}
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Floor</span>
                    <span className="font-semibold text-slate-900">Floor {activeSelectedRoom.floor}</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Bed Type</span>
                    <span className="font-semibold text-slate-900">{activeSelectedRoom.bedConfig || '1 King Bed'}</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Max Occupancy</span>
                    <span className="font-semibold text-slate-900">{activeSelectedRoom.maxOccupancy || 2} Adults</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Room Size</span>
                    <span className="font-semibold text-slate-900 font-mono">{activeSelectedRoom.sizeSqm || 42} m²</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">View</span>
                    <span className="font-semibold text-slate-900">{activeSelectedRoom.viewType || 'Lake Hawassa View'}</span>
                  </div>
                </div>

                {/* Features Tag Chips */}
                <div className="space-y-2 pt-2 border-t border-slate-100">
                  <span className="text-xs font-semibold text-slate-700 block">Amenities</span>
                  <div className="flex flex-wrap gap-1.5">
                    {(activeSelectedRoom.amenities && activeSelectedRoom.amenities.length > 0
                      ? activeSelectedRoom.amenities
                      : ['King Bed', 'City View', 'Minibar', 'Free Wi-Fi', 'Smart TV']
                    ).map((amenity, i) => (
                      <span key={i} className="px-2 py-0.5 rounded-lg bg-slate-100 text-slate-700 text-[11px] font-medium flex items-center gap-1">
                        <Tag className="w-2.5 h-2.5 text-slate-400" />
                        <span>{amenity}</span>
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Sub-tab Content: Guest */}
            {detailSubTab === 'GUEST' && (
              <div className="px-4 space-y-3 text-xs">
                {activeSelectedRoom.guestName ? (
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/90 space-y-2">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs">
                        {activeSelectedRoom.guestName.slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-bold text-slate-900">{activeSelectedRoom.guestName}</div>
                        <div className="text-[11px] text-slate-400">Currently Checked In</div>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-200/60 text-[11px]">
                      <div>
                        <span className="text-slate-400 block">Check In</span>
                        <span className="font-semibold text-slate-800">{activeSelectedRoom.checkInDate || 'Active Stay'}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Check Out</span>
                        <span className="font-semibold text-slate-800">{activeSelectedRoom.checkOutDate || 'Scheduled'}</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-6 text-slate-400 text-xs">
                    No active guest checked into Room {activeSelectedRoom.roomNumber}.
                  </div>
                )}
              </div>
            )}

            {/* Sub-tab Content: Housekeeping */}
            {detailSubTab === 'HOUSEKEEPING' && (
              <div className="px-4 space-y-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/90 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 font-medium">Turnaround Status</span>
                    {getHousekeepingBadge(activeSelectedRoom.cleaningStatus)}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 font-medium">Assigned Housekeeper</span>
                    <span className="font-semibold text-slate-900">{activeSelectedRoom.assignedHousekeeper || 'Housekeeping Team'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 font-medium">Last Cleaned</span>
                    <span className="font-mono text-slate-700">{activeSelectedRoom.lastCleaned || 'Today, 09:30 AM'}</span>
                  </div>
                </div>
              </div>
            )}

            {/* Sub-tab Content: Maintenance */}
            {detailSubTab === 'MAINTENANCE' && (
              <div className="px-4 space-y-3 text-xs">
                <div className="p-3 bg-rose-50/70 border border-rose-200 rounded-xl space-y-2 text-rose-900">
                  <div className="font-bold flex items-center gap-1.5">
                    <Wrench className="w-4 h-4 text-rose-600" />
                    <span>Work Order Inspection</span>
                  </div>
                  <p className="text-[11px] leading-relaxed text-rose-800">
                    AC thermostat calibration, lock battery status & plumbing pressure check.
                  </p>
                  <div className="text-[10px] text-rose-600 font-semibold pt-1">
                    Engineering Status: Routine Maintenance
                  </div>
                </div>
              </div>
            )}

            {/* Bottom Action Buttons */}
            <div className="p-4 pt-2 space-y-2 border-t border-slate-100">
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    toggleRoomStatus(activeSelectedRoom.id, 'AVAILABLE');
                    addToast({ type: 'success', title: 'Room Status', message: `Room ${activeSelectedRoom.roomNumber} marked Available.` });
                  }}
                  className="py-2.5 px-3 bg-[#2563EB] hover:bg-blue-700 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 shadow-sm transition-colors"
                >
                  <Bed className="w-3.5 h-3.5" />
                  <span>Mark Available</span>
                </button>

                <button
                  onClick={() => {
                    toggleRoomStatus(activeSelectedRoom.id, 'DIRTY');
                    addToast({ type: 'warning', title: 'Room Status', message: `Room ${activeSelectedRoom.roomNumber} marked Dirty for cleaning.` });
                  }}
                  className="py-2.5 px-3 bg-white hover:bg-amber-50 border border-slate-200 hover:border-amber-300 text-slate-700 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>Mark Dirty</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    toggleRoomStatus(activeSelectedRoom.id, 'MAINTENANCE');
                    addToast({ type: 'info', title: 'Maintenance Ticket', message: `Work order dispatched for Room ${activeSelectedRoom.roomNumber}.` });
                  }}
                  className="py-2.5 px-3 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Wrench className="w-3.5 h-3.5 text-slate-500" />
                  <span>Maintenance</span>
                </button>

                <button
                  onClick={() => {
                    toggleRoomStatus(activeSelectedRoom.id, 'CHECKED_OUT');
                    addToast({ type: 'error', title: 'Room Blocked', message: `Room ${activeSelectedRoom.roomNumber} marked Out of Order.` });
                  }}
                  className="py-2.5 px-3 bg-white hover:bg-rose-50 border border-slate-200 hover:border-rose-300 text-rose-600 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Lock className="w-3.5 h-3.5 text-rose-500" />
                  <span>Block Room</span>
                </button>
              </div>

              {/* Room Delete Button */}
              <div className="pt-1">
                <button
                  onClick={() => deleteRoom(activeSelectedRoom.id)}
                  className="w-full py-2 px-3 border border-slate-200 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 transition-colors text-slate-500 hover:text-rose-600 hover:bg-rose-50 hover:border-rose-200"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Remove Room from Property</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 6. QUICK ROOM COUNT ADJUSTER MODAL (User Request: decide how many rooms on each floor, including 0) */}
      {isQuickAdjustOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 space-y-4 text-xs font-sans">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-blue-600" />
                <h3 className="font-bold text-slate-900 text-sm">
                  Adjust Floor {quickAdjustFloorNum} Rooms
                </h3>
              </div>
              <button onClick={() => setIsQuickAdjustOpen(false)} className="p-1 text-slate-400 hover:text-slate-700">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-slate-500">
              Decide how many rooms belong on Floor {quickAdjustFloorNum}. You can set any count, including 0 to clear all rooms.
            </p>

            <div className="flex items-center justify-center gap-3 p-4 bg-slate-50 rounded-xl border border-slate-200">
              <button
                type="button"
                onClick={() => setQuickAdjustCount(prev => Math.max(0, prev - 1))}
                className="w-10 h-10 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 font-bold text-lg flex items-center justify-center shadow-2xs"
              >
                -
              </button>
              <div className="text-center px-4">
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={quickAdjustCount}
                  onChange={e => {
                    const v = parseInt(e.target.value, 10);
                    setQuickAdjustCount(isNaN(v) ? 0 : Math.max(0, v));
                  }}
                  className="w-16 text-center font-mono font-bold text-2xl text-slate-900 bg-transparent focus:outline-none"
                />
                <span className="block text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Rooms</span>
              </div>
              <button
                type="button"
                onClick={() => setQuickAdjustCount(prev => prev + 1)}
                className="w-10 h-10 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 font-bold text-lg flex items-center justify-center shadow-2xs"
              >
                +
              </button>
            </div>

            {/* Quick Presets Including 0 */}
            <div className="flex items-center justify-between px-1">
              <button
                type="button"
                onClick={() => setQuickAdjustCount(0)}
                className="text-xs text-rose-600 hover:underline font-semibold"
              >
                Clear all (Set to 0)
              </button>
              <div className="flex gap-1.5">
                {[8, 12, 16, 20].map(cnt => (
                  <button
                    key={cnt}
                    type="button"
                    onClick={() => setQuickAdjustCount(cnt)}
                    className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-medium"
                  >
                    {cnt} rms
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsQuickAdjustOpen(false)}
                className="px-4 py-2 border border-slate-200 rounded-xl font-semibold text-slate-600 hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  setFloorRoomCount(quickAdjustFloorNum, quickAdjustCount);
                  setIsQuickAdjustOpen(false);
                }}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-sm"
              >
                Save Room Count
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 7. FULL CUSTOM FLOOR PLAN & ROOMS CONFIGURATION MODAL */}
      <FloorPlanConfigModal
        isOpen={isFloorConfigModalOpen}
        onClose={() => setIsFloorConfigModalOpen(false)}
        initialFloor={floorConfigInitialFloor}
      />

      {/* 8. MULTIPLE ROOM PICTURES UPLOADER & THUMBNAIL MANAGER MODAL */}
      {isPhotoManagerModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl border border-slate-200 space-y-5 text-xs font-sans">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <Camera className="w-5 h-5 text-blue-600" />
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Room {activeSelectedRoom.roomNumber} Photo Gallery & Uploader
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Upload multiple pictures, set thumbnail cover, or arrange high-res photo gallery
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsPhotoManagerModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Upload Action Box */}
            <div className="p-4 bg-blue-50/50 border-2 border-dashed border-blue-200 rounded-xl text-center space-y-3">
              <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mx-auto">
                <Upload className="w-5 h-5" />
              </div>
              <div>
                <span className="font-bold text-slate-900 block text-xs">Upload Multiple Room Pictures</span>
                <span className="text-[11px] text-slate-500">Supports JPG, PNG, WEBP. Drag and drop or browse local files</span>
              </div>

              <input
                type="file"
                multiple
                accept="image/*"
                ref={fileInputRef}
                onChange={handleLocalFileUpload}
                className="hidden"
              />

              <div className="flex items-center justify-center gap-2">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold shadow-xs flex items-center gap-1.5 text-xs"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Choose Image Files</span>
                </button>
              </div>
            </div>

            {/* Add via URL */}
            <div className="space-y-1.5">
              <label className="block font-semibold text-slate-700 text-xs">Or Add Image via Web URL</label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={newPhotoUrlInput}
                  onChange={e => setNewPhotoUrlInput(e.target.value)}
                  placeholder="https://images.unsplash.com/photo-..."
                  className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono text-slate-900 focus:ring-1 focus:ring-blue-500"
                />
                <button
                  type="button"
                  onClick={handleAddPhotoUrl}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-semibold text-xs"
                >
                  Add Picture
                </button>
              </div>
            </div>

            {/* Quick Luxury Presets Picker */}
            <div className="space-y-1.5">
              <span className="block font-semibold text-slate-700 text-xs">Quick Room Photo Presets</span>
              <div className="grid grid-cols-6 gap-2">
                {ROOM_PHOTO_PRESETS.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      uploadRoomPhotos(activeSelectedRoom.id, [preset]);
                    }}
                    className="relative h-14 rounded-lg overflow-hidden border border-slate-200 group"
                    title="Click to add preset photo"
                  >
                    <img src={preset} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                      <Plus className="w-4 h-4" />
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Current Active Room Gallery with Thumbnail Grid */}
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 text-xs">
                  Current Gallery ({currentRoomPhotos.length} Pictures)
                </span>
                <span className="text-[11px] text-slate-400">Click a picture to set as Cover or Delete</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {currentRoomPhotos.map((photo, i) => {
                  const isCover = i === 0;

                  return (
                    <div
                      key={i}
                      className="group relative h-28 rounded-xl overflow-hidden border border-slate-200 bg-slate-100 shadow-2xs"
                    >
                      <img src={photo} alt="" className="w-full h-full object-cover" />
                      
                      {isCover && (
                        <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-blue-600 text-white text-[9px] font-bold shadow-md">
                          COVER THUMBNAIL
                        </div>
                      )}

                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 p-2">
                        {!isCover && (
                          <button
                            type="button"
                            onClick={() => handleSetCoverPhoto(photo)}
                            className="px-2 py-1 rounded bg-white text-slate-800 text-[10px] font-bold hover:bg-blue-50 hover:text-blue-600 transition-colors shadow-sm"
                            title="Set as Main Room Thumbnail"
                          >
                            Set Cover
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => handleDeletePhoto(photo)}
                          className="p-1.5 rounded bg-rose-600 hover:bg-rose-700 text-white transition-colors shadow-sm"
                          title="Delete Picture"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsPhotoManagerModalOpen(false)}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold text-xs shadow-sm"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 9. ADD ROOM MODAL */}
      {isAddRoomModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl border border-slate-200 space-y-4 text-xs font-sans">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Plus className="w-5 h-5 text-blue-600" />
                <h3 className="text-base font-bold text-slate-900">Add New Hotel Room</h3>
              </div>
              <button onClick={() => setIsAddRoomModalOpen(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveNewRoom} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Room Number *</label>
                  <input
                    type="text"
                    required
                    value={formRoomNo}
                    onChange={e => setFormRoomNo(e.target.value)}
                    placeholder="e.g. 121"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-bold font-mono text-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Floor *</label>
                  <select
                    value={formFloor}
                    onChange={e => setFormFloor(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-900"
                  >
                    {[...floors].sort((a, b) => a.floorNumber - b.floorNumber).map(fl => (
                      <option key={fl.floorNumber} value={fl.floorNumber}>
                        {fl.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Category *</label>
                  <select
                    value={formCategory}
                    onChange={e => setFormCategory(e.target.value as RoomCategory)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-900"
                  >
                    <option value="STANDARD">Standard Room</option>
                    <option value="DELUXE">Deluxe Room</option>
                    <option value="SUITE">Executive Suite</option>
                    <option value="PRESIDENTIAL">Presidential Suite</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nightly Rate ({currency}) *</label>
                  <input
                    type="number"
                    min={50}
                    value={formRate}
                    onChange={e => setFormRate(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-mono font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Bed Configuration</label>
                  <input
                    type="text"
                    value={formBedType}
                    onChange={e => setFormBedType(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Room Size (m²)</label>
                  <input
                    type="number"
                    value={formSize}
                    onChange={e => setFormSize(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-mono text-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Status</label>
                  <select
                    value={formStatus}
                    onChange={e => setFormStatus(e.target.value as RoomStatus)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-900"
                  >
                    <option value="AVAILABLE">Available</option>
                    <option value="OCCUPIED">Occupied</option>
                    <option value="DIRTY">Dirty</option>
                    <option value="MAINTENANCE">Maintenance</option>
                  </select>
                </div>
              </div>

              {/* Photo selector for new room */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1.5">Attach Initial Photos</label>
                <div className="grid grid-cols-3 gap-2">
                  {ROOM_PHOTO_PRESETS.slice(0, 3).map((p, idx) => (
                    <div key={idx} className="h-16 rounded-lg overflow-hidden border border-slate-200 relative">
                      <img src={p} alt="" className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddRoomModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold shadow-sm"
                >
                  Create Room
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
