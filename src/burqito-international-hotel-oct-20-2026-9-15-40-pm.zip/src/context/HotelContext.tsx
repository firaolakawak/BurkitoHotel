/**
 * Global Hotel & Inventory Management System Context
 * Provides real-time synchronization, toast alerts, and action triggers across PMS & IMS.
 */

import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import {
  Room,
  Booking,
  GuestFolio,
  InventoryItem,
  WarehouseLocation,
  StockTransfer,
  PurchaseOrder,
  HousekeepingTask,
  MaintenanceTicket,
  PosProduct,
  WarehouseLocationId,
  Employee,
  StaffStatus,
  NavigationTab,
  HotelCurrency,
  HotelInfo,
  RoomStatus,
  FloorConfig,
  RoomCategory
} from '../types/index.ts';
import { INITIAL_STAFF } from '../data/staffData.ts';
import { POS_MENU_ITEMS, PosMenuItem } from '../data/posMenuData.ts';
import { apiService } from '../services/api.ts';
import { db } from '../server/database.ts';

export interface ToastMessage {
  id: string;
  type: 'success' | 'warning' | 'error' | 'info';
  title: string;
  message: string;
  timestamp: string;
}

interface HotelContextType {
  // Hotel Details & Currency
  hotelInfo: HotelInfo;
  updateHotelInfo: (updates: Partial<HotelInfo>) => void;
  currency: HotelCurrency;
  setCurrency: (currency: HotelCurrency) => void;
  toggleCurrency: () => void;
  exchangeRate: number;
  formatMoney: (amountInETB: number, opts?: { showBoth?: boolean; compact?: boolean }) => string;

  // Data state
  rooms: Room[];
  bookings: Booking[];
  inventoryItems: InventoryItem[];
  warehouseLocations: WarehouseLocation[];
  stockTransfers: StockTransfer[];
  purchaseOrders: PurchaseOrder[];
  housekeepingTasks: HousekeepingTask[];
  maintenanceTickets: MaintenanceTicket[];
  posProducts: PosProduct[];
  consumptionLogs: any[];
  isLoading: boolean;
  toasts: ToastMessage[];

  // Metrics
  metrics: {
    totalRooms: number;
    occupiedRooms: number;
    occupancyRate: number;
    dirtyRooms: number;
    maintenanceRooms: number;
    availableRooms: number;
    revPar: number;
    adr: number;
    lowStockCount: number;
    openMaintenanceCount: number;
    pendingHousekeepingCount: number;
    totalInventoryValue: number;
  };
  kpis: {
    totalRooms: number;
    occupiedRooms: number;
    occupancyRate: number;
    dirtyRooms: number;
    maintenanceRooms: number;
    availableRooms: number;
    revPar: number;
    adr: number;
    lowStockCount: number;
    openMaintenanceCount: number;
    pendingHousekeepingCount: number;
    totalInventoryValue: number;
  };

  // Modals & Active Selections
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  selectedRoom: Room | null;
  setSelectedRoom: (room: Room | null) => void;
  selectedInventoryItem: InventoryItem | null;
  setSelectedInventoryItem: (item: InventoryItem | null) => void;
  employees: Employee[];
  selectedEmployee: Employee | null;
  setSelectedEmployee: (emp: Employee | null) => void;
  isAddStaffOpen: boolean;
  setIsAddStaffOpen: (open: boolean) => void;
  addEmployee: (emp: Partial<Employee>) => void;
  updateEmployeeStatus: (id: string, status: StaffStatus) => void;
  deleteEmployee: (id: string) => void;
  deleteEmployees: (ids: string[]) => void;
  isBookingWizardOpen: boolean;
  setIsBookingWizardOpen: (open: boolean) => void;
  bookingWizardInitialRoomId?: string | null;
  openBookingWizardForRoom: (roomId?: string) => void;
  isCheckOutModalOpen: boolean;
  setIsCheckOutModalOpen: (open: boolean) => void;
  checkOutBooking: Booking | null;
  openCheckOutModal: (booking: Booking) => void;
  isStockTransferOpen: boolean;
  setIsStockTransferOpen: (open: boolean) => void;
  stockTransferItem: InventoryItem | null;
  openStockTransferModal: (item?: InventoryItem) => void;
  isPurchaseOrderOpen: boolean;
  setIsPurchaseOrderOpen: (open: boolean) => void;
  isMaintenanceModalOpen: boolean;
  setIsMaintenanceModalOpen: (open: boolean) => void;
  maintenanceRoom: Room | null;
  openMaintenanceModal: (room?: Room) => void;
  isFolioModalOpen: boolean;
  setIsFolioModalOpen: (open: boolean) => void;
  folioModalBooking: Booking | null;
  openFolioModal: (booking: Booking) => void;

  // Actions
  saveAllChanges: () => void;
  refreshAllData: () => Promise<void>;
  resetAllData: () => Promise<void>;
  createBooking: (payload: any) => Promise<boolean>;
  checkInGuest: (bookingId: string) => Promise<boolean>;
  checkOutGuest: (bookingId: string, paymentMethod?: string) => Promise<boolean>;
  transferStock: (payload: {
    itemId: string;
    fromLocation: WarehouseLocationId;
    toLocation: WarehouseLocationId;
    quantity: number;
    reason: string;
    staffName: string;
  }) => Promise<boolean>;
  postPosCharge: (payload: {
    roomNumber: string;
    category: 'FOOD_BEVERAGE' | 'MINIBAR' | 'SPA';
    description: string;
    amount: number;
    serverName: string;
  }) => Promise<boolean>;
  updateHousekeepingTask: (id: string, status: string, notes?: string) => Promise<boolean>;
  createMaintenanceTicket: (payload: any) => Promise<boolean>;
  resolveMaintenanceTicket: (id: string) => Promise<boolean>;
  createPurchaseOrder: (payload: any) => Promise<boolean>;
  transitionPOStatus: (poId: string, status: string, receiveQtyMap?: Record<string, number>) => Promise<boolean>;
  
  // Room & Custom Floor Plan Management
  floors: FloorConfig[];
  setFloors: React.Dispatch<React.SetStateAction<FloorConfig[]>>;
  addFloor: (config: {
    floorNumber: number;
    name: string;
    wing?: string;
    roomCount: number;
    startRoomNumber?: number;
    defaultCategory?: RoomCategory;
    defaultRate?: number;
  }) => void;
  updateFloor: (floorNumber: number, updates: Partial<FloorConfig>) => void;
  deleteFloor: (floorNumber: number) => void;
  setFloorRoomCount: (floorNumber: number, newCount: number, defaultCategory?: RoomCategory, defaultRate?: number) => void;
  addRoom: (room: Omit<Room, 'id'>) => void;
  updateRoom: (id: string, updates: Partial<Room>) => void;
  deleteRoom: (id: string) => void;
  toggleRoomStatus: (id: string, status: RoomStatus) => void;
  bulkUpdateRooms: (roomIds: string[], updates: Partial<Room>) => void;
  uploadRoomPhotos: (roomId: string, newPhotoUrls: string[]) => void;
  deleteRoomPhoto: (roomId: string, photoUrl: string) => void;
  setRoomCoverPhoto: (roomId: string, photoUrl: string) => void;
  clearAllOccupiedAndResetFrontDesk: () => Promise<void>;

  // Menu Management
  menuItems: PosMenuItem[];
  setMenuItems: React.Dispatch<React.SetStateAction<PosMenuItem[]>>;
  addMenuItem: (item: Omit<PosMenuItem, 'id'>) => void;
  updateMenuItem: (id: string, updates: Partial<PosMenuItem>) => void;
  deleteMenuItem: (id: string) => void;
  toggleMenuItemAvailability: (id: string) => void;
  bulkUpdateMenuPrices: (category: string, amountOrPercent: number, isPercent: boolean) => void;

  addToast: (toast: Omit<ToastMessage, 'id' | 'timestamp'>) => void;
  removeToast: (id: string) => void;
}

const HotelContext = createContext<HotelContextType | undefined>(undefined);

export const HotelProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [rooms, setRooms] = useState<Room[]>(() => {
    const saved = localStorage.getItem('bih_rooms');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          parsed.forEach(r => db.rooms.set(r.id, r));
          return parsed;
        }
      } catch (e) {}
    }
    const defaultRooms: Room[] = [];
    for (let num = 1; num <= 24; num++) {
      const roomNum = `5${num < 10 ? '0' + num : num}`;
      const roomId = `rm-${roomNum}`;
      const cat: RoomCategory = num <= 6 ? 'SUITE' : num <= 16 ? 'DELUXE' : 'STANDARD';
      const rate = cat === 'SUITE' ? 1200 : cat === 'DELUXE' ? 850 : 650;
      const room: Room = {
        id: roomId,
        roomNumber: roomNum,
        floor: 5,
        category: cat,
        pricePerNight: rate,
        status: 'AVAILABLE',
        cleaningStatus: 'CLEAN',
        maxOccupancy: cat === 'SUITE' ? 4 : 2,
        bedConfig: cat === 'SUITE' ? '1 King Bed + Living Area' : '1 King Bed',
        amenities: ['High-speed Wi-Fi', 'Smart TV 55"', 'Rain Shower', 'Mini Bar', 'Ocean View Balcony'],
        wing: 'Lake Wing'
      };
      defaultRooms.push(room);
      db.rooms.set(roomId, room);
    }
    return defaultRooms;
  });

  useEffect(() => {
    localStorage.setItem('bih_rooms', JSON.stringify(rooms));
  }, [rooms]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>([]);
  const [warehouseLocations, setWarehouseLocations] = useState<WarehouseLocation[]>([]);
  const [stockTransfers, setStockTransfers] = useState<StockTransfer[]>([]);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([]);
  const [housekeepingTasks, setHousekeepingTasks] = useState<HousekeepingTask[]>([]);
  const [maintenanceTickets, setMaintenanceTickets] = useState<MaintenanceTicket[]>([]);
  const [posProducts, setPosProducts] = useState<PosProduct[]>([]);
  const [consumptionLogs, setConsumptionLogs] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Navigation tab
  const [activeTab, setActiveTab] = useState<NavigationTab>('PMS_GRID');

  // Staff State (Persisted)
  const [employees, setEmployees] = useState<Employee[]>(() => {
    const saved = localStorage.getItem('bih_employees');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return INITIAL_STAFF;
  });

  useEffect(() => {
    localStorage.setItem('bih_employees', JSON.stringify(employees));
  }, [employees]);

  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(employees[0] || INITIAL_STAFF[0]);
  const [isAddStaffOpen, setIsAddStaffOpen] = useState(false);

  // Modals state
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [selectedInventoryItem, setSelectedInventoryItem] = useState<InventoryItem | null>(null);
  const [isBookingWizardOpen, setIsBookingWizardOpen] = useState(false);
  const [bookingWizardInitialRoomId, setBookingWizardInitialRoomId] = useState<string | null>(null);
  const [isCheckOutModalOpen, setIsCheckOutModalOpen] = useState(false);
  const [checkOutBooking, setCheckOutBooking] = useState<Booking | null>(null);
  const [isStockTransferOpen, setIsStockTransferOpen] = useState(false);
  const [stockTransferItem, setStockTransferItem] = useState<InventoryItem | null>(null);
  const [isPurchaseOrderOpen, setIsPurchaseOrderOpen] = useState(false);
  const [isMaintenanceModalOpen, setIsMaintenanceModalOpen] = useState(false);
  const [maintenanceRoom, setMaintenanceRoom] = useState<Room | null>(null);
  const [isFolioModalOpen, setIsFolioModalOpen] = useState(false);
  const [folioModalBooking, setFolioModalBooking] = useState<Booking | null>(null);

  // Currency & Hotel Property Config (Persisted)
  const [currency, setCurrency] = useState<HotelCurrency>(() => {
    const saved = localStorage.getItem('bih_currency');
    return (saved as HotelCurrency) || 'ETB';
  });

  useEffect(() => {
    localStorage.setItem('bih_currency', currency);
  }, [currency]);

  const exchangeRate = 125; // 1 USD = 125 ETB (Ethiopian Birr)

  // Custom Floors & Layout Configuration (Persisted)
  const [floors, setFloors] = useState<FloorConfig[]>(() => {
    const saved = localStorage.getItem('bih_floors');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return [
      { floorNumber: 1, name: 'Floor 1', wing: 'Lake Wing', description: 'Standard & Deluxe Rooms' },
      { floorNumber: 2, name: 'Floor 2', wing: 'Lake Wing', description: 'Deluxe Lake View & Executive Rooms' },
      { floorNumber: 3, name: 'Floor 3', wing: 'Central Tower', description: 'Central Tower City & Mountain View' },
      { floorNumber: 4, name: 'Floor 4', wing: 'Central Tower', description: 'Premium Executive Tower' },
      { floorNumber: 5, name: 'Floor 5', wing: 'Lake Wing', description: 'Penthouse & Presidential Suites' },
      { floorNumber: 6, name: 'Floor 6', wing: 'Promenade Wing', description: 'Panoramic Lake Horizon Suites' },
    ];
  });

  useEffect(() => {
    localStorage.setItem('bih_floors', JSON.stringify(floors));
  }, [floors]);

  // Dynamic F&B Menu Catalog for Burqito Outlets
  const [menuItems, setMenuItems] = useState<PosMenuItem[]>(() =>
    POS_MENU_ITEMS.map(item => ({
      ...item,
      isAvailable: item.isAvailable !== undefined ? item.isAvailable : true,
      costPrice: item.costPrice || Math.round(item.price * 0.38),
      prepTimeMinutes: item.prepTimeMinutes || (item.category.includes('Special') ? 25 : item.category.includes('Beverage') ? 5 : 18),
      kitchenStation: item.kitchenStation || (item.category.includes('Seafood') ? 'Fish Station' : item.category.includes('Beverage') ? 'Bar & Cellar' : item.category.includes('Coffee') ? 'Coffee Counter' : 'Hot Kitchen'),
      outlets: item.outlets || ['BIH Lake Terrace Bar', 'Room Service & Minibar', 'Main Dining Hall']
    }))
  );

  const [hotelInfo, setHotelInfo] = useState<HotelInfo>(() => {
    const saved = localStorage.getItem('bih_hotel_info');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return {
      name: 'Burqito International Hotel (BIH)',
      shortName: 'BIH',
      city: 'Hawassa, Sidama',
      country: 'Ethiopia',
      address: 'Lake Hawassa Promenade, Old Bus Station Area, Hawassa, Sidama Region, Ethiopia',
      phone: '+251 91 682 3984',
      phoneAlt: '+251 90 966 9900',
      email: 'burqitointernational@gmail.com',
      website: 'https://www.burqitointernationalhotel.com',
      description: 'Premier 3-star luxury lakefront hotel offering modern comfort and authentic Ethiopian hospitality in Hawassa, Ethiopia.',
      logo: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=150&auto=format&fit=crop&q=80',
      photos: [
        'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1000&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=1000&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1590490360182-c33d57733427?w=1000&auto=format&fit=crop&q=80'
      ]
    };
  });

  const updateHotelInfo = useCallback((updates: Partial<HotelInfo>) => {
    setHotelInfo(prev => {
      const next = { ...prev, ...updates };
      localStorage.setItem('bih_hotel_info', JSON.stringify(next));
      return next;
    });
    addToast({
      type: 'success',
      title: 'Property Profile Updated',
      message: 'Hotel identity, logo and photo gallery saved persistently.'
    });
  }, []);

  const addToast = useCallback((toast: Omit<ToastMessage, 'id' | 'timestamp'>) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`;
    const newToast: ToastMessage = {
      ...toast,
      id,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    };
    setToasts(prev => [newToast, ...prev.slice(0, 4)]);

    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 6000);
  }, []);

  const toggleCurrency = useCallback(() => {
    setCurrency(prev => {
      const next = prev === 'ETB' ? 'USD' : 'ETB';
      addToast({
        type: 'info',
        title: `Currency Switched to ${next}`,
        message: next === 'ETB'
          ? 'Displaying rates in Ethiopian Birr (ETB). Rate: 1 USD ≈ 125 ETB'
          : 'Displaying rates in US Dollars (USD). Rate: 1 USD ≈ 125 ETB'
      });
      return next;
    });
  }, [addToast]);

  const formatMoney = useCallback((amountInETB: number, opts?: { showBoth?: boolean; compact?: boolean }): string => {
    if (isNaN(amountInETB) || amountInETB === undefined || amountInETB === null) {
      return currency === 'ETB' ? 'ETB 0' : '$0.00';
    }
    const usdVal = amountInETB / exchangeRate;

    if (currency === 'ETB') {
      const decimals = opts?.compact ? 0 : 2;
      const formattedETB = `ETB ${amountInETB.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: 2 })}`;
      if (opts?.showBoth) {
        return `${formattedETB} ($${usdVal.toFixed(2)})`;
      }
      return formattedETB;
    } else {
      const formattedUSD = `$${usdVal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      if (opts?.showBoth) {
        return `${formattedUSD} (ETB ${amountInETB.toLocaleString()})`;
      }
      return formattedUSD;
    }
  }, [currency]);


  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const addEmployee = useCallback((empData: Partial<Employee>) => {
    const newEmp: Employee = {
      id: `emp-${Date.now()}`,
      employeeId: `EMP-${String(employees.length + 1).padStart(3, '0')}`,
      name: empData.name || 'New Staff',
      avatar: empData.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      department: empData.department || 'Front Office',
      position: empData.position || 'Staff Associate',
      status: empData.status || 'Active',
      workType: empData.workType || 'Full Time',
      phone: empData.phone || '+251 91 000 0000',
      email: empData.email || 'staff@burqitohotel.com',
      joinDate: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      tenure: 'Just Joined',
      managerName: empData.managerName || 'Selamawit Haile',
      managerPosition: empData.managerPosition || 'Hotel Manager',
      managerAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
      shift: empData.shift || 'Morning (07:00 - 15:30)',
      todayAttendance: { status: 'Checked In', time: '08:00 AM' },
      activities: [
        { id: `act-${Date.now()}`, type: 'checkin', title: 'Onboarded & Profile Created', time: 'Today' }
      ]
    };
    setEmployees(prev => [newEmp, ...prev]);
    setSelectedEmployee(newEmp);
    addToast({
      type: 'success',
      title: 'Staff Member Registered',
      message: `${newEmp.name} registered as ${newEmp.position} in ${newEmp.department}.`
    });
  }, [employees.length, addToast]);

  const updateEmployeeStatus = useCallback((id: string, status: StaffStatus) => {
    setEmployees(prev => prev.map(e => e.id === id ? { ...e, status } : e));
    setSelectedEmployee(prev => prev && prev.id === id ? { ...prev, status } : prev);
    addToast({
      type: 'info',
      title: 'Status Updated',
      message: `Employee status changed to ${status}.`
    });
  }, [addToast]);

  const deleteEmployee = useCallback((id: string) => {
    let removedEmpName = 'Staff member';
    let nextSelected: Employee | null = null;

    setEmployees(prev => {
      const target = prev.find(e => e.id === id);
      if (target) {
        removedEmpName = `${target.name} (${target.employeeId})`;
      }
      const remaining = prev.filter(e => e.id !== id);
      nextSelected = remaining.length > 0 ? remaining[0] : null;
      return remaining;
    });

    setSelectedEmployee(prev => {
      if (prev && prev.id === id) {
        return nextSelected;
      }
      return prev;
    });

    addToast({
      type: 'info',
      title: 'Staff Member Deleted',
      message: `${removedEmpName} has been removed from the staff directory.`
    });
  }, [addToast]);

  const deleteEmployees = useCallback((ids: string[]) => {
    if (!ids || ids.length === 0) return;
    let nextSelected: Employee | null = null;

    setEmployees(prev => {
      const remaining = prev.filter(e => !ids.includes(e.id));
      nextSelected = remaining.length > 0 ? remaining[0] : null;
      return remaining;
    });

    setSelectedEmployee(prev => {
      if (prev && ids.includes(prev.id)) {
        return nextSelected;
      }
      return prev;
    });

    addToast({
      type: 'info',
      title: 'Staff Records Deleted',
      message: `${ids.length} staff member(s) deleted from the staff directory.`
    });
  }, [addToast]);

  // Custom Floor & Dynamic Room Plan Actions
  const addFloor = useCallback((config: {
    floorNumber: number;
    name: string;
    wing?: string;
    roomCount: number;
    startRoomNumber?: number;
    defaultCategory?: RoomCategory;
    defaultRate?: number;
  }) => {
    if (floors.some(f => f.floorNumber === config.floorNumber)) {
      addToast({ type: 'error', title: 'Floor Exists', message: `Floor ${config.floorNumber} already exists in property layout.` });
      return;
    }

    const newFloor: FloorConfig = {
      floorNumber: config.floorNumber,
      name: config.name || `Floor ${config.floorNumber}`,
      wing: config.wing || 'Lake Wing'
    };
    setFloors(prev => [...prev, newFloor].sort((a, b) => a.floorNumber - b.floorNumber));

    // Generate custom roomCount rooms
    const startNum = config.startRoomNumber || config.floorNumber * 100 + 1;
    const cat = config.defaultCategory || (config.floorNumber >= 5 ? 'SUITE' : config.floorNumber >= 3 ? 'DELUXE' : 'STANDARD');
    const rate = config.defaultRate || (cat === 'SUITE' ? 1200 : cat === 'DELUXE' ? 850 : 650);

    const generatedRooms: Room[] = [];
    for (let i = 0; i < config.roomCount; i++) {
      const roomNum = String(startNum + i);
      const rid = `rm-${roomNum}`;
      const newRoom: Room = {
        id: rid,
        roomNumber: roomNum,
        floor: config.floorNumber,
        category: cat,
        pricePerNight: rate,
        status: i % 4 === 0 ? 'OCCUPIED' : i % 5 === 0 ? 'DIRTY' : 'AVAILABLE',
        maxOccupancy: cat === 'SUITE' ? 4 : 2,
        bedConfig: cat === 'SUITE' ? '1 King Bed + Living Area' : '1 King Bed',
        amenities: ['High-speed Wi-Fi', 'Smart TV 55"', 'Rain Shower', 'Mini Bar'],
        wing: (config.wing as any) || 'Lake Wing',
        cleaningStatus: 'CLEAN'
      };
      db.rooms.set(rid, newRoom);
      generatedRooms.push(newRoom);
    }

    setRooms(prev => [...prev, ...generatedRooms]);
    addToast({
      type: 'success',
      title: 'Floor Added',
      message: `${newFloor.name} configured with ${config.roomCount} custom rooms.`
    });
  }, [floors, addToast]);

  const updateFloor = useCallback((floorNumber: number, updates: Partial<FloorConfig>) => {
    setFloors(prev => {
      const next = prev.map(f => f.floorNumber === floorNumber ? { ...f, ...updates } : f);
      localStorage.setItem('bih_floors', JSON.stringify(next));
      return next;
    });
    if (updates.name || updates.wing) {
      setRooms(prev => {
        const nextRooms = prev.map(r => r.floor === floorNumber ? {
          ...r,
          wing: (updates.wing as any) || r.wing
        } : r);
        localStorage.setItem('bih_rooms', JSON.stringify(nextRooms));
        return nextRooms;
      });
    }
    addToast({ type: 'success', title: 'Floor Updated', message: `Configuration saved for Floor ${floorNumber}.` });
  }, [addToast]);

  const deleteFloor = useCallback((floorNumber: number) => {
    setFloors(prev => prev.filter(f => f.floorNumber !== floorNumber));
    const roomsToDelete = rooms.filter(r => r.floor === floorNumber);
    roomsToDelete.forEach(r => db.rooms.delete(r.id));
    setRooms(prev => prev.filter(r => r.floor !== floorNumber));
    setSelectedRoom(prev => (prev && prev.floor === floorNumber ? null : prev));
    addToast({
      type: 'info',
      title: 'Floor Removed',
      message: `Floor ${floorNumber} and all its ${roomsToDelete.length} room(s) removed.`
    });
  }, [rooms, addToast]);

  const setFloorRoomCount = useCallback((floorNumber: number, newCount: number, defaultCategory?: RoomCategory, defaultRate?: number) => {
    const safeCount = Math.max(0, newCount);
    const currentRoomsOnFloor = rooms.filter(r => r.floor === floorNumber);
    const diff = safeCount - currentRoomsOnFloor.length;

    if (diff === 0) return;

    if (safeCount === 0) {
      currentRoomsOnFloor.forEach(r => db.rooms.delete(r.id));
      setRooms(prev => prev.filter(r => r.floor !== floorNumber));
      setSelectedRoom(prev => (prev && prev.floor === floorNumber ? null : prev));
      addToast({
        type: 'info',
        title: 'Floor Set to 0 Rooms',
        message: `Floor ${floorNumber} rooms cleared (0 rooms).`
      });
      return;
    }

    if (diff > 0) {
      const existingHighest = currentRoomsOnFloor.reduce((max, r) => {
        const parsed = parseInt(r.roomNumber, 10);
        return !isNaN(parsed) && parsed > max ? parsed : max;
      }, floorNumber * 100);

      const addedRooms: Room[] = [];
      const cat = defaultCategory || (floorNumber >= 5 ? 'SUITE' : floorNumber >= 3 ? 'DELUXE' : 'STANDARD');
      const rate = defaultRate || (cat === 'SUITE' ? 1200 : cat === 'DELUXE' ? 850 : 480);

      for (let i = 1; i <= diff; i++) {
        const roomNum = String(existingHighest + i);
        const rid = `rm-${roomNum}`;
        const room: Room = {
          id: rid,
          roomNumber: roomNum,
          floor: floorNumber,
          category: cat,
          pricePerNight: rate,
          status: 'AVAILABLE',
          maxOccupancy: cat === 'SUITE' ? 4 : 2,
          bedConfig: cat === 'SUITE' ? '1 King Bed + Living Area' : '1 King Bed',
          amenities: ['High-speed Wi-Fi', 'Smart TV 55"', 'Rain Shower'],
          wing: floorNumber % 2 === 0 ? 'Central Tower' : 'Lake Wing',
          cleaningStatus: 'CLEAN'
        };
        db.rooms.set(rid, room);
        addedRooms.push(room);
      }
      setRooms(prev => [...prev, ...addedRooms]);
      addToast({
        type: 'success',
        title: 'Rooms Added',
        message: `Added ${diff} new room(s) to Floor ${floorNumber}. Total: ${safeCount} rooms.`
      });
    } else {
      const toRemoveCount = Math.abs(diff);
      const roomsToRemove = [...currentRoomsOnFloor].slice(-toRemoveCount);
      const removeIds = roomsToRemove.map(r => r.id);
      removeIds.forEach(id => db.rooms.delete(id));
      setRooms(prev => prev.filter(r => !removeIds.includes(r.id)));
      setSelectedRoom(prev => (prev && removeIds.includes(prev.id) ? null : prev));
      addToast({
        type: 'info',
        title: 'Room Count Adjusted',
        message: `Floor ${floorNumber} adjusted to ${safeCount} room(s).`
      });
    }
  }, [rooms, addToast]);

  // Room Management Actions
  const addRoom = useCallback((roomData: Omit<Room, 'id'>) => {
    const id = `rm-${roomData.roomNumber}`;
    const newRoom: Room = {
      ...roomData,
      id
    };
    db.rooms.set(id, newRoom);
    setRooms(prev => [newRoom, ...prev]);
    setSelectedRoom(newRoom);
    addToast({
      type: 'success',
      title: 'Room Added',
      message: `Room ${newRoom.roomNumber} (${newRoom.category}) added to hotel inventory.`
    });
  }, [addToast]);

  const updateRoom = useCallback((id: string, updates: Partial<Room>) => {
    setRooms(prev => prev.map(r => {
      if (r.id === id || r.roomNumber === id) {
        const updated = { ...r, ...updates };
        db.rooms.set(updated.id, updated);
        return updated;
      }
      return r;
    }));
    setSelectedRoom(prev => (prev && (prev.id === id || prev.roomNumber === id)) ? { ...prev, ...updates } : prev);
    addToast({
      type: 'success',
      title: 'Room Updated',
      message: `Room configuration saved successfully.`
    });
  }, [addToast]);

  const deleteRoom = useCallback((id: string) => {
    const target = rooms.find(r => r.id === id || r.roomNumber === id);
    if (!target) return;
    if (target.status === 'OCCUPIED') {
      addToast({
        type: 'error',
        title: 'Action Restricted',
        message: `Cannot delete Room ${target.roomNumber} while a guest is actively checked in.`
      });
      return;
    }
    db.rooms.delete(target.id);
    setRooms(prev => prev.filter(r => r.id !== target.id));
    if (selectedRoom?.id === target.id) {
      setSelectedRoom(null);
    }
    addToast({
      type: 'info',
      title: 'Room Removed',
      message: `Room ${target.roomNumber} removed from active inventory.`
    });
  }, [rooms, selectedRoom, addToast]);

  const toggleRoomStatus = useCallback((id: string, status: RoomStatus) => {
    setRooms(prev => prev.map(r => {
      if (r.id === id || r.roomNumber === id) {
        const updated = { ...r, status };
        db.rooms.set(updated.id, updated);
        return updated;
      }
      return r;
    }));
    setSelectedRoom(prev => (prev && (prev.id === id || prev.roomNumber === id)) ? { ...prev, status } : prev);
    addToast({
      type: 'info',
      title: 'Status Updated',
      message: `Room status updated to ${status}.`
    });
  }, [addToast]);

  const bulkUpdateRooms = useCallback((roomIds: string[], updates: Partial<Room>) => {
    setRooms(prev => prev.map(r => {
      if (roomIds.includes(r.id) || roomIds.includes(r.roomNumber)) {
        const updated = { ...r, ...updates };
        db.rooms.set(updated.id, updated);
        return updated;
      }
      return r;
    }));
    addToast({
      type: 'success',
      title: 'Bulk Update Applied',
      message: `${roomIds.length} rooms updated.`
    });
  }, [addToast]);

  const uploadRoomPhotos = useCallback((roomId: string, newPhotoUrls: string[]) => {
    setRooms(prev => prev.map(r => {
      if (r.id === roomId || r.roomNumber === roomId) {
        const existingImages = r.images || (r.coverImage ? [r.coverImage] : []);
        const merged = [...existingImages, ...newPhotoUrls];
        const updated = {
          ...r,
          images: merged,
          coverImage: r.coverImage || newPhotoUrls[0] || existingImages[0]
        };
        db.rooms.set(updated.id, updated);
        return updated;
      }
      return r;
    }));
    setSelectedRoom(prev => {
      if (prev && (prev.id === roomId || prev.roomNumber === roomId)) {
        const existingImages = prev.images || (prev.coverImage ? [prev.coverImage] : []);
        const merged = [...existingImages, ...newPhotoUrls];
        return {
          ...prev,
          images: merged,
          coverImage: prev.coverImage || newPhotoUrls[0] || existingImages[0]
        };
      }
      return prev;
    });
    addToast({
      type: 'success',
      title: 'Photos Uploaded',
      message: `${newPhotoUrls.length} image(s) added to Room ${roomId.replace('rm-', '')}.`
    });
  }, [addToast]);

  const deleteRoomPhoto = useCallback((roomId: string, photoUrl: string) => {
    setRooms(prev => prev.map(r => {
      if (r.id === roomId || r.roomNumber === roomId) {
        const remaining = (r.images || []).filter(img => img !== photoUrl);
        const updated = {
          ...r,
          images: remaining,
          coverImage: r.coverImage === photoUrl ? (remaining[0] || '') : r.coverImage
        };
        db.rooms.set(updated.id, updated);
        return updated;
      }
      return r;
    }));
    setSelectedRoom(prev => {
      if (prev && (prev.id === roomId || prev.roomNumber === roomId)) {
        const remaining = (prev.images || []).filter(img => img !== photoUrl);
        return {
          ...prev,
          images: remaining,
          coverImage: prev.coverImage === photoUrl ? (remaining[0] || '') : prev.coverImage
        };
      }
      return prev;
    });
    addToast({
      type: 'info',
      title: 'Photo Removed',
      message: `Image deleted from room gallery.`
    });
  }, [addToast]);

  const setRoomCoverPhoto = useCallback((roomId: string, photoUrl: string) => {
    setRooms(prev => prev.map(r => {
      if (r.id === roomId || r.roomNumber === roomId) {
        const updated = { ...r, coverImage: photoUrl };
        db.rooms.set(updated.id, updated);
        return updated;
      }
      return r;
    }));
    setSelectedRoom(prev => (prev && (prev.id === roomId || prev.roomNumber === roomId)) ? { ...prev, coverImage: photoUrl } : prev);
    addToast({
      type: 'success',
      title: 'Cover Photo Updated',
      message: `Main thumbnail set for room.`
    });
  }, [addToast]);

  const clearAllOccupiedAndResetFrontDesk = useCallback(async () => {
    try {
      try {
        await apiService.resetAllRoomsToAvailable();
      } catch {
        db.clearAllOccupiedAndMakeAllAvailable();
      }

      // Reset all rooms in React state to AVAILABLE and CLEAN
      setRooms(prev => prev.map(r => ({
        ...r,
        status: 'AVAILABLE' as RoomStatus,
        cleaningStatus: 'CLEAN',
        currentBookingId: null,
        guestName: undefined,
        checkInDate: undefined,
        checkOutDate: undefined,
        activeMaintenanceTicketId: null
      })));

      // Reset front desk bookings, housekeeping tasks, maintenance tickets
      setBookings([]);
      setHousekeepingTasks([]);
      setMaintenanceTickets([]);

      // Reset selected room
      setSelectedRoom(prev => prev ? {
        ...prev,
        status: 'AVAILABLE' as RoomStatus,
        cleaningStatus: 'CLEAN',
        currentBookingId: null,
        guestName: undefined,
        checkInDate: undefined,
        checkOutDate: undefined
      } : null);

      addToast({
        type: 'success',
        title: 'Front Desk & Rooms Reset',
        message: 'Cleared all mockup occupied rooms. All rooms are now Available and Clean.'
      });
    } catch (err: any) {
      console.error(err);
      addToast({
        type: 'error',
        title: 'Reset Error',
        message: err.message || 'Could not reset room data.'
      });
    }
  }, [addToast]);

  // Menu Management Actions
  const addMenuItem = useCallback((itemData: Omit<PosMenuItem, 'id'>) => {
    const id = `pos-custom-${Date.now()}`;
    const newItem: PosMenuItem = {
      ...itemData,
      id,
      isAvailable: itemData.isAvailable !== undefined ? itemData.isAvailable : true,
      price: Number(itemData.price) || 0
    };
    setMenuItems(prev => [newItem, ...prev]);
    addToast({
      type: 'success',
      title: 'Menu Item Added',
      message: `"${newItem.name}" added to ${newItem.category}.`
    });
  }, [addToast]);

  const updateMenuItem = useCallback((id: string, updates: Partial<PosMenuItem>) => {
    setMenuItems(prev => prev.map(item => {
      if (item.id === id) {
        return {
          ...item,
          ...updates,
          price: updates.price !== undefined ? Number(updates.price) : item.price
        };
      }
      return item;
    }));
    addToast({
      type: 'success',
      title: 'Menu Item Updated',
      message: `Changes saved successfully.`
    });
  }, [addToast]);

  const deleteMenuItem = useCallback((id: string) => {
    const target = menuItems.find(i => i.id === id);
    setMenuItems(prev => prev.filter(i => i.id !== id));
    addToast({
      type: 'info',
      title: 'Item Deleted',
      message: target ? `"${target.name}" removed from F&B menu.` : 'Menu item removed.'
    });
  }, [menuItems, addToast]);

  const toggleMenuItemAvailability = useCallback((id: string) => {
    setMenuItems(prev => prev.map(item => {
      if (item.id === id) {
        const nextState = !item.isAvailable;
        addToast({
          type: nextState ? 'success' : 'warning',
          title: nextState ? 'Item In Stock' : 'Item 86\'d (Sold Out)',
          message: nextState
            ? `"${item.name}" is now live and orderable on POS.`
            : `"${item.name}" marked Sold Out. POS orders restricted.`
        });
        return { ...item, isAvailable: nextState };
      }
      return item;
    }));
  }, [addToast]);

  const bulkUpdateMenuPrices = useCallback((category: string, amountOrPercent: number, isPercent: boolean) => {
    setMenuItems(prev => prev.map(item => {
      if (category === 'ALL' || item.category === category) {
        let newPrice = item.price;
        if (isPercent) {
          newPrice = Math.round(item.price * (1 + amountOrPercent / 100));
        } else {
          newPrice = Math.max(0, item.price + amountOrPercent);
        }
        return { ...item, price: newPrice };
      }
      return item;
    }));
    addToast({
      type: 'success',
      title: 'Prices Updated',
      message: `Adjusted pricing for ${category === 'ALL' ? 'all items' : category}.`
    });
  }, [addToast]);

  const saveAllChanges = useCallback(() => {
    try {
      localStorage.setItem('bih_rooms', JSON.stringify(rooms));
      localStorage.setItem('bih_bookings', JSON.stringify(bookings));
      localStorage.setItem('bih_inventory', JSON.stringify(inventoryItems));
      localStorage.setItem('bih_housekeeping', JSON.stringify(housekeepingTasks));
      localStorage.setItem('bih_maintenance', JSON.stringify(maintenanceTickets));
      localStorage.setItem('bih_employees', JSON.stringify(employees));
      localStorage.setItem('bih_floors', JSON.stringify(floors));
      localStorage.setItem('bih_hotel_info', JSON.stringify(hotelInfo));
      localStorage.setItem('bih_currency', currency);
      localStorage.setItem('bih_menu', JSON.stringify(menuItems));

      addToast({
        type: 'success',
        title: 'Database Saved Successfully',
        message: 'All changes across Front Desk, Reservations, Room Management, IMS, Staff, and Settings are safely saved to database.'
      });
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Save Failed',
        message: 'Could not save state to browser database storage.'
      });
    }
  }, [rooms, bookings, inventoryItems, housekeepingTasks, maintenanceTickets, employees, floors, hotelInfo, currency, menuItems, addToast]);

  // Sync / Refresh function with fallback to database directly
  const refreshAllData = useCallback(async () => {
    try {
      // First try fetching from Express backend
      const [
        fetchedRooms,
        fetchedBookings,
        fetchedItems,
        fetchedLocations,
        fetchedTransfers,
        fetchedPOs,
        fetchedTasks,
        fetchedTickets,
        fetchedPOS,
        fetchedLogs
      ] = await Promise.all([
        apiService.getRooms().catch(() => Array.from(db.rooms.values())),
        apiService.getBookings().catch(() => Array.from(db.bookings.values()).map(b => ({
          ...b,
          guest: db.guests.get(b.guestId),
          room: db.rooms.get(b.roomId),
          folio: db.folios.get(b.folioId)
        }))),
        apiService.getInventoryItems().catch(() => Array.from(db.inventoryItems.values())),
        apiService.getWarehouseLocations().catch(() => Array.from(db.warehouseLocations.values())),
        apiService.getStockTransfers().catch(() => db.stockTransfers),
        apiService.getPurchaseOrders().catch(() => Array.from(db.purchaseOrders.values())),
        apiService.getHousekeepingTasks().catch(() => Array.from(db.housekeepingTasks.values())),
        apiService.getMaintenanceTickets().catch(() => Array.from(db.maintenanceTickets.values())),
        apiService.getPosProducts().catch(() => db.posProducts),
        apiService.getConsumptionLogs().catch(() => db.inventoryConsumptionLogs)
      ]);

      // Ensure all rooms are completely sanitized to AVAILABLE and CLEAN with no mock occupancy
      const cleanRooms = fetchedRooms.map(r => ({
        ...r,
        status: (fetchedBookings.some(b => b.roomId === r.id && b.status === 'CHECKED_IN') ? r.status : 'AVAILABLE') as RoomStatus,
        cleaningStatus: 'CLEAN' as const,
        currentBookingId: fetchedBookings.some(b => b.roomId === r.id && b.status === 'CHECKED_IN') ? r.currentBookingId : null,
        guestName: fetchedBookings.some(b => b.roomId === r.id && b.status === 'CHECKED_IN') ? r.guestName : undefined,
        checkInDate: fetchedBookings.some(b => b.roomId === r.id && b.status === 'CHECKED_IN') ? r.checkInDate : undefined,
        checkOutDate: fetchedBookings.some(b => b.roomId === r.id && b.status === 'CHECKED_IN') ? r.checkOutDate : undefined
      }));

      setRooms(cleanRooms);
      setSelectedRoom(prev => (prev ? cleanRooms.find(r => r.id === prev.id) || cleanRooms[0] : cleanRooms[0]) || null);
      setBookings(fetchedBookings);
      setInventoryItems(fetchedItems);
      setWarehouseLocations(fetchedLocations);
      setStockTransfers(fetchedTransfers);
      setPurchaseOrders(fetchedPOs);
      setHousekeepingTasks(fetchedTasks);
      setMaintenanceTickets(fetchedTickets);
      setPosProducts(fetchedPOS);
      setConsumptionLogs(fetchedLogs);
    } catch (err: any) {
      console.warn('Network sync notice: Using synchronized in-memory database store.', err);
      const cleanDbRooms = Array.from(db.rooms.values()).map(r => ({
        ...r,
        status: (db.bookings.has(r.currentBookingId || '') ? r.status : 'AVAILABLE') as RoomStatus,
        cleaningStatus: 'CLEAN' as const,
        currentBookingId: db.bookings.has(r.currentBookingId || '') ? r.currentBookingId : null,
        guestName: db.bookings.has(r.currentBookingId || '') ? r.guestName : undefined
      }));
      setRooms(cleanDbRooms);
      setSelectedRoom(prev => (prev ? cleanDbRooms.find(r => r.id === prev.id) || cleanDbRooms[0] : cleanDbRooms[0]) || null);
      setBookings(Array.from(db.bookings.values()));
      setInventoryItems(Array.from(db.inventoryItems.values()));
      setWarehouseLocations(Array.from(db.warehouseLocations.values()));
      setStockTransfers(db.stockTransfers);
      setPurchaseOrders(Array.from(db.purchaseOrders.values()));
      setHousekeepingTasks(Array.from(db.housekeepingTasks.values()));
      setMaintenanceTickets(Array.from(db.maintenanceTickets.values()));
      setPosProducts(db.posProducts);
      setConsumptionLogs(db.inventoryConsumptionLogs);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshAllData();
  }, [refreshAllData]);

  const resetAllData = useCallback(async () => {
    try {
      await apiService.resetAll().catch(() => {});
      db.resetAllData();
      localStorage.clear();
      setRooms([]);
      setBookings([]);
      setInventoryItems([]);
      setWarehouseLocations([]);
      setStockTransfers([]);
      setPurchaseOrders([]);
      setHousekeepingTasks([]);
      setMaintenanceTickets([]);
      setPosProducts([]);
      setConsumptionLogs([]);
      setEmployees([]);
      addToast({
        type: 'success',
        title: 'System Reset Successful',
        message: 'All frontend and backend datasets have been completely cleared and reset.'
      });
    } catch (err: any) {
      addToast({
        type: 'error',
        title: 'Reset Failed',
        message: err.message || 'Could not reset datasets.'
      });
    }
  }, [addToast]);

  // Derived KPIs
  const totalRooms = rooms.length;
  const occupiedRooms = rooms.filter(r => r.status === 'OCCUPIED').length;
  const dirtyRooms = rooms.filter(r => r.status === 'DIRTY' || r.status === 'CHECKED_OUT').length;
  const maintenanceRooms = rooms.filter(r => r.status === 'MAINTENANCE').length;
  const availableRooms = rooms.filter(r => r.status === 'AVAILABLE').length;
  const occupancyRate = totalRooms > 0 ? Math.round((occupiedRooms / totalRooms) * 100) : 0;
  
  // Calculate ADR & RevPAR
  const occupiedRoomEntities = rooms.filter(r => r.status === 'OCCUPIED');
  const totalOccupiedRate = occupiedRoomEntities.reduce((sum, r) => sum + r.pricePerNight, 0);
  const adr = occupiedRooms > 0 ? Math.round(totalOccupiedRate / occupiedRooms) : 0;
  const revPar = totalRooms > 0 ? Math.round(totalOccupiedRate / totalRooms) : 0;

  const lowStockCount = inventoryItems.filter(i => i.totalStock <= i.minSafetyStock).length;
  const openMaintenanceCount = maintenanceTickets.filter(t => t.status !== 'RESOLVED').length;
  const pendingHousekeepingCount = housekeepingTasks.filter(t => t.status === 'PENDING' || t.status === 'IN_PROGRESS').length;
  const totalInventoryValue = Number(inventoryItems.reduce((sum, i) => sum + (i.totalStock * i.unitCost), 0).toFixed(2));

  // Modal Triggers
  const openBookingWizardForRoom = (roomId?: string) => {
    setBookingWizardInitialRoomId(roomId || null);
    setIsBookingWizardOpen(true);
  };

  const openCheckOutModal = (booking: Booking) => {
    setCheckOutBooking(booking);
    setIsCheckOutModalOpen(true);
  };

  const openStockTransferModal = (item?: InventoryItem) => {
    setStockTransferItem(item || null);
    setIsStockTransferOpen(true);
  };

  const openMaintenanceModal = (room?: Room) => {
    setMaintenanceRoom(room || null);
    setIsMaintenanceModalOpen(true);
  };

  const openFolioModal = (booking: Booking) => {
    setFolioModalBooking(booking);
    setIsFolioModalOpen(true);
  };

  // -------------------------------------------------------------
  // ACTIONS WRAPPERS
  // -------------------------------------------------------------

  const handleCreateBooking = async (payload: any): Promise<boolean> => {
    try {
      try {
        await apiService.createBooking(payload);
      } catch {
        // Direct DB fallback
        const room = db.rooms.get(payload.roomId);
        if (!room) throw new Error('Room not found');
        const guest = {
          id: `g-${Date.now()}`,
          firstName: payload.guestData.firstName,
          lastName: payload.guestData.lastName,
          email: payload.guestData.email,
          phone: payload.guestData.phone,
          idType: payload.guestData.idType || 'PASSPORT',
          idNumber: payload.guestData.idNumber,
          nationality: payload.guestData.nationality || 'Unknown',
          vipStatus: !!payload.guestData.vipStatus,
          createdAt: new Date().toISOString()
        };
        db.guests.set(guest.id, guest);

        const nights = 2;
        const total = room.pricePerNight * nights;
        const bookingId = `bk-${Date.now()}`;
        const folioId = `fol-${Date.now()}`;

        const folio: GuestFolio = {
          id: folioId,
          bookingId,
          status: 'OPEN',
          items: [
            { id: `fi-${Date.now()}-1`, folioId, category: 'ROOM_CHARGE', description: `Room ${room.roomNumber} - ${nights} Nights`, amount: total, date: payload.checkInDate, postedBy: 'FRONT_DESK' },
            { id: `fi-${Date.now()}-2`, folioId, category: 'TAX', description: 'Occupancy Tax (12%)', amount: total * 0.12, date: payload.checkInDate, postedBy: 'SYSTEM' }
          ],
          payments: [],
          subtotal: total,
          taxAmount: total * 0.12,
          totalAmount: total * 1.12,
          paidAmount: 0,
          balanceDue: total * 1.12
        };
        db.folios.set(folioId, folio);

        const booking: Booking = {
          id: bookingId,
          bookingReference: `GH-2026-${Math.floor(1000 + Math.random() * 9000)}`,
          roomId: room.id,
          guestId: guest.id,
          checkInDate: payload.checkInDate,
          checkOutDate: payload.checkOutDate,
          numberOfGuests: payload.numberOfGuests || 1,
          ratePerNight: room.pricePerNight,
          totalNights: nights,
          status: payload.autoCheckIn ? 'CHECKED_IN' : 'CONFIRMED',
          folioId,
          createdAt: new Date().toISOString()
        };
        db.bookings.set(bookingId, booking);

        if (payload.autoCheckIn) {
          db.checkInGuest(bookingId);
        }
      }

      addToast({
        type: 'success',
        title: 'Booking Confirmed',
        message: payload.autoCheckIn
          ? `Guest registered & checked in! Inventory supplies auto-deducted.`
          : `Reservation confirmed successfully.`
      });
      await refreshAllData();
      return true;
    } catch (err: any) {
      addToast({ type: 'error', title: 'Reservation Failed', message: err.message });
      return false;
    }
  };

  const handleCheckInGuest = async (bookingId: string): Promise<boolean> => {
    try {
      try {
        await apiService.checkInGuest(bookingId);
      } catch {
        db.checkInGuest(bookingId);
      }
      addToast({
        type: 'success',
        title: 'Guest Checked In',
        message: 'Room marked Occupied. Luxury amenities kit automatically deducted from floor inventory!'
      });
      await refreshAllData();
      return true;
    } catch (err: any) {
      addToast({ type: 'error', title: 'Check-In Error', message: err.message });
      return false;
    }
  };

  const handleCheckOutGuest = async (bookingId: string, paymentMethod?: string): Promise<boolean> => {
    try {
      try {
        await apiService.checkOutGuest(bookingId, paymentMethod);
      } catch {
        db.checkOutGuest(bookingId, (paymentMethod as any) || 'CREDIT_CARD');
      }
      addToast({
        type: 'success',
        title: 'Check-Out Finalized',
        message: 'Folio settled. Room transitioned to DIRTY and routed to Housekeeping dispatch.'
      });
      await refreshAllData();
      return true;
    } catch (err: any) {
      addToast({ type: 'error', title: 'Check-Out Error', message: err.message });
      return false;
    }
  };

  const handleTransferStock = async (payload: {
    itemId: string;
    fromLocation: WarehouseLocationId;
    toLocation: WarehouseLocationId;
    quantity: number;
    reason: string;
    staffName: string;
  }): Promise<boolean> => {
    try {
      try {
        await apiService.transferStock(payload);
      } catch {
        db.transferInventory(payload.itemId, payload.fromLocation, payload.toLocation, payload.quantity, payload.reason, payload.staffName);
      }
      addToast({
        type: 'success',
        title: 'Stock Transferred',
        message: `Successfully moved ${payload.quantity} units to ${payload.toLocation}.`
      });
      await refreshAllData();
      return true;
    } catch (err: any) {
      addToast({ type: 'error', title: 'Transfer Failed', message: err.message });
      return false;
    }
  };

  const handlePostPosCharge = async (payload: {
    roomNumber: string;
    category: 'FOOD_BEVERAGE' | 'MINIBAR' | 'SPA';
    description: string;
    amount: number;
    serverName: string;
  }): Promise<boolean> => {
    try {
      try {
        await apiService.postPosCharge(payload);
      } catch {
        db.postPosCharge(payload.roomNumber, payload.category, payload.description, payload.amount, payload.serverName);
      }
      addToast({
        type: 'success',
        title: 'Charge Posted to Room',
        message: `$${payload.amount.toFixed(2)} posted directly to Room ${payload.roomNumber} folio.`
      });
      await refreshAllData();
      return true;
    } catch (err: any) {
      addToast({ type: 'error', title: 'Charge Posting Failed', message: err.message });
      return false;
    }
  };

  const handleUpdateHousekeepingTask = async (id: string, status: string, notes?: string): Promise<boolean> => {
    try {
      try {
        await apiService.updateHousekeepingTask(id, status, notes);
      } catch {
        const task = db.housekeepingTasks.get(id);
        if (task) {
          task.status = status as any;
          if (notes) task.notes = notes;
          if (status === 'COMPLETED' || status === 'INSPECTED') {
            const rm = db.rooms.get(task.roomId);
            if (rm && rm.status === 'DIRTY') rm.status = 'AVAILABLE';
          }
        }
      }
      addToast({
        type: 'success',
        title: 'Housekeeping Updated',
        message: `Task marked as ${status}. Room inventory status updated.`
      });
      await refreshAllData();
      return true;
    } catch (err: any) {
      addToast({ type: 'error', title: 'Update Failed', message: err.message });
      return false;
    }
  };

  const handleCreateMaintenanceTicket = async (payload: any): Promise<boolean> => {
    try {
      try {
        await apiService.createMaintenanceTicket(payload);
      } catch {
        const room = db.rooms.get(payload.roomId);
        if (!room) throw new Error('Room not found');
        const tid = `mt-${Date.now()}`;
        const newTicket: MaintenanceTicket = {
          id: tid,
          ticketNumber: `MT-2026-${Math.floor(100 + Math.random() * 900)}`,
          roomId: room.id,
          roomNumber: room.roomNumber,
          category: payload.category || 'HVAC',
          description: payload.description,
          priority: payload.priority || 'HIGH',
          status: 'OPEN',
          assignedTo: payload.assignedTo || 'Maintenance Tech',
          locksRoom: payload.locksRoom !== false,
          createdAt: new Date().toISOString()
        };
        db.maintenanceTickets.set(tid, newTicket);
        if (newTicket.locksRoom) {
          room.status = 'MAINTENANCE';
          room.activeMaintenanceTicketId = tid;
        }
      }
      addToast({
        type: 'warning',
        title: 'Maintenance Ticket Logged',
        message: payload.locksRoom !== false ? `Room locked into MAINTENANCE status.` : `Ticket created.`
      });
      await refreshAllData();
      return true;
    } catch (err: any) {
      addToast({ type: 'error', title: 'Ticket Creation Failed', message: err.message });
      return false;
    }
  };

  const handleResolveMaintenanceTicket = async (id: string): Promise<boolean> => {
    try {
      try {
        await apiService.resolveMaintenanceTicket(id);
      } catch {
        const ticket = db.maintenanceTickets.get(id);
        if (ticket) {
          ticket.status = 'RESOLVED';
          const room = db.rooms.get(ticket.roomId);
          if (room && room.status === 'MAINTENANCE') {
            room.status = 'AVAILABLE';
            room.activeMaintenanceTicketId = null;
          }
        }
      }
      addToast({
        type: 'success',
        title: 'Ticket Resolved',
        message: 'Maintenance cleared. Room restored to AVAILABLE in the PMS inventory grid.'
      });
      await refreshAllData();
      return true;
    } catch (err: any) {
      addToast({ type: 'error', title: 'Resolution Failed', message: err.message });
      return false;
    }
  };

  const handleCreatePurchaseOrder = async (payload: any): Promise<boolean> => {
    try {
      try {
        await apiService.createPurchaseOrder(payload);
      } catch {
        const poId = `po-${Date.now()}`;
        const newPO: PurchaseOrder = {
          id: poId,
          poNumber: `PO-2026-${Math.floor(100 + Math.random() * 900)}`,
          vendorId: `v-${Date.now()}`,
          vendorName: payload.vendorName,
          status: 'DRAFT',
          items: payload.items || [],
          totalAmount: payload.totalAmount || 0,
          targetWarehouse: payload.targetWarehouse || 'MAIN_WAREHOUSE',
          createdAt: new Date().toISOString(),
          expectedDeliveryDate: payload.expectedDeliveryDate || '2026-10-25'
        };
        db.purchaseOrders.set(poId, newPO);
      }
      addToast({
        type: 'success',
        title: 'Purchase Order Drafted',
        message: 'New PO registered. Ready to send to vendor.'
      });
      await refreshAllData();
      return true;
    } catch (err: any) {
      addToast({ type: 'error', title: 'PO Error', message: err.message });
      return false;
    }
  };

  const handleTransitionPOStatus = async (poId: string, status: string, receiveQtyMap?: Record<string, number>): Promise<boolean> => {
    try {
      try {
        await apiService.updatePurchaseOrderStatus(poId, status, receiveQtyMap);
      } catch {
        db.transitionPurchaseOrder(poId, status as any, receiveQtyMap);
      }
      addToast({
        type: 'success',
        title: 'PO Status Updated',
        message: status === 'FULFILLED' || status === 'PARTIALLY_RECEIVED'
          ? 'Stock automatically restocked into Main Central Warehouse!'
          : `PO status updated to ${status}.`
      });
      await refreshAllData();
      return true;
    } catch (err: any) {
      addToast({ type: 'error', title: 'PO Status Failed', message: err.message });
      return false;
    }
  };

  return (
    <HotelContext.Provider
      value={{
        rooms,
        bookings,
        inventoryItems,
        warehouseLocations,
        stockTransfers,
        purchaseOrders,
        housekeepingTasks,
        maintenanceTickets,
        posProducts,
        consumptionLogs,
        isLoading,
        toasts,
        hotelInfo,
        updateHotelInfo,
        saveAllChanges,
        currency,
        setCurrency,
        toggleCurrency,
        exchangeRate,
        formatMoney,
        metrics: {
          totalRooms,
          occupiedRooms,
          occupancyRate,
          dirtyRooms,
          maintenanceRooms,
          availableRooms,
          revPar,
          adr,
          lowStockCount,
          openMaintenanceCount,
          pendingHousekeepingCount,
          totalInventoryValue
        },
        kpis: {
          totalRooms,
          occupiedRooms,
          occupancyRate,
          dirtyRooms,
          maintenanceRooms,
          availableRooms,
          revPar,
          adr,
          lowStockCount,
          openMaintenanceCount,
          pendingHousekeepingCount,
          totalInventoryValue
        },
        activeTab,
        setActiveTab,
        selectedRoom,
        setSelectedRoom,
        selectedInventoryItem,
        setSelectedInventoryItem,
        employees,
        selectedEmployee,
        setSelectedEmployee,
        isAddStaffOpen,
        setIsAddStaffOpen,
        addEmployee,
        updateEmployeeStatus,
        deleteEmployee,
        deleteEmployees,
        isBookingWizardOpen,
        setIsBookingWizardOpen,
        bookingWizardInitialRoomId,
        openBookingWizardForRoom,
        isCheckOutModalOpen,
        setIsCheckOutModalOpen,
        checkOutBooking,
        openCheckOutModal,
        isStockTransferOpen,
        setIsStockTransferOpen,
        stockTransferItem,
        openStockTransferModal,
        isPurchaseOrderOpen,
        setIsPurchaseOrderOpen,
        isMaintenanceModalOpen,
        setIsMaintenanceModalOpen,
        maintenanceRoom,
        openMaintenanceModal,
        isFolioModalOpen,
        setIsFolioModalOpen,
        folioModalBooking,
        openFolioModal,
        refreshAllData,
        resetAllData,
        createBooking: handleCreateBooking,
        checkInGuest: handleCheckInGuest,
        checkOutGuest: handleCheckOutGuest,
        transferStock: handleTransferStock,
        postPosCharge: handlePostPosCharge,
        updateHousekeepingTask: handleUpdateHousekeepingTask,
        createMaintenanceTicket: handleCreateMaintenanceTicket,
        resolveMaintenanceTicket: handleResolveMaintenanceTicket,
        createPurchaseOrder: handleCreatePurchaseOrder,
        transitionPOStatus: handleTransitionPOStatus,
        // Custom Floor Plan Management
        floors,
        setFloors,
        addFloor,
        updateFloor,
        deleteFloor,
        setFloorRoomCount,
        // Room Management
        addRoom,
        updateRoom,
        deleteRoom,
        toggleRoomStatus,
        bulkUpdateRooms,
        uploadRoomPhotos,
        deleteRoomPhoto,
        setRoomCoverPhoto,
        clearAllOccupiedAndResetFrontDesk,
        // Menu Management
        menuItems,
        setMenuItems,
        addMenuItem,
        updateMenuItem,
        deleteMenuItem,
        toggleMenuItemAvailability,
        bulkUpdateMenuPrices,
        addToast,
        removeToast
      }}
    >
      {children}
    </HotelContext.Provider>
  );
};

export const useHotel = () => {
  const context = useContext(HotelContext);
  if (!context) {
    throw new Error('useHotel must be used within a HotelProvider');
  }
  return context;
};
