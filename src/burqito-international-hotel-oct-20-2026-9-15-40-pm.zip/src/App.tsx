/**
 * Aurelia Hospitality Cloud - Main Application Shell
 * Upgraded to match exact UI/UX, light theme, dark navy sidebar, and drawer layout.
 */

import React from 'react';
import { HotelProvider, useHotel } from './context/HotelContext.tsx';
import { Sidebar } from './components/Sidebar.tsx';
import { Header } from './components/Header.tsx';
import { ExecutiveDashboard } from './components/dashboard/ExecutiveDashboard.tsx';
import { MetricsBar } from './components/pms/MetricsBar.tsx';
import { RoomGrid } from './components/pms/RoomGrid.tsx';
import { RoomDetailDrawer } from './components/pms/RoomDetailDrawer.tsx';
import { BottomOperationalTables } from './components/pms/BottomOperationalTables.tsx';
import { BookingWizardModal } from './components/pms/BookingWizardModal.tsx';
import { CheckOutModal } from './components/pms/CheckOutModal.tsx';
import { ReservationsView } from './components/reservations/ReservationsView.tsx';
import { GuestsDirectoryView } from './components/guests/GuestsDirectoryView.tsx';
import { InventoryDashboard } from './components/ims/InventoryDashboard.tsx';
import { InventoryMetricsBar } from './components/ims/InventoryMetricsBar.tsx';
import { InventoryItemDetailDrawer } from './components/ims/InventoryItemDetailDrawer.tsx';
import { StockTransferModal } from './components/ims/StockTransferModal.tsx';
import { PurchaseOrderModal } from './components/ims/PurchaseOrderModal.tsx';
import { PurchasingView } from './components/purchasing/PurchasingView.tsx';
import { StaffManagement } from './components/staff/StaffManagement.tsx';
import { AddStaffModal } from './components/staff/AddStaffModal.tsx';
import { CashierPos } from './components/pos/CashierPos.tsx';
import { OutletsView } from './components/outlets/OutletsView.tsx';
import { FinanceView } from './components/finance/FinanceView.tsx';
import { ReportsView } from './components/reports/ReportsView.tsx';
import { SettingsView } from './components/settings/SettingsView.tsx';
import { RoomManagementView } from './components/rooms/RoomManagementView.tsx';
import { MenuManagementView } from './components/menu/MenuManagementView.tsx';
import { HousekeepingBoard } from './components/housekeeping/HousekeepingBoard.tsx';
import { MaintenanceModal } from './components/housekeeping/MaintenanceModal.tsx';
import { FolioInvoiceModal } from './components/billing/FolioInvoiceModal.tsx';
import { ArchitectureViewer } from './components/blueprint/ArchitectureViewerModal.tsx';
import { ToastContainer } from './components/ToastContainer.tsx';

const MainLayout: React.FC = () => {
  const {
    activeTab,
    selectedRoom,
    setSelectedRoom,
    selectedInventoryItem,
    setSelectedInventoryItem
  } = useHotel();

  return (
    <div className="flex h-screen overflow-hidden overflow-x-hidden bg-[#F8F1E8] text-[#1F2937] font-sans selection:bg-[#F28C28]/20 selection:text-[#5B0F0F]">
      {/* 1. Left Dark Navy Sidebar */}
      <Sidebar />

      {/* 2. Main Content Frame */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        {/* Top Header Navigation */}
        <Header />

        {/* Content View Router */}
        <div className="flex-1 flex flex-col lg:flex-row min-w-0 overflow-hidden">
          
          {/* Main Workspace Column */}
          <div className="flex-1 p-5 sm:p-6 space-y-6 overflow-y-auto min-w-0 h-full">
            {activeTab === 'DASHBOARD' && (
              <ExecutiveDashboard />
            )}

            {activeTab === 'PMS_GRID' && (
              <>
                {/* Section Title */}
                <div>
                  <h1 className="text-2xl font-bold tracking-tight text-slate-900">Front Desk</h1>
                  <p className="text-xs text-slate-500 mt-0.5">Live room status and hotel operations</p>
                </div>

                {/* 7 KPI Metric Cards */}
                <MetricsBar />

                {/* Sub-tabs, Floor selector & 6-column Room Grid */}
                <RoomGrid />

                {/* Bottom 3 Operational Panels: Arrivals, Departures, Housekeeping */}
                <BottomOperationalTables />
              </>
            )}

            {activeTab === 'ROOMS' && (
              <RoomManagementView />
            )}

            {activeTab === 'RESERVATIONS' && (
              <ReservationsView />
            )}

            {activeTab === 'GUESTS' && (
              <GuestsDirectoryView />
            )}

            {activeTab === 'HOUSEKEEPING' && (
              <div className="space-y-4">
                <div>
                  <h1 className="text-2xl font-bold tracking-tight text-slate-900">Housekeeping & Maintenance</h1>
                  <p className="text-xs text-slate-500 mt-0.5">Room turnaround queues and priority room lockout tickets</p>
                </div>
                <HousekeepingBoard />
              </div>
            )}

            {activeTab === 'INVENTORY' && (
              <>
                {/* Section Title */}
                <div>
                  <h1 className="text-2xl font-bold tracking-tight text-slate-900">Inventory & Supply Chain (IMS)</h1>
                  <p className="text-xs text-slate-500 mt-0.5">Real-time multi-location warehouse stock, automated reorders & procurement lifecycle</p>
                </div>

                {/* 7 KPI Metric Cards matching Aurelia PMS */}
                <InventoryMetricsBar />

                {/* Catalog, Multi-Warehouse Matrix, POs & Deductions */}
                <InventoryDashboard />
              </>
            )}

            {activeTab === 'PURCHASING' && (
              <PurchasingView />
            )}

            {activeTab === 'STAFF' && (
              <StaffManagement />
            )}

            {activeTab === 'FINANCE' && (
              <FinanceView />
            )}

            {activeTab === 'POS' && (
              <CashierPos />
            )}

            {activeTab === 'MENU' && (
              <MenuManagementView />
            )}

            {activeTab === 'OUTLETS' && (
              <OutletsView />
            )}

            {activeTab === 'REPORTS' && (
              <ReportsView />
            )}

            {activeTab === 'SETTINGS' && (
              <SettingsView />
            )}

            {activeTab === 'BLUEPRINT' && (
              <div className="space-y-4">
                <div>
                  <h1 className="text-2xl font-bold tracking-tight text-slate-900">Schema & System Architecture</h1>
                  <p className="text-xs text-slate-500 mt-0.5">PostgreSQL DDL, Prisma relational schema, and ER diagrams</p>
                </div>
                <ArchitectureViewer />
              </div>
            )}
          </div>

          {/* 3. Right-Hand Room Detail Drawer (Displayed on Front Desk view or Guests view) */}
          {(activeTab === 'PMS_GRID' || activeTab === 'GUESTS') && selectedRoom && (
            <RoomDetailDrawer
              room={selectedRoom}
              onClose={() => setSelectedRoom(null)}
            />
          )}

          {/* 4. Right-Hand Inventory Detail Drawer (Displayed on Inventory view) */}
          {activeTab === 'INVENTORY' && selectedInventoryItem && (
            <InventoryItemDetailDrawer
              item={selectedInventoryItem}
              onClose={() => setSelectedInventoryItem(null)}
            />
          )}

        </div>
      </div>

      {/* Global Modals */}
      <BookingWizardModal />
      <CheckOutModal />
      <StockTransferModal />
      <PurchaseOrderModal />
      <AddStaffModal />
      <MaintenanceModal />
      <FolioInvoiceModal />
      <ToastContainer />
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <HotelProvider>
      <MainLayout />
    </HotelProvider>
  );
};

export default App;
