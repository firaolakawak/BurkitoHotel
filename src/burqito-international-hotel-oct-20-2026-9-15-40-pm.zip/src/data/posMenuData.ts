export interface PosMenuItem {
  id: string;
  name: string;
  price: number; // Stored in ETB (Ethiopian Birr)
  description: string;
  category: string;
  image: string;
  tag?: "Chef's Special" | 'Vegetarian' | 'Spicy' | 'Gluten Free' | 'Ethiopian Special';
  isVegetarian?: boolean;
  isSpicy?: boolean;
  favorite?: boolean;
  linkedInventorySku?: string;
  defaultNote?: string;
  isAvailable?: boolean; // false = 86'd / Sold out
  costPrice?: number; // Cost of goods sold in ETB
  prepTimeMinutes?: number;
  kitchenStation?: 'Hot Kitchen' | 'Grill Station' | 'Fish Station' | 'Bar & Cellar' | 'Coffee Counter' | 'Pastry & Bakery' | 'Cold Larder';
  outlets?: string[];
}

export const POS_MENU_ITEMS: PosMenuItem[] = [
  // Ethiopian & Hawassa Lake Specialties (Burqito International Hotel)
  {
    id: 'pos-eth-1',
    name: 'Special Doro Wat with Injera',
    price: 650.00,
    description: 'Slow-simmered tender chicken leg in rich berbere sauce with hard-boiled egg, fresh cottage cheese (ayib), and teff injera.',
    category: 'Ethiopian Specialties',
    image: 'https://images.unsplash.com/photo-1541518763669-27fef04b14ea?w=400&auto=format&fit=crop&q=80',
    tag: "Chef's Special",
    isSpicy: true,
    favorite: true,
    linkedInventorySku: 'FB-001',
    defaultNote: 'Mild spice with Ayib'
  },
  {
    id: 'pos-eth-2',
    name: 'Lake Hawassa Fresh Tilapia (Asa Tibs)',
    price: 550.00,
    description: 'Freshly caught Lake Hawassa tilapia, crisp pan-fried with garlic, rosemary, mitmita spice, and warm lime glaze.',
    category: 'Lake Hawassa Seafood',
    image: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=400&auto=format&fit=crop&q=80',
    tag: "Chef's Special",
    favorite: true,
    linkedInventorySku: 'FB-001',
    defaultNote: 'Well crisped with karia chili'
  },
  {
    id: 'pos-eth-3',
    name: 'Sizzling Sidama Beef Tibs',
    price: 620.00,
    description: 'Prime beef cubes sautéed on clay shekla with red onions, rosemary sprigs, jalapeño peppers, and awaze dip.',
    category: 'Ethiopian Specialties',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=400&auto=format&fit=crop&q=80',
    tag: 'Spicy',
    isSpicy: true,
    favorite: true,
    defaultNote: 'Juicy medium-well'
  },
  {
    id: 'pos-eth-4',
    name: 'Clay Pot Shiro Tegabino',
    price: 420.00,
    description: 'Simmering organic powdered chickpeas cooked in clay pot with garlic, ginger, and spiced Ethiopian herbal butter (kibe).',
    category: 'Ethiopian Specialties',
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&auto=format&fit=crop&q=80',
    tag: 'Vegetarian',
    isVegetarian: true,
    favorite: true,
    defaultNote: 'Bubbling hot with injera'
  },
  {
    id: 'pos-eth-5',
    name: 'Sidama Coffee Ceremony (Bunna)',
    price: 180.00,
    description: 'Traditional organic single-origin Sidama beans freshly roasted and brewed in clay pot (Jebena), served with popped corn & incense.',
    category: 'Beverages',
    image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=400&auto=format&fit=crop&q=80',
    tag: "Chef's Special",
    isVegetarian: true,
    favorite: true,
    defaultNote: 'With traditional rue herb'
  },
  {
    id: 'pos-eth-6',
    name: 'Fresh Fruit Spris Juice',
    price: 220.00,
    description: 'Layered fresh Hawassa avocado, sweet mango, and papaya puree with fresh lime wedge and vimto syrup.',
    category: 'Beverages',
    image: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?w=400&auto=format&fit=crop&q=80',
    tag: 'Vegetarian',
    isVegetarian: true,
    favorite: true,
    defaultNote: 'Avocado & Mango layered'
  },
  {
    id: 'pos-eth-7',
    name: 'Habesha Cold Lager Beer',
    price: 190.00,
    description: 'Cold Ethiopian 5% cold-filtered malt beer brewed from pristine highland spring water.',
    category: 'Beverages',
    image: 'https://images.unsplash.com/photo-1608270192799-59e8f8b89410?w=400&auto=format&fit=crop&q=80',
    favorite: true,
    defaultNote: 'Chilled bottle'
  },
  {
    id: 'pos-eth-8',
    name: 'Traditional Tej (Honey Wine)',
    price: 280.00,
    description: 'Pure organic fermented Ethiopian acacia honey wine served in traditional round-bottom flask (berele).',
    category: 'Beverages',
    image: 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=400&auto=format&fit=crop&q=80',
    favorite: true,
    defaultNote: 'Served in berele flask'
  },

  // International & Continental Classics
  {
    id: 'pos-1',
    name: 'Burqito Classic Burger',
    price: 520.00,
    description: 'Prime highland beef patty, lettuce, garden tomato, aged gouda, hand-cut potato wedges.',
    category: 'Grill & Barbecue',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&auto=format&fit=crop&q=80',
    tag: "Chef's Special",
    linkedInventorySku: 'FB-001',
    favorite: true,
    defaultNote: 'Medium well'
  },
  {
    id: 'pos-2',
    name: 'Wood-fired Margherita Pizza',
    price: 480.00,
    description: 'Fresh tomato concasse, mozzarella fior di latte, fresh basil leaves from our kitchen garden.',
    category: 'Pizza & Pasta',
    image: 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=400&auto=format&fit=crop&q=80',
    tag: 'Vegetarian',
    isVegetarian: true,
    linkedInventorySku: 'FB-002',
    favorite: true,
    defaultNote: 'Extra basil'
  },
  {
    id: 'pos-3',
    name: 'Pan-Seared Salmon Fillet',
    price: 950.00,
    description: 'Imported Norwegian salmon fillet served with baby carrots, asparagus, and lemon butter emulsion.',
    category: 'Lake Hawassa Seafood',
    image: 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=400&auto=format&fit=crop&q=80',
    tag: "Chef's Special",
    linkedInventorySku: 'FB-001',
    favorite: true,
    defaultNote: 'Medium with crisp skin'
  },
  {
    id: 'pos-4',
    name: 'Garden Caesar Salad',
    price: 390.00,
    description: 'Crisp romaine lettuce hearts, shaved parmesan, garlic herb croutons, creamy anchovy dressing.',
    category: 'Salads',
    image: 'https://images.unsplash.com/photo-1550304943-4f24f54ddde9?w=400&auto=format&fit=crop&q=80',
    tag: 'Vegetarian',
    isVegetarian: true,
    favorite: true,
    defaultNote: 'Dressing on side'
  },
  {
    id: 'pos-5',
    name: 'Fettuccine Chicken Alfredo',
    price: 540.00,
    description: 'Fresh pasta ribbons tossed with rich parmesan cream, grilled herb chicken, and black pepper.',
    category: 'Pizza & Pasta',
    image: 'https://images.unsplash.com/photo-1645112411341-6c4fd023714a?w=400&auto=format&fit=crop&q=80',
    favorite: true,
    defaultNote: 'Extra parmesan'
  },
  {
    id: 'pos-6',
    name: 'Charcoal Grilled Ribeye Steak',
    price: 980.00,
    description: '300g marbled ribeye steak grilled over acacia coals, garlic mashed potato, rosemary jus.',
    category: 'Grill & Barbecue',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=400&auto=format&fit=crop&q=80',
    tag: "Chef's Special",
    favorite: true,
    defaultNote: 'Medium rare'
  },
  {
    id: 'pos-7',
    name: 'San Marzano Tomato Soup',
    price: 290.00,
    description: 'Roasted ripe tomato velouté, fresh basil oil, crispy toasted garlic baguette.',
    category: 'Soups',
    image: 'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=400&auto=format&fit=crop&q=80',
    tag: 'Vegetarian',
    isVegetarian: true,
    favorite: true,
    defaultNote: 'With warm garlic roll'
  },
  {
    id: 'pos-11',
    name: 'Warm Belgian Chocolate Fondant',
    price: 360.00,
    description: 'Molten dark chocolate cake served with Madagascar vanilla bean gelato.',
    category: 'Desserts',
    image: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=400&auto=format&fit=crop&q=80',
    favorite: true,
    defaultNote: 'With vanilla gelato'
  },
  {
    id: 'pos-12',
    name: 'Tropical Fruit Plate',
    price: 280.00,
    description: 'Hawassa pineapple, sweet papaya, watermelon, mango slices, wild forest honey drizzle.',
    category: 'Desserts',
    image: 'https://images.unsplash.com/photo-1519996529931-28324d5a630e?w=400&auto=format&fit=crop&q=80',
    tag: 'Vegetarian',
    isVegetarian: true,
    favorite: true
  },
  {
    id: 'pos-15',
    name: 'Lakefront Breakfast Eggs Benedict',
    price: 450.00,
    description: 'Poached free-range farm eggs on toasted brioche with smoked turkey bacon and warm hollandaise.',
    category: 'Breakfast',
    image: 'https://images.unsplash.com/photo-1608039829572-78524f79c4c7?w=400&auto=format&fit=crop&q=80',
    tag: "Chef's Special",
    favorite: true
  }
];

export interface PosOrderItem {
  id: string;
  menuItem: PosMenuItem;
  quantity: number;
  note?: string;
  customPrice?: number;
}
